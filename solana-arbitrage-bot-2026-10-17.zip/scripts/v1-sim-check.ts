// Read-only: does each RPC endpoint deserialize a v1 SMB transaction?
import dotenv from "dotenv";
dotenv.config({ quiet: true } as any);
import { Connection, Keypair, PublicKey, SystemProgram } from "@solana/web3.js";
import { compileV1, signV1 } from "../smb/tx-v1";

(async () => {
  const kp = Keypair.generate();
  const urls = [process.env.RPC_ENDPOINT!, "https://api.mainnet-beta.solana.com", "https://solana-rpc.publicnode.com"];
  for (const url of urls) {
    const c = new Connection(url, "processed");
    const { blockhash } = await c.getLatestBlockhash();
    const m = compileV1(kp.publicKey, [SystemProgram.transfer({ fromPubkey: kp.publicKey, toPubkey: kp.publicKey, lamports: 0 })], blockhash, { priorityFee: BigInt(1000), computeUnitLimit: 10000 });
    const b64 = Buffer.from(signV1(m, null).wire).toString("base64");
    const outs: string[] = [];
    for (let i = 0; i < 6; i++) {
      const r = await (c as any)._rpcRequest("simulateTransaction", [b64, { encoding: "base64", sigVerify: false, replaceRecentBlockhash: true }]);
      outs.push(r.error ? `ERR:${String(r.error.message).slice(0, 40)}` : `ok:${JSON.stringify(r.result.value.err).slice(0, 30)}`);
    }
    console.log(url.replace(/api-key=.*/, "api-key=***"), outs.join(" | "));
  }
})();
