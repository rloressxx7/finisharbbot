// Zero-cost probe (unfunded random wallet: nothing can land or pay a fee):
// does each send path accept our v1 wire format, and how fast does it answer?
import dotenv from "dotenv";
dotenv.config({ quiet: true } as any);
import { Connection, Keypair, PublicKey, SystemProgram } from "@solana/web3.js";
import { compileV1, signV1 } from "../smb/tx-v1";

const SENDER = ["http://fra-sender.helius-rpc.com", "http://ams-sender.helius-rpc.com", "http://lon-sender.helius-rpc.com"];
const JITO = ["https://frankfurt.mainnet.block-engine.jito.wtf", "https://amsterdam.mainnet.block-engine.jito.wtf", "https://london.mainnet.block-engine.jito.wtf"];
const SENDER_TIP = new PublicKey("4ACfpUFoaSD9bfPdeu6DBt89gB6ENTeHBXCAi87NhDEE");

async function post(url: string, method: string, params: unknown[]) {
  const t0 = performance.now();
  try {
    const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }) });
    const text = await r.text();
    return `${(performance.now() - t0).toFixed(0)}ms ${r.status} ${text.slice(0, 140)}`;
  } catch (e) {
    return `${(performance.now() - t0).toFixed(0)}ms ERR ${String(e).slice(0, 100)}`;
  }
}

(async () => {
  const conn = new Connection(process.env.RPC_ENDPOINT!);
  const { blockhash } = await conn.getLatestBlockhash();
  const kp = Keypair.generate();
  const jitoTip = new PublicKey(JSON.parse(await (await fetch(`${JITO[0]}/api/v1/getTipAccounts`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "getTipAccounts", params: [] }) })).text()).result[0]);
  const wire = (to: PublicKey, lamports: number) =>
    Buffer.from(signV1(compileV1(kp.publicKey, [SystemProgram.transfer({ fromPubkey: kp.publicKey, toPubkey: to, lamports })], blockhash, { priorityFee: BigInt(10000), computeUnitLimit: 5000 }), kp).wire).toString("base64");
  for (const s of SENDER) {
    const t0 = performance.now();
    await fetch(`${s}/ping`).catch(() => null);
    const ping = (performance.now() - t0).toFixed(0);
    const t1 = performance.now();
    await fetch(`${s}/ping`).catch(() => null);
    console.log("sender", s, `ping ${ping}ms warm ${(performance.now() - t1).toFixed(0)}ms`, "| swqos tx:", await post(`${s}/fast?swqos_only=true`, "sendTransaction", [wire(SENDER_TIP, 5000), { encoding: "base64", skipPreflight: true, maxRetries: 0 }]));
  }
  for (const j of JITO) {
    console.log("jito", j, "| bundle:", await post(`${j}/api/v1/bundles`, "sendBundle", [[wire(jitoTip, 1000)], { encoding: "base64" }]));
  }
  console.log("helius rpc | tx:", await post(process.env.RPC_ENDPOINT!, "sendTransaction", [wire(SENDER_TIP, 0), { encoding: "base64", skipPreflight: true, maxRetries: 0 }]));
})();
