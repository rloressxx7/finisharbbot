// Read-only: waits for one market win, builds our SMB tx for its pools, simulates (DRY).
import dotenv from "dotenv";
dotenv.config({ quiet: true } as any);
import { Connection, Keypair, PublicKey } from "@solana/web3.js";
import { startHarvester } from "../smb/harvest";
import { smbTry } from "../smb/execute";
import { createRateLimitedFetch } from "../utils/rpcLimiter";
import bs58 from "bs58";

const conn = new Connection(process.env.RPC_ENDPOINT!, { commitment: "confirmed", fetch: createRateLimitedFetch(4) });
const signer = Keypair.fromSecretKey(bs58.decode(process.env.PRIVATE_KEY!));
let done = false;
const run = async (c: { mint: string; pools: string[] }) => {
  if (done) return;
  done = true;
  const mi = await conn.getAccountInfo(new PublicKey(c.mint));
  const { blockhash } = await conn.getLatestBlockhash();
  const r = await smbTry({ conn, sendConns: [], plain: false, signer, mint: new PublicKey(c.mint), tokenProgram: mi!.owner, pools: c.pools.map((p) => new PublicKey(p)), blockhash, live: false,
    s: { programFeeBps: 1100, minProfitLamports: BigInt(7000), priorityLamports: BigInt(10000), maxPools: 4, simFirst: true } });
  console.log(c.mint, c.pools, r);
  process.exit(0);
};
if (process.argv[2]) run({ mint: process.argv[2], pools: process.argv[3].split(",") });
else startHarvester(conn, (c) => void run(c));
setTimeout(() => process.exit(1), 200000);
