// Read-only: lists profitable SolanaMevBot calls seen in the last ~1000 txs.
import dotenv from "dotenv";
dotenv.config({ quiet: true } as any);
import { Connection } from "@solana/web3.js";
import { startHarvester, harvestStats } from "../smb/harvest";
import { createRateLimitedFetch } from "../utils/rpcLimiter";

const conn = new Connection(process.env.RPC_ENDPOINT!, { commitment: "confirmed", fetch: createRateLimitedFetch(5) });
startHarvester(conn, (c) => {
  console.log(new Date(c.blockTime * 1000).toISOString().slice(11, 19), (Number(c.net) / 1e9).toFixed(6), "SOL", c.signer.slice(0, 6), c.mint, c.pools.join(","));
}, 15000);
setInterval(() => console.log("stats", JSON.stringify(harvestStats)), 30000);
setTimeout(() => process.exit(0), Number(process.argv[2] ?? 240) * 1000);
