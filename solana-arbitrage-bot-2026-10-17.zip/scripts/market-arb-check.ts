// Read-only: market-wide profitable arbitrage seen on the pumpapi stream.
import { startPumpApiStream } from "../utils/pumpapi";
import { createMarketArbDetector, marketArbStats } from "../utils/marketArb";

const routes = new Map<string, { n: number; lamports: bigint; venues: string }>();
const signers = new Map<string, number>();
const signerSol = new Map<string, bigint>();
const feed = createMarketArbDetector((a) => {
  const k = `${a.mint}|${a.pools.slice().sort().join(",")}`;
  const r = routes.get(k) ?? { n: 0, lamports: BigInt(0), venues: a.venues.join("+") };
  r.n++;
  r.lamports += a.net;
  routes.set(k, r);
  signers.set(a.signer, (signers.get(a.signer) ?? 0) + 1);
  signerSol.set(a.signer, (signerSol.get(a.signer) ?? BigInt(0)) + a.net);
});
startPumpApiStream({ onEvent: feed });
const secs = Number(process.argv[2] ?? 180);
setTimeout(() => {
  const s = marketArbStats;
  console.log(`${secs}s: txs=${s.txs} buy+sell cycles=${s.cycles} profitable=${s.profitable} total=${(Number(s.lamports) / 1e9).toFixed(4)} SOL routes=${routes.size} signers=${signers.size}`);
  const topRoutes = [...routes.entries()].sort((a, b) => Number(b[1].lamports - a[1].lamports)).slice(0, 15);
  for (const [k, r] of topRoutes) console.log(`${(Number(r.lamports) / 1e9).toFixed(5)} SOL x${r.n} ${r.venues} ${k.split("|")[0]}`);
  const top = [...signers.entries()].sort((a, b) => b[1] - a[1]).slice(0, 25);
  for (const [w, n] of top) console.log("SIGNER", w, n, (Number(signerSol.get(w)) / 1e9).toFixed(5));
  process.exit(0);
}, secs * 1000);
