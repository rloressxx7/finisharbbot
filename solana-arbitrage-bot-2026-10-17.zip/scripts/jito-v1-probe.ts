// Zero-cost: an unfunded random wallet's v1 tx in a bundle can never land.
import dotenv from "dotenv";
dotenv.config({ quiet: true } as any);
import { Connection, Keypair, PublicKey, SystemProgram, TransactionMessage, VersionedTransaction } from "@solana/web3.js";
import { compileV1, signV1 } from "../smb/tx-v1";

(async () => {
  const be = process.env.BLOCK_ENGINE_URL!;
  const post = async (path: string, method: string, params: unknown[]) =>
    (await (await fetch(`${be}${path}`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ jsonrpc: "2.0", id: 1, method, params }) })).json());
  const tip = new PublicKey((await post("/api/v1/getTipAccounts", "getTipAccounts", [])).result[0]);
  const conn = new Connection(process.env.RPC_ENDPOINT!);
  const { blockhash } = await conn.getLatestBlockhash();
  const kp = Keypair.generate();
  const ixs = [SystemProgram.transfer({ fromPubkey: kp.publicKey, toPubkey: tip, lamports: 1000 })];
  const v1 = Buffer.from(signV1(compileV1(kp.publicKey, ixs, blockhash, { priorityFee: BigInt(1000), computeUnitLimit: 5000 }), kp).wire).toString("base64");
  const v0tx = new VersionedTransaction(new TransactionMessage({ payerKey: kp.publicKey, recentBlockhash: blockhash, instructions: ixs }).compileToV0Message());
  v0tx.sign([kp]);
  const v0 = Buffer.from(v0tx.serialize()).toString("base64");
  console.log("v0 bundle:", JSON.stringify(await post("/api/v1/bundles", "sendBundle", [[v0], { encoding: "base64" }])).slice(0, 200));
  console.log("v1 bundle:", JSON.stringify(await post("/api/v1/bundles", "sendBundle", [[v1], { encoding: "base64" }])).slice(0, 200));
  console.log("v1 tx    :", JSON.stringify(await post("/api/v1/transactions", "sendTransaction", [v1, { encoding: "base64" }])).slice(0, 200));
})();
