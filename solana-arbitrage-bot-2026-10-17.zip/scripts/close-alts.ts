// Lists / deactivates / closes the wallet's address lookup tables (rent back to the wallet).
//   npx ts-node scripts/close-alts.ts list
//   npx ts-node scripts/close-alts.ts deactivate   (then wait ~513 slots, about 4 minutes)
//   npx ts-node scripts/close-alts.ts close
import dotenv from "dotenv";
dotenv.config({ quiet: true } as any);
import { AddressLookupTableProgram, Connection, Keypair, PublicKey, TransactionMessage, VersionedTransaction } from "@solana/web3.js";
import bs58 from "bs58";

const ALT_PROGRAM = new PublicKey("AddressLookupTab1e1111111111111111111111111");

(async () => {
  const mode = process.argv[2] ?? "list";
  const conn = new Connection(process.env.RPC_ENDPOINT!, "confirmed");
  const wallet = Keypair.fromSecretKey(bs58.decode(process.env.PRIVATE_KEY!));
  // Layout: type u32, deactivation_slot u64, last_extended_slot u64, start index u8, authority Option<Pubkey> at 21/22.
  const accs = await conn.getProgramAccounts(ALT_PROGRAM, {
    filters: [{ memcmp: { offset: 22, bytes: wallet.publicKey.toBase58() } }],
  });
  const slot = await conn.getSlot("confirmed");
  let total = 0;
  for (const a of accs) {
    const deact = a.account.data.readBigUInt64LE(4);
    const active = deact === BigInt("18446744073709551615");
    total += a.account.lamports;
    console.log(a.pubkey.toBase58(), (a.account.lamports / 1e9).toFixed(6), "SOL", active ? "active" : `deactivated@${deact} (+${slot - Number(deact)} slots)`);
  }
  console.log(`wallet ${wallet.publicKey.toBase58()} ALTs=${accs.length} rent=${(total / 1e9).toFixed(6)} SOL`);
  if (mode === "list") return;

  const ixs = accs.flatMap((a) => {
    const deact = a.account.data.readBigUInt64LE(4);
    const active = deact === BigInt("18446744073709551615");
    if (mode === "deactivate" && active) {
      return [AddressLookupTableProgram.deactivateLookupTable({ lookupTable: a.pubkey, authority: wallet.publicKey })];
    }
    if (mode === "close" && !active && slot - Number(deact) > 513) {
      return [AddressLookupTableProgram.closeLookupTable({ lookupTable: a.pubkey, authority: wallet.publicKey, recipient: wallet.publicKey })];
    }
    return [];
  });
  if (!ixs.length) return console.log(`nothing to ${mode}`);
  const { blockhash, lastValidBlockHeight } = await conn.getLatestBlockhash();
  const tx = new VersionedTransaction(new TransactionMessage({ payerKey: wallet.publicKey, recentBlockhash: blockhash, instructions: ixs }).compileToV0Message());
  tx.sign([wallet]);
  const sig = await conn.sendTransaction(tx);
  await conn.confirmTransaction({ signature: sig, blockhash, lastValidBlockHeight }, "confirmed");
  console.log(`${mode}: ${ixs.length} table(s), tx ${sig}`);
  console.log("balance now", (await conn.getBalance(wallet.publicKey)) / 1e9, "SOL");
})();
