// Creates the wallet's WSOL associated token account once (idempotent).
// Its rent stays in the account and comes back if it is ever closed.
import dotenv from "dotenv";
dotenv.config({ quiet: true } as any);
import { Connection, Keypair, TransactionMessage, VersionedTransaction } from "@solana/web3.js";
import { createAssociatedTokenAccountIdempotentInstruction, getAssociatedTokenAddressSync, NATIVE_MINT } from "@solana/spl-token";
import bs58 from "bs58";

(async () => {
  const conn = new Connection(process.env.RPC_ENDPOINT!, "confirmed");
  const wallet = Keypair.fromSecretKey(bs58.decode(process.env.PRIVATE_KEY!));
  const ata = getAssociatedTokenAddressSync(NATIVE_MINT, wallet.publicKey);
  if (await conn.getAccountInfo(ata)) return console.log("WSOL account already exists:", ata.toBase58());
  const { blockhash, lastValidBlockHeight } = await conn.getLatestBlockhash();
  const tx = new VersionedTransaction(
    new TransactionMessage({
      payerKey: wallet.publicKey,
      recentBlockhash: blockhash,
      instructions: [createAssociatedTokenAccountIdempotentInstruction(wallet.publicKey, ata, wallet.publicKey, NATIVE_MINT)],
    }).compileToV0Message(),
  );
  tx.sign([wallet]);
  const sig = await conn.sendTransaction(tx);
  await conn.confirmTransaction({ signature: sig, blockhash, lastValidBlockHeight }, "confirmed");
  console.log("WSOL account created:", ata.toBase58(), "tx", sig);
  console.log("balance now", (await conn.getBalance(wallet.publicKey)) / 1e9, "SOL");
})();
