import dotenv from "dotenv";
import bs58 from "bs58";
import fs from "node:fs";
import { createInterface } from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";
import {
  AddressLookupTableProgram,
  Connection,
  Keypair,
  LAMPORTS_PER_SOL,
  PublicKey,
  TransactionMessage,
  TransactionInstruction,
  VersionedTransaction,
} from "@solana/web3.js";

dotenv.config();

const MAINNET_GENESIS_HASH = "5eykt4UsFv8P8NJdTREpY1vzqKqZKvdpKuc147dw2N9d";

async function sendAndConfirm(
  connection: Connection,
  payer: Keypair,
  instructions: TransactionInstruction[],
): Promise<string> {
  const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash("confirmed");
  const message = new TransactionMessage({
    payerKey: payer.publicKey,
    recentBlockhash: blockhash,
    instructions,
  }).compileToV0Message();
  const transaction = new VersionedTransaction(message);
  transaction.sign([payer]);
  const signature = await connection.sendTransaction(transaction, { maxRetries: 3 });
  const confirmation = await connection.confirmTransaction(
    { signature, blockhash, lastValidBlockHeight },
    "confirmed",
  );
  if (confirmation.value.err) {
    throw new Error(`Transaction failed: ${JSON.stringify(confirmation.value.err)}; signature=${signature}`);
  }
  return signature;
}

async function main(): Promise<void> {
  const rpcEndpoint = process.env.RPC_ENDPOINT?.trim();
  const privateKey = process.env.PRIVATE_KEY?.trim();
  if (!rpcEndpoint || !privateKey) {
    throw new Error("RPC_ENDPOINT and PRIVATE_KEY must be set in .env");
  }
  if (!fs.existsSync("alts.txt")) throw new Error("alts.txt was not found in the project root");

  const addresses = [...new Set(
    fs.readFileSync("alts.txt", "utf8")
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean),
  )].map((line) => new PublicKey(line));
  if (addresses.length === 0) throw new Error("alts.txt contains no addresses");

  const connection = new Connection(rpcEndpoint, "confirmed");
  const genesisHash = await connection.getGenesisHash();
  if (genesisHash !== MAINNET_GENESIS_HASH) {
    throw new Error("RPC_ENDPOINT is not Solana mainnet-beta; refusing to create an ALT");
  }

  const payer = Keypair.fromSecretKey(bs58.decode(privateKey));
  const balance = await connection.getBalance(payer.publicKey, "confirmed");
  const accountBytes = 56 + 32 * addresses.length;
  const rentLamports = await connection.getMinimumBalanceForRentExemption(accountBytes, "confirmed");
  const estimatedRentSol = rentLamports / LAMPORTS_PER_SOL;

  console.log("Network: Solana mainnet-beta");
  console.log("Payer public key:", payer.publicKey.toBase58());
  console.log("Payer balance:", (balance / LAMPORTS_PER_SOL).toFixed(6), "SOL");
  console.log("Unique addresses to add:", addresses.length);
  console.log("Estimated ALT rent only:", estimatedRentSol.toFixed(6), "SOL (transaction fees are additional)");
  console.log("This will create an on-chain lookup table and submit extension transactions; it spends real SOL.");

  const rl = createInterface({ input, output });
  const answer = await rl.question("To continue on MAINNET, type CREATE-ALT-MAINNET: ");
  rl.close();
  if (answer.trim() !== "CREATE-ALT-MAINNET") {
    console.log("Cancelled. No on-chain transaction was sent.");
    return;
  }

  const recentSlot = await connection.getSlot("finalized");
  const [createInstruction, lookupTableAddress] = AddressLookupTableProgram.createLookupTable({
    authority: payer.publicKey,
    payer: payer.publicKey,
    recentSlot,
  });

  console.log("Creating ALT:", lookupTableAddress.toBase58());
  const createSignature = await sendAndConfirm(connection, payer, [createInstruction]);
  console.log("Create transaction confirmed:", createSignature);

  const batchSize = 20;
  for (let i = 0; i < addresses.length; i += batchSize) {
    const batch = addresses.slice(i, i + batchSize);
    const extendInstruction = AddressLookupTableProgram.extendLookupTable({
      payer: payer.publicKey,
      authority: payer.publicKey,
      lookupTable: lookupTableAddress,
      addresses: batch,
    });
    const signature = await sendAndConfirm(connection, payer, [extendInstruction]);
    console.log(`Extended ${Math.min(i + batch.length, addresses.length)}/${addresses.length} addresses:`, signature);
  }

  // Wait for an RPC read to observe the newly extended table.
  let table = null;
  for (let attempt = 0; attempt < 10; attempt++) {
    const result = await connection.getAddressLookupTable(lookupTableAddress, { commitment: "confirmed" });
    table = result.value;
    if (table && table.state.addresses.length === addresses.length) break;
    await new Promise((resolve) => setTimeout(resolve, 1000));
  }
  if (!table || table.state.addresses.length !== addresses.length) {
    throw new Error(`ALT was created but verification was incomplete. New ALT address: ${lookupTableAddress.toBase58()}`);
  }

  console.log("\nALT READY:", lookupTableAddress.toBase58());
  console.log("Verified addresses:", table.state.addresses.length);

  // Update the known stale hard-coded ALT address safely and keep a backup first.
  const mainPath = "main.ts";
  const oldAddress = "4RqDUqkQqMkbQEAXvEBr5nFhh3hhfeHxeL9gUaMCFzyh";
  if (fs.existsSync(mainPath)) {
    const source = fs.readFileSync(mainPath, "utf8");
    const needle = `new PublicKey("${oldAddress}")`;
    const occurrences = source.split(needle).length - 1;
    if (occurrences === 1) {
      const stamp = new Date().toISOString().replace(/[:.]/g, "-");
      const backupPath = `${mainPath}.before-alt-${stamp}.bak`;
      fs.copyFileSync(mainPath, backupPath);
      fs.writeFileSync(mainPath, source.replace(needle, `new PublicKey("${lookupTableAddress.toBase58()}")`), "utf8");
      console.log("Updated main.ts automatically.");
      console.log("Backup:", backupPath);
      console.log("Next run: pnpm exec tsc --noEmit");
    } else {
      console.log("Could not safely auto-update main.ts (expected the old ALT constant exactly once).");
      console.log(`Manually replace ${oldAddress} with ${lookupTableAddress.toBase58()} in main.ts.`);
    }
  } else {
    console.log("main.ts not found in current directory; update its lookupTableAddress constant manually.");
  }
}

main().catch((error: unknown) => {
  const message = error instanceof Error ? error.message : String(error);
  console.error("ALT creation failed:", message);
  process.exitCode = 1;
});
