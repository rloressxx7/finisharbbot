/**
 * Minimal gRPC client for the local shredstream proxy's
 * `shredstream.ShredstreamProxy/SubscribeEntries` (server streaming), on
 * node:http2 — no gRPC dependency. Each stream message is a protobuf
 * `Entry { uint64 slot = 1; bytes entries = 2; }`, framed gRPC-style:
 * 1 byte compressed flag + 4 byte big-endian length + message.
 */
import http2 from "node:http2";

export interface ShredEntryMessage {
  slot: bigint;
  entries: Uint8Array;
  /** performance.now() when the last byte of this message arrived. */
  receivedAt: number;
}

/** Parse protobuf `Entry` (only fields 1 and 2; unknown fields skipped). */
export function parseEntryMessage(msg: Uint8Array): { slot: bigint; entries: Uint8Array } {
  let off = 0;
  let slot = 0n;
  let entries: Uint8Array = new Uint8Array(0);
  const varint = (): bigint => {
    let v = 0n;
    let shift = 0n;
    for (;;) {
      if (off >= msg.length) throw new Error("protobuf varint truncated");
      const b = msg[off++]!;
      v |= BigInt(b & 0x7f) << shift;
      if ((b & 0x80) === 0) return v;
      shift += 7n;
      if (shift > 63n) throw new Error("protobuf varint too long");
    }
  };
  while (off < msg.length) {
    const key = Number(varint());
    const field = key >>> 3;
    const wire = key & 7;
    if (wire === 0) {
      const v = varint();
      if (field === 1) slot = v;
    } else if (wire === 2) {
      const len = Number(varint());
      if (off + len > msg.length) throw new Error("protobuf bytes truncated");
      const v = msg.subarray(off, off + len);
      off += len;
      if (field === 2) entries = v;
    } else if (wire === 1) {
      off += 8;
    } else if (wire === 5) {
      off += 4;
    } else {
      throw new Error(`protobuf wire type ${wire} not supported`);
    }
  }
  return { slot, entries };
}

/** Accumulates stream chunks and yields complete gRPC messages. */
export class GrpcFramer {
  private buf = new Uint8Array(0);

  push(chunk: Uint8Array): Uint8Array[] {
    const merged = new Uint8Array(this.buf.length + chunk.length);
    merged.set(this.buf, 0);
    merged.set(chunk, this.buf.length);
    this.buf = merged;
    const out: Uint8Array[] = [];
    while (this.buf.length >= 5) {
      if (this.buf[0] !== 0) throw new Error("compressed gRPC messages not supported");
      const len = new DataView(this.buf.buffer, this.buf.byteOffset + 1, 4).getUint32(0, false);
      if (this.buf.length < 5 + len) break;
      out.push(this.buf.slice(5, 5 + len));
      this.buf = this.buf.slice(5 + len);
    }
    return out;
  }
}

/**
 * Subscribe to the proxy's entries. Calls `onEntry` for every message and
 * `onEnd` when the stream ends or fails. Returns a function that closes it.
 */
export function subscribeEntries(
  url: string,
  onEntry: (e: ShredEntryMessage) => void,
  onEnd: (err?: Error) => void,
): () => void {
  const client = http2.connect(url);
  let ended = false;
  const end = (err?: Error) => {
    if (ended) return;
    ended = true;
    try {
      client.close();
    } catch {
      /* already closed */
    }
    onEnd(err);
  };
  client.on("error", (e) => end(e));
  const req = client.request({
    ":method": "POST",
    ":path": "/shredstream.ShredstreamProxy/SubscribeEntries",
    "content-type": "application/grpc",
    te: "trailers",
  });
  const framer = new GrpcFramer();
  req.on("data", (chunk: Buffer) => {
    let msgs: Uint8Array[];
    try {
      msgs = framer.push(chunk);
    } catch (e) {
      end(e as Error);
      return;
    }
    const at = performance.now();
    for (const m of msgs) {
      try {
        const { slot, entries } = parseEntryMessage(m);
        onEntry({ slot, entries, receivedAt: at });
      } catch (e) {
        end(e as Error);
        return;
      }
    }
  });
  req.on("trailers", (t) => {
    const status = t["grpc-status"];
    if (status !== undefined && String(status) !== "0") {
      end(new Error(`grpc-status ${status} ${t["grpc-message"] ?? ""}`));
    }
  });
  req.on("end", () => end());
  req.on("error", (e) => end(e));
  // Empty SubscribeEntriesRequest: flag 0, length 0.
  req.end(Buffer.from([0, 0, 0, 0, 0]));
  return () => end();
}
