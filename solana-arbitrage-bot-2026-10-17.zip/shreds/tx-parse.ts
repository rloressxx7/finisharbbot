/**
 * One parser for all three wire formats (legacy, v0, v1/SIMD-0385): account
 * keys, lookup-table references and instructions, straight from the bytes.
 * web3.js cannot read v1, and a hot path that only needs "which accounts,
 * which program, which data" does not need full deserialization.
 */
import { TX_V1 } from "./entries";

export interface ParsedInstruction {
  programIndex: number;
  accounts: number[];
  data: Uint8Array;
}

export interface ParsedLookup {
  table: Uint8Array;
  writable: number[];
  readonly: number[];
}

export interface ParsedTx {
  version: "legacy" | 0 | 1;
  /** First signature (the tx id), 64 bytes. */
  signature: Uint8Array;
  numRequiredSignatures: number;
  numReadonlySigned: number;
  numReadonlyUnsigned: number;
  /** Static account keys, 32 bytes each. */
  staticKeys: Uint8Array[];
  /** v0 only. Loaded indexes follow the static keys: all writable, then all readonly. */
  lookups: ParsedLookup[];
  instructions: ParsedInstruction[];
}

function shortVec(buf: Uint8Array, off: { v: number }): number {
  let len = 0;
  for (let i = 0; i < 3; i++) {
    const b = buf[off.v++];
    if (b === undefined) throw new Error("tx truncated");
    len |= (b & 0x7f) << (7 * i);
    if ((b & 0x80) === 0) return len;
  }
  throw new Error("bad short_vec");
}

function take(buf: Uint8Array, off: { v: number }, n: number): Uint8Array {
  if (off.v + n > buf.length) throw new Error("tx truncated");
  const out = buf.subarray(off.v, off.v + n);
  off.v += n;
  return out;
}

function parseV1(buf: Uint8Array): ParsedTx {
  const off = { v: 1 };
  const [req, roSigned, roUnsigned] = take(buf, off, 3);
  const maskBytes = take(buf, off, 4);
  const mask = maskBytes[0]! | (maskBytes[1]! << 8) | (maskBytes[2]! << 16) | (maskBytes[3]! << 24);
  take(buf, off, 32); // lifetime
  const nIx = take(buf, off, 1)[0]!;
  const nAddr = take(buf, off, 1)[0]!;
  const staticKeys: Uint8Array[] = [];
  for (let i = 0; i < nAddr; i++) staticKeys.push(take(buf, off, 32));
  let bits = 0;
  for (let m = mask >>> 0; m; m &= m - 1) bits++;
  take(buf, off, 4 * bits);
  const headers: { prog: number; nAcc: number; len: number }[] = [];
  for (let i = 0; i < nIx; i++) {
    const h = take(buf, off, 4);
    headers.push({ prog: h[0]!, nAcc: h[1]!, len: h[2]! | (h[3]! << 8) });
  }
  const instructions: ParsedInstruction[] = headers.map((h) => ({
    programIndex: h.prog,
    accounts: [...take(buf, off, h.nAcc)],
    data: take(buf, off, h.len),
  }));
  const sigs = take(buf, off, 64 * req!);
  return {
    version: 1,
    signature: sigs.subarray(0, 64),
    numRequiredSignatures: req!,
    numReadonlySigned: roSigned!,
    numReadonlyUnsigned: roUnsigned!,
    staticKeys,
    lookups: [],
    instructions,
  };
}

export function parseTx(buf: Uint8Array): ParsedTx {
  if (buf[0] === TX_V1) return parseV1(buf);
  const off = { v: 0 };
  const nSig = shortVec(buf, off);
  const sigs = take(buf, off, 64 * nSig);
  let version: "legacy" | 0 = "legacy";
  if ((buf[off.v]! & 0x80) !== 0) {
    const v = buf[off.v]! & 0x7f;
    if (v !== 0) throw new Error(`unsupported message version ${v}`);
    version = 0;
    off.v++;
  }
  const [req, roSigned, roUnsigned] = take(buf, off, 3);
  const nKeys = shortVec(buf, off);
  const staticKeys: Uint8Array[] = [];
  for (let i = 0; i < nKeys; i++) staticKeys.push(take(buf, off, 32));
  take(buf, off, 32); // recent blockhash
  const nIx = shortVec(buf, off);
  const instructions: ParsedInstruction[] = [];
  for (let i = 0; i < nIx; i++) {
    const programIndex = take(buf, off, 1)[0]!;
    const accounts = [...take(buf, off, shortVec(buf, off))];
    const data = take(buf, off, shortVec(buf, off));
    instructions.push({ programIndex, accounts, data });
  }
  const lookups: ParsedLookup[] = [];
  if (version === 0) {
    const nL = shortVec(buf, off);
    for (let i = 0; i < nL; i++) {
      const table = take(buf, off, 32);
      const writable = [...take(buf, off, shortVec(buf, off))];
      const readonly = [...take(buf, off, shortVec(buf, off))];
      lookups.push({ table, writable, readonly });
    }
  }
  return {
    version,
    signature: sigs.subarray(0, 64),
    numRequiredSignatures: req!,
    numReadonlySigned: roSigned!,
    numReadonlyUnsigned: roUnsigned!,
    staticKeys,
    lookups,
    instructions,
  };
}

/**
 * All account keys in index order: static keys, then (v0) every lookup's
 * writable addresses, then every lookup's readonly addresses. `resolve`
 * returns a table's addresses, or undefined when it is not cached yet — then
 * the result is undefined too (the caller fetches the table and moves on).
 */
export function accountKeys(
  tx: ParsedTx,
  resolve: (table: Uint8Array) => Uint8Array[] | undefined,
): Uint8Array[] | undefined {
  if (!tx.lookups.length) return tx.staticKeys;
  const writable: Uint8Array[] = [];
  const readonly: Uint8Array[] = [];
  for (const l of tx.lookups) {
    const addrs = resolve(l.table);
    if (!addrs) return undefined;
    for (const i of l.writable) {
      const a = addrs[i];
      if (!a) return undefined;
      writable.push(a);
    }
    for (const i of l.readonly) {
      const a = addrs[i];
      if (!a) return undefined;
      readonly.push(a);
    }
  }
  return [...tx.staticKeys, ...writable, ...readonly];
}
