/**
 * Decoder for the shredstream proxy's `Entry.entries` bytes: a bincode
 * `Vec<solana_entry::Entry>` (fixint, little-endian):
 *
 *   u64 count, then per entry:
 *     u64 num_hashes, [u8;32] hash, u64 tx count, tx count × VersionedTransaction
 *
 * A VersionedTransaction's bincode form is the wire format (short_vec
 * lengths), so each transaction is returned as its raw bytes, ready for
 * VersionedTransaction.deserialize. Its length is found by walking the
 * wire layout — bincode does not prefix it.
 */

export interface DecodedEntry {
  numHashes: bigint;
  hash: Uint8Array;
  /** Raw wire bytes of each transaction, in block order. */
  txs: Uint8Array[];
}

class Reader {
  constructor(
    readonly buf: Uint8Array,
    public off = 0,
  ) {}

  need(n: number): void {
    if (this.off + n > this.buf.length) throw new Error(`entries truncated at ${this.off} (+${n})`);
  }

  u8(): number {
    this.need(1);
    return this.buf[this.off++]!;
  }

  u64(): bigint {
    this.need(8);
    const v = new DataView(this.buf.buffer, this.buf.byteOffset + this.off, 8).getBigUint64(0, true);
    this.off += 8;
    return v;
  }

  bytes(n: number): Uint8Array {
    this.need(n);
    const out = this.buf.subarray(this.off, this.off + n);
    this.off += n;
    return out;
  }

  skip(n: number): void {
    this.need(n);
    this.off += n;
  }

  /** compact-u16 ("short_vec" length). */
  shortVec(): number {
    let len = 0;
    for (let i = 0; i < 3; i++) {
      const b = this.u8();
      len |= (b & 0x7f) << (7 * i);
      if ((b & 0x80) === 0) return len;
    }
    throw new Error("bad short_vec");
  }
}

/** Version byte of a v1 transaction (SIMD-0385), at offset 0. */
export const TX_V1 = 0x81;

/**
 * v1 (SIMD-0385, live on mainnet since epoch 1035): version byte FIRST,
 * signatures LAST, no lookup tables, fixed-width headers:
 *   u8 version(129) | u8,u8,u8 header | u32 configMask | [32] lifetime |
 *   u8 numInstructions | u8 numAddresses | numAddresses×[32] |
 *   popcount(configMask)×[4] configValues |
 *   numInstructions×(u8 programIndex, u8 numAccounts, u16 dataLen) |
 *   per instruction: accounts bytes + data bytes | numRequiredSignatures×[64]
 * About 8% of a mainnet block in October 2026 — and web3.js cannot read them.
 */
function txLengthV1(r: Reader, start: number): number {
  r.skip(1); // version
  const numSigs = r.u8();
  r.skip(2); // rest of the legacy header
  r.need(4);
  const mask = new DataView(r.buf.buffer, r.buf.byteOffset + r.off, 4).getUint32(0, true);
  r.skip(4);
  r.skip(32); // lifetime specifier (blockhash)
  const nIx = r.u8();
  const nAddr = r.u8();
  r.skip(32 * nAddr);
  let bits = 0;
  for (let m = mask; m; m &= m - 1) bits++;
  r.skip(4 * bits); // config values
  let payload = 0;
  for (let i = 0; i < nIx; i++) {
    r.skip(1); // program index
    const nAcc = r.u8();
    r.need(2);
    const dataLen = r.buf[r.off]! | (r.buf[r.off + 1]! << 8);
    r.skip(2);
    payload += nAcc + dataLen;
  }
  r.skip(payload);
  r.skip(64 * numSigs);
  return r.off - start;
}

/** Walk one wire-format transaction (legacy, v0 or v1) and return its byte length. */
export function txLength(buf: Uint8Array, start = 0): number {
  const r = new Reader(buf, start);
  // Legacy/v0 start with the signature count (short_vec, always < 128
  // signatures); v1 starts with its version byte.
  if (buf[start] === TX_V1) return txLengthV1(r, start);
  r.skip(64 * r.shortVec()); // signatures
  const first = r.buf[r.off];
  if (first === undefined) throw new Error("tx truncated");
  const versioned = (first & 0x80) !== 0;
  if (versioned) r.skip(1); // version prefix
  r.skip(3); // header
  r.skip(32 * r.shortVec()); // static account keys
  r.skip(32); // recent blockhash
  const nIx = r.shortVec();
  for (let i = 0; i < nIx; i++) {
    r.skip(1); // program id index
    r.skip(r.shortVec()); // account indexes
    r.skip(r.shortVec()); // data
  }
  if (versioned) {
    const nLookups = r.shortVec();
    for (let i = 0; i < nLookups; i++) {
      r.skip(32);
      r.skip(r.shortVec()); // writable indexes
      r.skip(r.shortVec()); // readonly indexes
    }
  }
  return r.off - start;
}

export function decodeEntries(buf: Uint8Array): DecodedEntry[] {
  const r = new Reader(buf);
  const count = Number(r.u64());
  if (count > 100_000) throw new Error(`implausible entry count ${count}`);
  const out: DecodedEntry[] = [];
  for (let e = 0; e < count; e++) {
    const numHashes = r.u64();
    const hash = r.bytes(32);
    const nTx = Number(r.u64());
    if (nTx > 100_000) throw new Error(`implausible tx count ${nTx}`);
    const txs: Uint8Array[] = [];
    for (let t = 0; t < nTx; t++) {
      const len = txLength(r.buf, r.off);
      txs.push(r.bytes(len));
    }
    out.push({ numHashes, hash, txs });
  }
  // Deshredded payloads end in zero padding (measured on the AllenHark feed
  // 2026-10-14: 26 of 28 "trailing" payloads were all zeros after the
  // entries); bincode on the proxy side ignores it. Anything else is not
  // padding and the payload is refused.
  for (let i = r.off; i < buf.length; i++) {
    if (buf[i] !== 0) throw new Error(`entries: ${buf.length - r.off} trailing bytes`);
  }
  return out;
}

/** Inverse of decodeEntries (tests / fixtures). */
export function encodeEntries(entries: DecodedEntry[]): Uint8Array {
  const parts: Uint8Array[] = [];
  const u64 = (v: bigint | number) => {
    const b = new Uint8Array(8);
    new DataView(b.buffer).setBigUint64(0, BigInt(v), true);
    return b;
  };
  parts.push(u64(entries.length));
  for (const e of entries) {
    parts.push(u64(e.numHashes), e.hash, u64(e.txs.length), ...e.txs);
  }
  const total = parts.reduce((n, p) => n + p.length, 0);
  const out = new Uint8Array(total);
  let off = 0;
  for (const p of parts) {
    out.set(p, off);
    off += p.length;
  }
  return out;
}
