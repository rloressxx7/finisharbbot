/**
 * AllenHark "Jito Shreds" feed: transactions BEFORE they execute, so a trade
 * on one of the bot's pools is seen about a slot earlier than the gRPC /
 * pumpapi streams report it.
 *
 * Setup (not on the home PC: the home line is CGNAT, UDP shreds cannot reach
 * it). A Frankfurt VPS runs jito-shredstream-proxy against
 * https://fra.jito.allenhark.network with the auth keypair AllenHark
 * whitelisted, plus --grpc-service-port; the bot connects to
 *   SHRED_GRPC_URL=http://<vps-ip>:<grpc-port>
 * (shredstream.ShredstreamProxy/SubscribeEntries). Unset = feed off.
 *
 * Pipeline: entries (bincode) -> raw txs -> static program prefilter (an
 * invoked program id is always a static key) -> lookup tables resolved from a
 * cache (misses fetched in the background, tx skipped this time) -> tracked
 * pool keys -> onPendingTrade. Top-level PumpSwap buy/sell/buy_exact_quote_in
 * swaps are decoded too, so the bot can apply them to the pool's reserves.
 * Keys are compared as 32-byte latin1 strings: no base58 on the hot path.
 *
 * Known limits (measured 2026-10-14 on the AllenHark trial): the proxy drops
 * entry batches that contain v1 transactions (~25%); swaps routed through
 * another program (Jupiter, arb bots) are detected but not decoded.
 */
import bs58 from "bs58";
import { AddressLookupTableAccount, Connection, PublicKey } from "@solana/web3.js";
import { subscribeEntries } from "./grpc";
import { decodeEntries } from "./entries";
import { accountKeys, parseTx, ParsedInstruction, ParsedTx } from "./tx-parse";
import { logger } from "../utils/logger";

/** Programs whose transactions can move the pools the bot prices. */
const TRADE_PROGRAMS = [
  "pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA", // PumpSwap
  "LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo", // Meteora DLMM
  "cpamdpZCGKUy5JxQXB4dcpGPiikHawvSWAd6mEn1sGG", // Meteora DAMM v2
  "675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8", // Raydium AMM v4
  "CPMMoo8L3F4NbTegBCKVNunggL7H1ZpdTHKxQB5qKP1C", // Raydium CPMM
  "CAMMCzo5YL8w4VFF8KVHrK22GGUsp5VTaW7grrKgrWqK", // Raydium CLMM
  "whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc", // Orca Whirlpool
  "JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4", // Jupiter v6
  "proVF4pMXVaYqmy4NjniPh4pqKNfMmsihgd4wdkCX3u", // router seen on PumpSwap pools
];

const PUMPSWAP_DISC = {
  buy: Buffer.from([102, 6, 61, 18, 1, 218, 235, 234]),
  sell: Buffer.from([51, 230, 133, 164, 1, 127, 131, 173]),
  buyExactQuoteIn: Buffer.from([198, 46, 21, 82, 180, 217, 232, 112]),
};

export type PumpSwapKind = "buy" | "sell" | "buyExactQuoteIn";

export interface PendingPumpSwap {
  kind: PumpSwapKind;
  /** buy: base_amount_out · sell: base_amount_in · buyExactQuoteIn: spendable_quote_in */
  amount: bigint;
  baseMint: string;
  quoteMint: string;
}

export interface PendingPoolTrade {
  signature: string;
  slot: bigint;
  /** Tracked pool address (base58). */
  pool: string;
  /** Set when the tx holds exactly one top-level PumpSwap swap on this pool. */
  pumpSwap?: PendingPumpSwap;
  receivedAt: number;
  /** The pending transaction's wire bytes (for a backrun bundle). */
  raw: Uint8Array;
  /** It calls the SolanaMevBot executor itself (a competing arb, not a target). */
  isSmbCall: boolean;
}

export interface ShredFeedOptions {
  url: string;
  /** Used only to fetch lookup tables. */
  connection: Connection;
  onPendingTrade: (t: PendingPoolTrade) => void;
}

export const shredStats = {
  connected: false,
  messages: 0,
  txs: 0,
  dexTxs: 0,
  hits: 0,
  pumpSwapDecoded: 0,
  altMiss: 0,
  altFetched: 0,
  decodeFail: 0,
  parseFail: 0,
  reconnects: 0,
  lastSlot: BigInt(0),
};

const keyId = (k: Uint8Array | PublicKey): string =>
  Buffer.from(k instanceof PublicKey ? k.toBytes() : k).toString("latin1");

const programs = new Set(TRADE_PROGRAMS.map((p) => keyId(new PublicKey(p))));
const pumpSwapId = keyId(new PublicKey("pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA"));
const smbId = keyId(new PublicKey("MEViEnscUm6tsQRoGd9h6nLQaQspKj7DB2M5FwM3Xvz"));

/** latin1 key -> base58 pool address. Replaced whenever the pool set changes. */
let tracked = new Map<string, string>();

export function setShredTrackedPools(pools: string[]): void {
  const next = new Map<string, string>();
  for (const p of pools) {
    try {
      next.set(keyId(new PublicKey(p)), p);
    } catch {
      /* not a pubkey */
    }
  }
  tracked = next;
}

/* ---------------- lookup tables ---------------- */

const alts = new Map<string, Uint8Array[]>();
const altWanted = new Set<string>();
const altRefetchAt = new Map<string, number>();
const ALT_CACHE_MAX = 20000;

function wantRefetch(tx: ParsedTx): void {
  const now = Date.now();
  for (const l of tx.lookups) {
    const id = keyId(l.table);
    if ((altRefetchAt.get(id) ?? 0) > now) continue;
    altRefetchAt.set(id, now + 10000);
    altWanted.add(id);
  }
}

async function loadWantedTables(connection: Connection): Promise<void> {
  if (!altWanted.size) return;
  const ids = [...altWanted].slice(0, 100);
  for (const id of ids) altWanted.delete(id);
  const keys = ids.map((id) => new PublicKey(Buffer.from(id, "latin1")));
  const infos = await connection.getMultipleAccountsInfo(keys, "confirmed");
  infos.forEach((info, i) => {
    let addrs: Uint8Array[] = [];
    if (info) {
      try {
        addrs = AddressLookupTableAccount.deserialize(info.data).addresses.map((a) => a.toBytes());
      } catch {
        /* not a lookup table */
      }
    }
    alts.set(ids[i], addrs);
    shredStats.altFetched++;
  });
  if (alts.size > ALT_CACHE_MAX) {
    const drop = alts.size - ALT_CACHE_MAX;
    let n = 0;
    for (const k of alts.keys()) {
      if (n++ >= drop) break;
      alts.delete(k);
    }
  }
}

/* ---------------- lead time vs the confirmed streams ---------------- */

const pendingSeenAt = new Map<string, number>();
const leads: number[] = [];

/** Call with every signature the gRPC / pumpapi streams report. */
export function noteStreamedSignature(signature: string): void {
  const at = pendingSeenAt.get(signature);
  if (at === undefined) return;
  pendingSeenAt.delete(signature);
  leads.push(performance.now() - at);
  if (leads.length > 500) leads.shift();
}

function leadP50(): number | null {
  if (!leads.length) return null;
  const s = [...leads].sort((a, b) => a - b);
  return Math.round(s[Math.floor(s.length / 2)]);
}

/* ---------------- decoding ---------------- */

function decodePumpSwap(ix: ParsedInstruction, keys: Uint8Array[]): (PendingPumpSwap & { poolId: string }) | undefined {
  const d = Buffer.from(ix.data);
  if (d.length < 24 || ix.accounts.length < 9) return undefined;
  const head = d.subarray(0, 8);
  const kind: PumpSwapKind | null = head.equals(PUMPSWAP_DISC.buy)
    ? "buy"
    : head.equals(PUMPSWAP_DISC.sell)
      ? "sell"
      : head.equals(PUMPSWAP_DISC.buyExactQuoteIn)
        ? "buyExactQuoteIn"
        : null;
  if (!kind) return undefined;
  // Accounts: pool 0, user 1, global_config 2, base_mint 3, quote_mint 4, ...
  const pool = keys[ix.accounts[0]];
  const baseMint = keys[ix.accounts[3]];
  const quoteMint = keys[ix.accounts[4]];
  if (!pool || !baseMint || !quoteMint) return undefined;
  return {
    poolId: keyId(pool),
    kind,
    amount: d.readBigUInt64LE(8),
    baseMint: bs58.encode(baseMint),
    quoteMint: bs58.encode(quoteMint),
  };
}

function onEntries(slot: bigint, bytes: Uint8Array, receivedAt: number, onTrade: (t: PendingPoolTrade) => void): void {
  let entries;
  try {
    entries = decodeEntries(bytes);
  } catch {
    shredStats.decodeFail++;
    return;
  }
  for (const e of entries) {
    for (const raw of e.txs) {
      shredStats.txs++;
      let tx: ParsedTx;
      try {
        tx = parseTx(raw);
      } catch {
        shredStats.parseFail++;
        continue;
      }
      let dex = false;
      for (const ix of tx.instructions) {
        const p = tx.staticKeys[ix.programIndex];
        if (p && programs.has(keyId(p))) {
          dex = true;
          break;
        }
      }
      if (!dex) continue;
      shredStats.dexTxs++;
      let missing = false;
      const keys = accountKeys(tx, (t) => {
        const hit = alts.get(keyId(t));
        if (!hit) {
          missing = true;
          altWanted.add(keyId(t));
        }
        return hit;
      });
      if (!keys) {
        shredStats.altMiss++;
        // All tables cached but an index fell outside: a table was extended.
        if (!missing) wantRefetch(tx);
        continue;
      }
      const hitPools = new Set<string>();
      for (const k of keys) {
        const p = tracked.get(keyId(k));
        if (p) hitPools.add(p);
      }
      if (!hitPools.size) continue;

      // Top-level PumpSwap swaps on tracked pools; two on one pool = ambiguous.
      const swaps = new Map<string, PendingPumpSwap | null>();
      for (const ix of tx.instructions) {
        const p = tx.staticKeys[ix.programIndex];
        if (!p || keyId(p) !== pumpSwapId) continue;
        const s = decodePumpSwap(ix, keys);
        if (!s) continue;
        const pool = tracked.get(s.poolId);
        if (!pool) continue;
        swaps.set(pool, swaps.has(pool) ? null : { kind: s.kind, amount: s.amount, baseMint: s.baseMint, quoteMint: s.quoteMint });
      }

      const signature = bs58.encode(tx.signature);
      let isSmbCall = false;
      for (const ix of tx.instructions) {
        const p = tx.staticKeys[ix.programIndex];
        if (p && keyId(p) === smbId) isSmbCall = true;
      }
      pendingSeenAt.set(signature, receivedAt);
      if (pendingSeenAt.size > 20000) {
        const first = pendingSeenAt.keys().next().value;
        if (first !== undefined) pendingSeenAt.delete(first);
      }
      for (const pool of hitPools) {
        shredStats.hits++;
        const pumpSwap = swaps.get(pool) ?? undefined;
        if (pumpSwap) shredStats.pumpSwapDecoded++;
        onTrade({ signature, slot, pool, pumpSwap, receivedAt, raw, isSmbCall });
      }
    }
  }
}

/* ---------------- connection ---------------- */

export function startShredFeed(opts: ShredFeedOptions): void {
  let delayMs = 1000;
  let lastMessageAt = 0;

  const connect = () => {
    logger.info(`Connecting to shred proxy (SubscribeEntries): ${opts.url}`);
    subscribeEntries(
      opts.url,
      (m) => {
        if (!shredStats.connected) {
          shredStats.connected = true;
          delayMs = 1000;
          logger.info("shred feed live");
        }
        shredStats.messages++;
        shredStats.lastSlot = m.slot;
        lastMessageAt = Date.now();
        onEntries(m.slot, m.entries, m.receivedAt, opts.onPendingTrade);
      },
      (err) => {
        shredStats.connected = false;
        shredStats.reconnects++;
        logger.warn(`shred feed ended${err ? `: ${err.message}` : ""}; reconnecting in ${delayMs} ms`);
        setTimeout(connect, delayMs);
        delayMs = Math.min(30000, Math.floor(delayMs * 1.6));
      },
    );
  };
  connect();

  let altBusy = false;
  setInterval(() => {
    if (altBusy || !altWanted.size) return;
    altBusy = true;
    loadWantedTables(opts.connection)
      .catch((e) => logger.warn(`shred ALT fetch failed: ${String(e).slice(0, 120)}`))
      .finally(() => {
        altBusy = false;
      });
  }, Number(process.env.SHRED_ALT_FETCH_MS || 400));

  setInterval(() => {
    const silent = lastMessageAt ? Math.round((Date.now() - lastMessageAt) / 1000) : null;
    logger.info(
      `shred feed: connected=${shredStats.connected} msgs=${shredStats.messages} slot=${shredStats.lastSlot} ` +
        `txs=${shredStats.txs} dexTxs=${shredStats.dexTxs} poolHits=${shredStats.hits} pumpSwapDecoded=${shredStats.pumpSwapDecoded} ` +
        `altMiss=${shredStats.altMiss} altCached=${alts.size} leadP50ms=${leadP50()} (n=${leads.length})` +
        (silent !== null && silent > 30 ? ` SILENT ${silent}s (proxy has no shreds? AllenHark subscription/trial?)` : ""),
    );
  }, 30000);
}
