/**
 * Requests-per-second cap for HTTP RPC calls. Helius answers bursts above the
 * plan limit with 429 and web3.js then sleeps 500 ms+ per retry, which is far
 * slower than simply pacing the calls. Each process (main, worker) has its own
 * bucket, so their RPS values add up against the plan limit.
 */
export function createRateLimitedFetch(rps: number): typeof fetch {
  const intervalMs = 1000 / Math.max(1, rps);
  let nextSlot = 0;
  const limited = async (input: any, init?: any) => {
    const now = Date.now();
    const slot = Math.max(now, nextSlot);
    nextSlot = slot + intervalMs;
    if (slot > now) await new Promise((r) => setTimeout(r, slot - now));
    return fetch(input, init);
  };
  return limited as typeof fetch;
}
