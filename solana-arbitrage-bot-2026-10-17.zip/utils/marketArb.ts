/**
 * Market-wide arbitrage detector on the pumpapi stream (no RPC): every
 * landed transaction that bought AND sold the same mint on two different
 * SOL-quoted pools, and left its signer with more SOL+WSOL than before (fee
 * included), is a profitable arbitrage — whatever program or bot sent it.
 *
 * pumpapi sends one event per pool leg, all carrying the tx signature, the
 * signer (`txSigner`) and the signer's pre/post SOL, WSOL and mint balances,
 * so a short per-signature buffer is enough to see the whole transaction.
 */
import { PumpApiEvent, isSolQuote } from "./pumpapi";

export interface MarketArb {
  signature: string;
  signer: string;
  mint: string;
  /** pumpapi pool ids of the legs (2+). */
  pools: string[];
  /** pumpapi venue names of the legs, same order. */
  venues: string[];
  /** Signer's SOL + WSOL change, lamports (after fee). */
  net: bigint;
  programs: string[];
  at: number;
}

export const marketArbStats = { txs: 0, cycles: 0, profitable: 0, lamports: BigInt(0) };

const WSOL = "So11111111111111111111111111111111111111112";
const FLUSH_MS = 1500;

type Bal = Record<string, { sol?: number } & Record<string, number | undefined>>;

const toLamports = (x: unknown) => BigInt(Math.round(Number(x ?? 0) * 1e9));

export function createMarketArbDetector(onArb: (a: MarketArb) => void) {
  const pending = new Map<string, { at: number; events: PumpApiEvent[] }>();

  const evaluate = (sig: string, events: PumpApiEvent[]) => {
    marketArbStats.txs++;
    const byMint = new Map<string, PumpApiEvent[]>();
    for (const e of events) {
      if (!e.mint || !e.poolId || !isSolQuote(e.quoteMint)) continue;
      const l = byMint.get(e.mint) ?? [];
      l.push(e);
      byMint.set(e.mint, l);
    }
    for (const [mint, legs] of byMint) {
      const pools = [...new Set(legs.map((e) => String(e.poolId)))];
      const acts = new Set(legs.map((e) => e.action));
      if (pools.length < 2 || !acts.has("buy") || !acts.has("sell")) continue;
      marketArbStats.cycles++;
      const first = legs[0]!;
      const signer = String(first.txSigner ?? "");
      const pre = (first.preBalances as Bal | undefined)?.[signer];
      const post = (first.postBalances as Bal | undefined)?.[signer];
      if (!signer || !pre || !post) continue;
      const net = toLamports(post.sol) + toLamports(post[WSOL]) - toLamports(pre.sol) - toLamports(pre[WSOL]);
      if (net <= BigInt(0)) continue;
      marketArbStats.profitable++;
      marketArbStats.lamports += net;
      onArb({
        signature: sig,
        signer,
        mint,
        pools,
        venues: pools.map((p) => String(legs.find((e) => String(e.poolId) === p)?.pool ?? "")),
        net,
        programs: Array.isArray(first.programsUsed) ? (first.programsUsed as string[]) : [],
        at: Number(first.timestamp ?? Date.now()),
      });
    }
  };

  setInterval(() => {
    const cutoff = Date.now() - FLUSH_MS;
    for (const [sig, p] of pending) {
      if (p.at > cutoff) continue;
      pending.delete(sig);
      evaluate(sig, p.events);
    }
  }, 500);

  /** Feed every buy/sell event. */
  return (ev: PumpApiEvent) => {
    if (ev.action !== "buy" && ev.action !== "sell") return;
    const sig = String(ev.signature ?? "");
    if (!sig) return;
    const p = pending.get(sig);
    if (p) p.events.push(ev);
    else pending.set(sig, { at: Date.now(), events: [ev] });
  };
}
