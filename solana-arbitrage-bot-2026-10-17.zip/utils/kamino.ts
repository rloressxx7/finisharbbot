/**
 * Kamino (KLend) flash loan: borrow WSOL with no collateral and repay it in
 * the SAME transaction. At repay the program pulls borrow + fee back out of
 * the user's WSOL account; if the swaps did not leave that much WSOL the
 * repay fails and the whole transaction reverts, so the borrowed SOL can
 * never be lost (only the fee of a landed failed tx; nothing for a dropped
 * Jito bundle).
 *
 * Verified on mainnet 2026-10-03 and 2026-10-08 (solana-atomic-arb):
 *   program        KLend2g3cP87fffoy8q1mQqGKjrxjC8boSyAYavgmjD
 *   flash_borrow   87e734a70734d4c1   data = disc + amount u64
 *   flash_repay    b97500cb60f5b4ba   data = disc + amount u64 + borrow_ix_index u8
 *   main market SOL reserve: mint@128, supply_vault@160, fee_vault@192,
 *   total_available_amount@224 (u64). Measured fee 0.1 bps, linear.
 * Rules (flash_ixs.rs): borrow and repay carry byte-identical account lists,
 * repay amount == borrow amount (the fee is pulled on top), no other KLend
 * instruction between them, top-level only (no CPI), one borrow per tx.
 *
 * ALT 8ukeuaWQvvsgfa8NCX6Ey8Li3fxsKxN1z7f5x99fm975 (owned by the bot wallet)
 * holds every account below, so the flash pair costs ~24 bytes of tx size.
 */
import { Connection, PublicKey, TransactionInstruction } from "@solana/web3.js";
import { NATIVE_MINT, TOKEN_PROGRAM_ID } from "@solana/spl-token";

export const KLEND_PROGRAM = new PublicKey("KLend2g3cP87fffoy8q1mQqGKjrxjC8boSyAYavgmjD");
export const KAMINO_LOOKUP_TABLE = new PublicKey("8ukeuaWQvvsgfa8NCX6Ey8Li3fxsKxN1z7f5x99fm975");
const FLASH_BORROW_DISC = Buffer.from("87e734a70734d4c1", "hex");
const FLASH_REPAY_DISC = Buffer.from("b97500cb60f5b4ba", "hex");
const SYSVAR_INSTRUCTIONS = new PublicKey("Sysvar1nstructions1111111111111111111111111");

export interface KaminoReserve {
  market: PublicKey;
  marketAuthority: PublicKey;
  reserve: PublicKey;
  liquidityMint: PublicKey;
  supplyVault: PublicKey;
  feeVault: PublicKey;
}

/** Kamino main market SOL reserve (every key checked on-chain). */
export const KAMINO_MAIN_SOL: KaminoReserve = {
  market: new PublicKey("7u3HeHxYDLhnCoErrtycNokbQYbWGzLs6JSDqGAv5PfF"),
  // PDA ["lma", market] under KLEND_PROGRAM, bump 248.
  marketAuthority: new PublicKey("9DrvZvyWh1HuAoZxvYWMvkf2XCzryCpGgHqrMjyDWpmo"),
  reserve: new PublicKey("d4A2prbA2whesmvHaL88BH6Ewn5N4bTSU2Ze8P6Bc4Q"),
  liquidityMint: NATIVE_MINT,
  supplyVault: new PublicKey("GafNuUXj9rxGLn4y79dPu6MHSuPWeJR6UtTWuexpGh3U"),
  feeVault: new PublicKey("3JNof8s453bwG5UqiXBLJc77NRQXezYYEBbk3fqnoKph"),
};

// Optional referrer accounts are None: Anchor takes the program id as the
// placeholder for an omitted optional account.
function flashAccounts(r: KaminoReserve, userWsolAta: PublicKey, user: PublicKey) {
  const k = (pubkey: PublicKey, isWritable: boolean, isSigner = false) => ({ pubkey, isSigner, isWritable });
  return [
    k(user, false, true), // user_transfer_authority
    k(r.marketAuthority, false), // lending_market_authority (PDA)
    k(r.market, false), // lending_market
    k(r.reserve, true), // reserve
    k(r.liquidityMint, false), // reserve_liquidity_mint
    k(r.supplyVault, true), // reserve supply vault
    k(userWsolAta, true), // user WSOL ATA
    k(r.feeVault, true), // reserve fee receiver
    k(KLEND_PROGRAM, false), // referrer_token_state = None
    k(KLEND_PROGRAM, false), // referrer_account = None
    k(SYSVAR_INSTRUCTIONS, false),
    k(TOKEN_PROGRAM_ID, false),
  ];
}

export function flashBorrowIx(
  userWsolAta: PublicKey,
  user: PublicKey,
  amount: bigint,
  r: KaminoReserve = KAMINO_MAIN_SOL,
): TransactionInstruction {
  const data = Buffer.alloc(16);
  FLASH_BORROW_DISC.copy(data, 0);
  data.writeBigUInt64LE(amount, 8);
  return new TransactionInstruction({ programId: KLEND_PROGRAM, keys: flashAccounts(r, userWsolAta, user), data });
}

/** amount MUST equal the borrowed amount; borrowIxIndex = the borrow's position in the tx. */
export function flashRepayIx(
  userWsolAta: PublicKey,
  user: PublicKey,
  amount: bigint,
  borrowIxIndex: number,
  r: KaminoReserve = KAMINO_MAIN_SOL,
): TransactionInstruction {
  const data = Buffer.alloc(17);
  FLASH_REPAY_DISC.copy(data, 0);
  data.writeBigUInt64LE(amount, 8);
  data.writeUInt8(borrowIxIndex, 16);
  return new TransactionInstruction({ programId: KLEND_PROGRAM, keys: flashAccounts(r, userWsolAta, user), data });
}

/**
 * Flash fee, rounded UP. feeBps may be fractional (main SOL reserve = 0.1).
 * Over-estimating is safe (the surplus stays as profit); under-estimating only
 * makes the repay fail, which reverts the whole tx.
 */
export function flashFee(amount: bigint, feeBps: number): bigint {
  if (feeBps <= 0 || amount <= BigInt(0)) return BigInt(0);
  const microBps = BigInt(Math.round(feeBps * 1000));
  const fee = (amount * microBps + BigInt(9_999_999)) / BigInt(10_000_000);
  return fee < BigInt(1) ? BigInt(1) : fee;
}

export interface ReserveState {
  ok: boolean;
  available: bigint;
  reason?: string;
  at: number;
}

let reserveCache: ReserveState | null = null;

/** Live borrowable SOL in the reserve (lamports). Cached 15 s. */
export async function readKaminoReserve(connection: Connection, r: KaminoReserve = KAMINO_MAIN_SOL): Promise<ReserveState> {
  if (reserveCache && Date.now() - reserveCache.at < 15000) return reserveCache;
  try {
    const acc = await connection.getAccountInfo(r.reserve, "confirmed");
    if (!acc) {
      reserveCache = { ok: false, available: BigInt(0), reason: "reserve missing", at: Date.now() };
    } else if (!acc.owner.equals(KLEND_PROGRAM)) {
      reserveCache = { ok: false, available: BigInt(0), reason: "reserve owner != KLend", at: Date.now() };
    } else if (!new PublicKey(acc.data.subarray(128, 160)).equals(r.liquidityMint)) {
      reserveCache = { ok: false, available: BigInt(0), reason: "reserve mint != WSOL", at: Date.now() };
    } else {
      reserveCache = { ok: true, available: acc.data.readBigUInt64LE(224), at: Date.now() };
    }
  } catch (e) {
    // Keep the last good value on a transient RPC error.
    if (reserveCache?.ok) return reserveCache;
    reserveCache = { ok: false, available: BigInt(0), reason: String(e).slice(0, 120), at: Date.now() };
  }
  return reserveCache;
}
