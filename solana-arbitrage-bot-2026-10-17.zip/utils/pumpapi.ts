/**
 * pumpapi.io data stream (replaces PumpPortal). Data only: no key, no trading.
 *
 * - No subscribe message: the server pushes every event (~650 trades/s).
 * - Frames are binary JSON (`ws` hands us a Buffer); one event per frame,
 *   sometimes an array.
 * - pumpapi allows ONE socket per IP: a second process on the same machine
 *   (another bot, a test script) kicks this one and both reconnect in a loop.
 *
 * Event shapes measured 2026-10-17 (45 s census): action = buy | sell | add |
 * remove | create | migrate | createPool | transfer | leaders | distributeFees.
 * Pool events carry mint, poolId, pool (venue), quoteMint, tokensInPool,
 * quoteInPool (UI units), price (quote per token, UI units), poolFeeRate
 * (fraction), decimals, signature.
 */
import WebSocket from "ws";
import { logger } from "./logger";

export const PUMPAPI_STREAM_URL = process.env.PUMPAPI_STREAM_URL?.trim() || "wss://stream.pumpapi.io/";
const STALL_MS = Number(process.env.PUMPAPI_STALL_MS || 60000);

const SOL_QUOTES = new Set([
  "So11111111111111111111111111111111111111112",
  "So11111111111111111111111111111111111111111",
]);
const TICK_ACTIONS = new Set(["buy", "sell", "add", "remove"]);

export interface PumpApiEvent {
  action?: string;
  txType?: string;
  signature?: string;
  mint?: string;
  poolId?: string;
  pool?: string;
  quoteMint?: string;
  tokensInPool?: number;
  quoteInPool?: number;
  price?: number;
  poolFeeRate?: number;
  decimals?: number;
  poolCreatedBy?: string;
  [k: string]: unknown;
}

export interface PumpApiHandlers {
  /** A token migrated / graduated into a SOL pool. */
  onMigrate?: (ev: PumpApiEvent) => void;
  /** A buy/sell/add/remove on a SOL-quoted pool. */
  onPoolTick?: (ev: PumpApiEvent) => void;
  /** Every event, before filtering. */
  onEvent?: (ev: PumpApiEvent) => void;
}

export const pumpApiStats = {
  connected: false,
  events: 0,
  ticks: 0,
  migrations: 0,
  parseFail: 0,
  reconnects: 0,
};

export function isSolQuote(mint: unknown): boolean {
  return typeof mint === "string" && SOL_QUOTES.has(mint);
}

function frameText(data: WebSocket.RawData): string {
  if (Buffer.isBuffer(data)) return data.toString("utf8");
  if (Array.isArray(data)) return Buffer.concat(data).toString("utf8");
  return Buffer.from(data as ArrayBuffer).toString("utf8");
}

export function startPumpApiStream(h: PumpApiHandlers): void {
  let delayMs = 1000;
  let lastEventAt = Date.now();
  let socket: WebSocket | null = null;

  const scheduleReconnect = () => {
    pumpApiStats.reconnects++;
    setTimeout(connect, delayMs);
    delayMs = Math.min(30000, Math.floor(delayMs * 1.6));
  };

  const connect = () => {
    logger.info(`Connecting to pumpapi stream: ${PUMPAPI_STREAM_URL}`);
    let ws: WebSocket;
    try {
      ws = new WebSocket(PUMPAPI_STREAM_URL);
    } catch (e) {
      logger.error(`pumpapi stream connect threw: ${e}`);
      scheduleReconnect();
      return;
    }
    socket = ws;
    ws.on("open", () => {
      delayMs = 1000;
      lastEventAt = Date.now();
      pumpApiStats.connected = true;
      logger.info("pumpapi stream connected (migrate + pool ticks)");
    });
    ws.on("message", (data: WebSocket.RawData) => {
      lastEventAt = Date.now();
      let json: unknown;
      try {
        json = JSON.parse(frameText(data));
      } catch {
        pumpApiStats.parseFail++;
        return;
      }
      const list = Array.isArray(json) ? json : [json];
      for (const item of list) {
        if (!item || typeof item !== "object") continue;
        pumpApiStats.events++;
        const ev = item as PumpApiEvent;
        const action = String(ev.action ?? ev.txType ?? "");
        try {
          h.onEvent?.(ev);
          if (action === "migrate") {
            pumpApiStats.migrations++;
            h.onMigrate?.(ev);
          } else if (TICK_ACTIONS.has(action) && ev.poolId && isSolQuote(ev.quoteMint)) {
            pumpApiStats.ticks++;
            h.onPoolTick?.(ev);
          }
        } catch (e) {
          logger.error(`pumpapi handler error (${action}): ${e}`);
        }
      }
    });
    ws.on("close", (code: number) => {
      pumpApiStats.connected = false;
      logger.warn(`pumpapi stream closed (code ${code}), reconnecting in ${delayMs} ms`);
      scheduleReconnect();
    });
    ws.on("error", (err: Error) => {
      logger.error(`pumpapi stream error: ${err.message}`);
      // 'close' follows and schedules the reconnect.
    });
  };

  connect();

  // A socket that stays open but goes silent never fires 'close'.
  setInterval(() => {
    if (socket && pumpApiStats.connected && Date.now() - lastEventAt > STALL_MS) {
      logger.warn(`pumpapi stream silent for ${STALL_MS} ms, forcing reconnect`);
      socket.terminate();
    }
  }, 10000);
}
