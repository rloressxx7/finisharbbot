🧭 Solana arbitrage bot
- Solana arbitrage bot detect price differences between several dexes such as pumpswap, raydium, meteora, orca and make profit.
The purpose of this bot is to build token selection module, price calculation module, arbitrage opportunity detection module and swap module.
---
🧩 About
- This project provide several arbitrage modules and core smart contract for trying 2-hop, 3-hop, 4-hop swaps.
---
tip
- (🌟🌟🌟click and signup! so your polymarket account will be boosted instantly)<a href="https://polymarket.com/?r=cryptoking1106">
<img width="277" height="45" alt="image" src="https://github.com/user-attachments/assets/06fc93ff-82b6-4199-b285-e11117fa0dea" />

---
✨ Features
- Dynamic token selection module
 Bot update token list for arbitrage in real time for trending tokens.
- Multi hop smart contract.
 Smart contract has been optimzized for multi hop swaps by reducing transaction size using address lookup table.
- Several dexes support
 Bot currently work with 7 dexes, pumpswap, raydium amm v4, raydium clmm, raydium cpmm, orca whirlpool, meteora damm v2, meteora dlmm.
- Fast transaction building and sending method.
 For sending transaction asap, bot cache all available data and directly stream acount from geyser grpc.
- Address lookup tables
 I already configured address lookup table with the addresses in alts.txt of root directory
 If you want your own ALT, replace addresses in alts.txt and use createALT function of utils.ts
---
🧠 Tech Stack
- Languages:  JavaScript, TypeScript
- Frameworks: Node.js
- ools:   VS code, github
---
⚙️ Installation
#### Clone the repository
- git clone https://github.com/katlogic/solana-arbitrage-bot.git

#### Navigate to the project directory
- cd solana_arbitrage_bot

#### Install dependencies
- npm install  
---
🚀 Usage
#### Start the development server
- npm start  
---
🧾 Configuration
### Replace .env.example file with a .env file and set following environment variables
- PRIVATE_KEY=
- COMMITMENT_LEVEL=
- RPC_ENDPOINT=   //For rpc calls
- SWQOS_ENDPOINT=   //For sending transactions
- GRPC_ENDPOINT=
- API_KEY=
- QUOTE_AMOUNT=
- SLIPPAGE=
- BLOCK_ENGINE_URL=
- ISJITO=   //If true, send tx via jito, if not , send tx via swqos

After setting environment variables, create a tokens.txt file of root directory of project and list initial tokens for arbitrage.
---
🖼 Screenshots
![Arbitrage testing results](https://azure-legal-macaw-413.mypinata.cloud/ipfs/bafkreihpxbndcnkkpy7k7r4k34pah4lzmpot5bkssuvckki7dn67wc3cti)
![Arbitrage testing rssults](https://azure-legal-macaw-413.mypinata.cloud/ipfs/bafkreidafhcqurlfqpot5vwx7k6skzoae43sd5ftssaszyoz7ybiuapk7i)

Arbitrage program
- https://solscan.io/account/6UZznePGgoykwAutgJFmQce2QQzfYjVcsQesZbRq9Y3b
---
☎️ Contact
- GitHub:    https://github.com/katlogic/
---
🌟 Acknowledgements
### Used libraries
- "@meteora-ag/cp-amm-sdk": "^1.3.2",
- "@meteora-ag/dlmm": "^1.9.3",
- "@meteora-sdk/core": "^1.4.6",
- "@orca-so/whirlpools-sdk": "^0.17.4",
- "@pump-fun/pump-sdk": "^1.3.4",
- "@pump-fun/pump-swap-sdk": "^0.0.1-beta.52",
- "@raydium-io/raydium-sdk": "^1.3.1-beta.47",
- "@raydium-io/raydium-sdk-v2": "^0.2.2-alpha",
- "@shyft-to/solana-transaction-parser": "^2.0.1",
- "@solana/signers": "^2.3.0",
- "@solana/spl-token": "^0.4.0",
- "@solana/spl-token-metadata": "^0.1.6",
- "@solana/web3.js": "^1.89.1",
- "@supercharge/queue-datastructure": "^2.1.0",
- "@triton-one/yellowstone-grpc": "^4.0.0",
---
🔎 Furture development
- Flashloan integration
 Currently the maximum trade amount is about 5k for big pools.
 If you have enough funds, you can use this bot without any problem.
 For customers who don't have enough funds, will try flashloan.
- Tip optimization
 Currently tip is static. For the best performance, I am going to optimize fee and tip setting.

This bot is beta version , so can make small profit, but can't expect big profit.
If you want more profit, please feel free to reach out me.


---
📖 How to use.
- Setup environments variable such as private key, rpc, grpc urls
- Add token mints addresses you want in tokens.txt of project root directory.

## 2026-10-17 changes (pumpapi, Kamino, shreds, rate limits)

- **Signal source:** PumpPortal replaced by the pumpapi.io stream (`utils/pumpapi.ts`). Migrations add tokens; pool ticks reprice tracked pools; with `AUTO_DISCOVER=true` any mint seen on 2+ pools is looked up and tracked.
- **Kamino flash loan:** each arb tx becomes `borrow -> arb -> repay` from the KLend main SOL reserve (`utils/kamino.ts`). A failed repay reverts the whole tx.
- **Shreds (AllenHark Jito shreds):** set `SHRED_GRPC_URL=http://<vps>:<port>` (a jito-shredstream-proxy on a VPS; UDP cannot reach a home CGNAT line). Unset = off.
- **Safety:** nothing is sent unless `DRY_RUN=false` AND the arb program is deployed. `minimumFinalOutput` = amount + tx fee + tip + flash fee + MINIMUM_PROFIT, so an expected loss is never sent. Startup no longer creates ATAs; the arb tx creates them idempotently.
- **RPC:** paced per process (`RPC_RPS_MAIN`, `RPC_RPS_WORKER`), GPA concurrency `GPA_CONCURRENCY`, 429 backoff.

Optional `.env` keys (defaults): `DRY_RUN=true`, `KAMINO_ENABLED=true`, `KAMINO_MAX_SOL=10`, `KAMINO_FEE_BPS=0.1`, `SHRED_GRPC_URL=`, `AUTO_DISCOVER=true`, `MAX_TRACKED_TOKENS=50`, `MAX_POOLS_PER_TOKEN=20`, `DISCOVER_INTERVAL_MS=5000`, `PUMPAPI_MIGRATE_MIN_SOL=5`, `RPC_RPS_MAIN=2`, `RPC_RPS_WORKER=4`, `GPA_CONCURRENCY=4`, `DEX_ACCOUNTS_REFRESH_MS=15000`, `PAIR_REFRESH_MS=1800000`, `CU_LIMIT=700000`, `CU_PRICE_MICROLAMPORTS=1000`, `SEND_COOLDOWN_MS=300`, `TELEGRAM_ALERT_MS=3000`, `STATS_MS=30000`.

### Executor: SolanaMevBot (MEViEnsc…) — `ARB_PROGRAM=smb` (default)

The original program 6UZzne… is closed on chain, so the bot now calls the SolanaMevBot executor `MEViEnscUm6tsQRoGd9h6nLQaQspKj7DB2M5FwM3Xvz` (V10, opcode 61) through `smb/` (ported from solana-atomic-arb, layout verified by simulation). The program sizes and routes on chain, uses its own flashloan (Kamino is not used on this path) and reverts with `Custom(1)` below our floor. The floor covers the program's ~11% share + tx fee + tip + rent of accounts the trade would create + `MINIMUM_PROFIT`.

- Every trade is simulated first (`SMB_SIM_FIRST=true`); in DRY mode one simulation per `SMB_DRY_SIM_MS` is run and logged as `[SMB dry]`.
- The program is closed source and upgradeable by its owner: the deploy slot seen at startup is pinned and re-checked every 5 min; if it changes, sending stops until you set `SMB_EXPECTED_DEPLOY_SLOT=<new slot>`.
- Live needs `DRY_RUN=false` and a wallet holding fee + rent + reserve (the bot refuses otherwise).
- `ARB_PROGRAM=legacy` restores the old path unchanged (it stays dry while 6UZzne is closed).

Keys: `ARB_PROGRAM=smb`, `SMB_SIM_FIRST=true`, `SMB_DRY_SIM=true`, `SMB_DRY_SIM_MS=3000`, `SMB_PRIORITY_LAMPORTS=10000`, `SMB_MAX_POOLS=4`, `SMB_PROGRAM_FEE_BPS=1100`, `SMB_EXPECTED_DEPLOY_SLOT=`, `SMB_SIM_WALLET=`, `RPC_RPS_SMB=3`.

### Hot routes (real-opportunity detection, `HOT_ROUTES=true`)

`smb/harvest.ts` reads the executor's own successful transactions and keeps the ones that ended with a net gain for their signer; their mint + pools become "hot routes". Every pumpapi (or shred) trade on a hot pool triggers a simulation of OUR executor transaction at the current state, so the program itself decides whether profit exists right now. Found profits are logged as `[REAL OPPORTUNITY]`, written to `opportunities.csv` and sent to Telegram; live mode sends the same simulated transaction.

Keys: `HOT_ROUTES=true`, `HARVEST_POLL_MS=10000`, `HARVEST_FIRST_LIMIT=300`, `HOT_SIM_MIN_MS=400`, `HOT_SIM_CONCURRENCY=2`, `HOT_ROUTE_TTL_MS=21600000`, `RPC_RPS_HARVEST=2`, `SMB_BASKET_TTL_MS=5000`, `HOT_LOG_ALL=false`.
Scripts (read-only): `npx ts-node scripts/harvest-check.ts 240`, `npx ts-node scripts/smb-one.ts <mint> <pool,pool>`.
