import dotenv from "dotenv";
import bs58 from "bs58";
import {
  Connection,
  Keypair,
  PublicKey,
  SystemProgram,
  VersionedTransaction,
  LAMPORTS_PER_SOL,
  AccountMeta,
  TransactionInstruction,
  ComputeBudgetProgram,
  AddressLookupTableAccount,
  TransactionMessage,
  sendAndConfirmRawTransaction,
  SIGNATURE_LENGTH_IN_BYTES,
} from "@solana/web3.js";
import fs from "fs";
import path from "path";
import { Worker } from "worker_threads";
import type { WorkerResult } from "./workers/getDexAccounts.worker";
dotenv.config();
import { RPC_ENDPOINT,SWQOS_ENDPOINT, PRIVATE_KEY , GRPC_ENDPOINT , API_KEY, COMMITMENT_LEVEL, QUOTE_AMOUNT, X_API_KEY, BLOCK_ENGINE_URL, ISJITO, MINIMUM_PROFIT} from "./constants/constants";

/** Set USE_DEX_ACCOUNTS_WORKER=false to run getDexAccounts on the main thread. */
const USE_DEX_ACCOUNTS_WORKER = process.env.USE_DEX_ACCOUNTS_WORKER !== "false";
let dexAccountsWorker: Worker | null = null;
let dexAccountsPendingResolve: ((value: WorkerResult) => void) | null = null;
let dexAccountsTimeoutId: ReturnType<typeof setTimeout> | null = null;
// One refresh in flight at a time: a 5 s timer over ~40 DLMM/CLMM pools used to
// queue runs faster than they finished and drive the RPC into 429s.
let dexAccountsBusy = false;
const DEX_ACCOUNTS_REFRESH_MS = Number(process.env.DEX_ACCOUNTS_REFRESH_MS ?? 15000);

function getDexAccountsWorker(): Worker | null {
  if (!USE_DEX_ACCOUNTS_WORKER) return null;
  if (dexAccountsWorker) return dexAccountsWorker;
  try {
    const workerPath = path.join(__dirname, "workers", "getDexAccounts.worker.ts");
    dexAccountsWorker = new Worker(workerPath, { execArgv: ["-r", "ts-node/register"] });
    dexAccountsWorker.on("message", (msg: WorkerResult) => {
      dexAccountsBusy = false;
      if (dexAccountsTimeoutId) clearTimeout(dexAccountsTimeoutId);
      dexAccountsTimeoutId = null;
      if (dexAccountsPendingResolve) {
        dexAccountsPendingResolve(msg);
        dexAccountsPendingResolve = null;
      } else {
        applyWorkerResults(msg);
      }
    });
    dexAccountsWorker.on("error", (err) => {
      logger.error(`getDexAccounts worker error: ${err}`);
      dexAccountsBusy = false;
      if (dexAccountsTimeoutId) clearTimeout(dexAccountsTimeoutId);
      dexAccountsTimeoutId = null;
      if (dexAccountsPendingResolve) {
        dexAccountsPendingResolve({ results: [] });
        dexAccountsPendingResolve = null;
      }
    });
  } catch (e) {
    logger.warn("Could not start getDexAccounts worker, falling back to main thread:");
  }
  return dexAccountsWorker;
}

function applyWorkerResults(msg: WorkerResult) {
  for (const r of msg.results) {
    if (r.accounts) pairAddress_accounts[r.accountKey] = r.accounts.map((s: string) => new PublicKey(s));
  }
}
import Client, { CommitmentLevel, SubscribeRequest } from '@triton-one/yellowstone-grpc';
import { delay, logger ,calculateSwapOutput,  PoolReserves, sendTelegramAlert} from "./utils";
import { createRateLimitedFetch } from "./utils/rpcLimiter";
import { smbTry, programDeploySlot, SMB_PROGRAM, type SmbSettings } from "./smb/execute";
import { startHarvester, harvestStats, startWalletHarvester, walletHarvestStats, type ProfitableCall } from "./smb/harvest";
import { createMarketArbDetector, marketArbStats } from "./utils/marketArb";
import { startPumpApiStream, isSolQuote, PumpApiEvent, pumpApiStats } from "./utils/pumpapi";
import { flashBorrowIx, flashRepayIx, flashFee, readKaminoReserve, KAMINO_LOOKUP_TABLE } from "./utils/kamino";
import { startShredFeed, setShredTrackedPools, noteStreamedSignature, PendingPoolTrade, shredStats } from "./shreds/feed";
import BN, { max, min } from "bn.js";
import { SqrtPriceMath  } from "@raydium-io/raydium-sdk-v2";
import { buildArbitrageInstructionData, 
  buildArbitrageAccounts,
  DexProgram, 
  MintInfo,
  HopPoolAccounts,
  SYSTEM_PROGRAM_ID,
  } from "./program/instruction";
import { ASSOCIATED_TOKEN_PROGRAM_ID, getAssociatedTokenAddress, NATIVE_MINT, TOKEN_2022_PROGRAM_ID, TOKEN_PROGRAM_ID, createAssociatedTokenAccountIdempotentInstruction, getAssociatedTokenAddressSync } from "@solana/spl-token";
import { getDexAccounts } from "./utils/getDexAccounts";
import { EpochInfo } from "@solana/web3.js";
import { getPriceOfBinByBinId } from "@meteora-ag/dlmm";
import { getPriceFromSqrtPrice } from "@meteora-ag/cp-amm-sdk";
import { getDexFee } from "./utils/getDexFee";
import { MessageV0 } from "@solana/web3.js";
// Main-process RPC budget (the dex-accounts worker has its own, RPC_RPS_WORKER).
const rpcFetch = createRateLimitedFetch(Number(process.env.RPC_RPS_MAIN ?? 2));
const connection = new Connection(RPC_ENDPOINT,{commitment:"confirmed", fetch: rpcFetch});
const swqos_connection = new Connection(SWQOS_ENDPOINT,"confirmed");
const wallet =  Keypair.fromSecretKey(bs58.decode(PRIVATE_KEY))
const inputMint=new PublicKey("So11111111111111111111111111111111111111112");
const tokensRaw = fs
  .readFileSync("tokens.txt", "utf8")
  .split(/\r?\n/);
const tokens: string[] = [];
for (let i = 0; i < tokensRaw.length; i++) {
  const trimmed = tokensRaw[i].trim();
  if (trimmed) {
    tokens.push(trimmed);
  }
}
let pairAddresses: Record<string, BN[]> = {};
let pairAddress_accounts:Record<string, PublicKey[]>={};
let prices:Record<string, number>={};
let fees:Record<string, number>={};
let isToken2022Bitmap:Record<string, boolean>={};
let ratios:Record<string, number>={};
const lookupTableAddress=new PublicKey("CSmqNjMiAMSHtvsURGyo31MkncehVBqeL2QGEsFmgCM5");
let lookupTableAccount:AddressLookupTableAccount;
let client: Client;
try{
  client = new Client(GRPC_ENDPOINT, API_KEY, undefined);
}catch(e){
  console.log(e)
}
let stream:any;
let stream2:any;
let stream3:any;
let inter:any;
let inter1:any;
let inter2:any;
let inter3:any;
let inter5:any;
let streamStarted=false;
let streamStarted2=false;
let accountKeysForStream:string[]=[];
let stream_keys:string[]=[];
let currentSlot = new BN(0); // Track current slot from gRPC slot updates
let blockTime = new BN(0);
let jitoTipAccount:string="";
const myHeaders = new Headers();
myHeaders.append("accept", "application/json");
myHeaders.append("x-api-key", X_API_KEY);
const PROGRAM_ID = new PublicKey('6UZznePGgoykwAutgJFmQce2QQzfYjVcsQesZbRq9Y3b');
const BPF_UPGRADEABLE_LOADER = new PublicKey("BPFLoaderUpgradeab1e11111111111111111111111");
// Nothing is signed or sent unless DRY_RUN=false AND the arb program is still
// deployed (6UZzne was closed on 2026-04-01; every call since fails with
// UnsupportedProgramId and only burns the fee).
const DRY_RUN = (process.env.DRY_RUN ?? "true").trim().toLowerCase() !== "false";
let sendingEnabled = false;
const KAMINO_ENABLED = (process.env.KAMINO_ENABLED ?? "true").trim().toLowerCase() !== "false";
const KAMINO_FEE_BPS = Number(process.env.KAMINO_FEE_BPS ?? 0.1);
const KAMINO_MAX_LAMPORTS = BigInt(Math.floor(Number(process.env.KAMINO_MAX_SOL ?? 10) * LAMPORTS_PER_SOL));
let kaminoLookupTableAccount: AddressLookupTableAccount | null = null;
const JITO_TIP_LAMPORTS = 10000;
// Which on-chain executor the bot calls: "smb" = SolanaMevBot MEViEnsc… (V10,
// own flashloan, live), "legacy" = the original 6UZzne program (closed).
const ARB_PROGRAM = (process.env.ARB_PROGRAM ?? "smb").trim().toLowerCase() === "legacy" ? "legacy" : "smb";
const SMB: SmbSettings = {
  programFeeBps: Number(process.env.SMB_PROGRAM_FEE_BPS ?? 1100),
  minProfitLamports: BigInt(Math.ceil(Number(process.env.MINIMUM_PROFIT ?? 0) * LAMPORTS_PER_SOL)),
  priorityLamports: BigInt(process.env.SMB_PRIORITY_LAMPORTS ?? 10000),
  maxPools: Number(process.env.SMB_MAX_POOLS ?? 4),
  simFirst: (process.env.SMB_SIM_FIRST ?? "true").trim().toLowerCase() !== "false",
  rentInFloor: (process.env.SMB_RENT_IN_FLOOR ?? "false").trim().toLowerCase() === "true",
  simWallet: process.env.SMB_SIM_WALLET?.trim() ? new PublicKey(process.env.SMB_SIM_WALLET.trim()) : undefined,
};
// The program is closed source and upgradeable by its owner: pin the deploy
// slot seen at startup (or SMB_EXPECTED_DEPLOY_SLOT) and stop sending if it moves.
let smbDeploySlot: bigint | null = null;
const SMB_DRY_SIM = (process.env.SMB_DRY_SIM ?? "true").trim().toLowerCase() !== "false";
const SMB_DRY_SIM_MS = Number(process.env.SMB_DRY_SIM_MS ?? 3000);
let smbBusy = false;
let smbLastDrySimAt = 0;
// Own RPC budget so simulations/sends never queue behind discovery calls.
const smbConnection = new Connection(RPC_ENDPOINT, { commitment: "processed", fetch: createRateLimitedFetch(Number(process.env.RPC_RPS_SMB ?? 3)) });
const smbSendConnection = new Connection(RPC_ENDPOINT, "processed");
const harvestConnection = new Connection(RPC_ENDPOINT, { commitment: "confirmed", fetch: createRateLimitedFetch(Number(process.env.RPC_RPS_HARVEST ?? 2)) });
const PUMPAPI_MIGRATE_MIN_SOL = Number(process.env.PUMPAPI_MIGRATE_MIN_SOL ?? 5);
const SHRED_GRPC_URL = process.env.SHRED_GRPC_URL?.trim() || "";
const TELEGRAM_ALERT_MS = Number(process.env.TELEGRAM_ALERT_MS ?? 3000);
let recentBlockhash=""
let recentBlockhashAt=0;
/** A blockhash older than this is not used for sends (it may expire in flight). */
const BLOCKHASH_MAX_AGE_MS = Number(process.env.BLOCKHASH_MAX_AGE_MS ?? 20000);
const blockhashFresh = () => !!recentBlockhash && Date.now() - recentBlockhashAt < BLOCKHASH_MAX_AGE_MS;
const program_ids={
  "cpmm":new PublicKey("CPMMoo8L3F4NbTegBCKVNunggL7H1ZpdTHKxQB5qKP1C"),
  "clmm":new PublicKey("CAMMCzo5YL8w4VFF8KVHrK22GGUsp5VTaW7grrKgrWqK"),
  "orcawp":new PublicKey("whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc"),
  "dlmm":new PublicKey("LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo"),
  "dyn2":new PublicKey("cpamdpZCGKUy5JxQXB4dcpGPiikHawvSWAd6mEn1sGG"),
  "pumpswap":new PublicKey("pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA"),
  "raydium":new PublicKey("675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8")
}

const excludedPairAddresses=["AYszYSUyd3uAs5Q3d9vymfExQpVHuMV6AzFHtNvwH8px","U1kF6PsPzr91sE5ZgGSnty4g1MC9cUQ9QiMDUDoacTf"];
// ---------------------------------------------------------------------------
// pumpapi (replaces PumpPortal): migrations add tokens, pool ticks reprice the
// pools the bot already tracks. Shreds (AllenHark) report trades on those
// pools before they execute.
// ---------------------------------------------------------------------------
const PUMPAPI_POOL_DEX: Record<string, string> = {
  "pump-amm": "pumpswap",
  "raydium-cpmm": "cpmm",
  "raydium-v4": "raydium",
  "raydium-clmm": "clmm",
  "orca-whirlpool": "orcawp",
  "meteora-dlmm": "dlmm",
};
// Venues whose price the bot derives from vault reserves (same as the gRPC path).
const RESERVE_DEXES = new Set(["pumpswap", "cpmm", "raydium"]);
// Hot-path indexes (pool -> pair key, mint -> its pair keys), rebuilt whenever
// pairAddresses changes, so a tick never scans every pair.
let poolToPairKey = new Map<string, string>();
let mintToPairKeys = new Map<string, string[]>();

function rebuildPoolIndex() {
  const next = new Map<string, string>();
  const byMint = new Map<string, string[]>();
  for (const key of Object.keys(pairAddresses)) {
    const [mint, , pool] = key.split("_");
    next.set(pool, key);
    const list = byMint.get(mint);
    if (list) list.push(key);
    else byMint.set(mint, [key]);
  }
  poolToPairKey = next;
  mintToPairKeys = byMint;
  setShredTrackedPools([...next.keys(), ...hotPoolToMint.keys()]);
}

/** Token program of each mint, read in batches of 100 (read-only, no ATA creation). */
async function detectTokenPrograms(mints: string[]) {
  for (let i = 0; i < mints.length; i += 100) {
    const batch = mints.slice(i, i + 100);
    try {
      const infos = await connection.getMultipleAccountsInfo(batch.map((m) => new PublicKey(m)));
      infos.forEach((info, j) => {
        if (info) isToken2022Bitmap[batch[j]] = info.owner.equals(TOKEN_2022_PROGRAM_ID);
      });
    } catch (e) {
      logger.error(`detectTokenPrograms failed: ${e}`);
    }
  }
}

async function onPumpApiMigrate(ev: PumpApiEvent) {
  const mint = String(ev.mint ?? "");
  const sol = Number(ev.quoteInPool ?? 0);
  if (!mint || !isSolQuote(ev.quoteMint) || !(sol >= PUMPAPI_MIGRATE_MIN_SOL)) return;
  if (tokens.includes(mint)) return;
  logger.info(`New Migration-> ${mint} (${ev.pool}, ${sol.toFixed(2)} SOL, pumpapi)`);
  tokens.push(mint);
  await fs.promises.appendFile("tokens.txt", "\n" + mint, "utf8");
  // Read-only: the arb transaction creates the ATAs it needs idempotently.
  if (ev.tokenProgram === "spl-token-2022" || ev.tokenProgram === "spl-token") {
    isToken2022Bitmap[mint] = ev.tokenProgram === "spl-token-2022";
  } else {
    await detectTokenPrograms([mint]);
  }
  // Other venues list a graduated token within a minute or two; look once
  // then instead of waiting for the 10-minute full refresh.
  setTimeout(() => {
    discoverPairsFor(mint).catch((e) => logger.error(`pair discovery ${mint}: ${e}`));
  }, MIGRATION_DISCOVERY_DELAY_MS);
}

const MAX_POOLS_PER_TOKEN = Number(process.env.MAX_POOLS_PER_TOKEN ?? 20);
const MIGRATION_DISCOVERY_DELAY_MS = Number(process.env.MIGRATION_DISCOVERY_DELAY_MS ?? 90000);

async function discoverPairsFor(mint: string) {
  const found = await getTokenPairaddresses(mint);
  const keys = Object.keys(found).filter((k) => !(k in pairAddresses) && !excludedPairAddresses.includes(k.split("_")[2]));
  if (Object.keys(found).length < 2 || keys.length === 0) return;
  // Majors with hundreds of dust CLMM/Whirlpool pools would eat the RPC
  // budget refreshing accounts that never carry a tradable spread.
  if (Object.keys(found).length > MAX_POOLS_PER_TOKEN) {
    logger.info(`skip ${mint}: ${Object.keys(found).length} pools > MAX_POOLS_PER_TOKEN=${MAX_POOLS_PER_TOKEN}`);
    return;
  }
  for (const k of keys) pairAddresses[k] = found[k];
  rebuildPoolIndex();
  logger.info(`New pairs for ${mint}: ${keys.map((k) => k.split("_")[1]).join(",")} (total ${poolToPairKey.size})`);
  await getDexAccountsForPairsMainThread(connection, false, keys);
}

// ---------------------------------------------------------------------------
// Hot routes: pools where the SMB executor REALLY made money recently (read
// from its own successful transactions). Every trade on one of them triggers
// a simulation of the executor at the current state: the program's own math
// says whether there is profit now. No price-spread guessing.
// ---------------------------------------------------------------------------
interface HotRoute { pools: Set<string>; wins: number; bestNet: bigint; lastWinAt: number; lastSimAt: number; }
const hotRoutes = new Map<string, HotRoute>();
const hotPoolToMint = new Map<string, string>();
const HOT_SIM_MIN_MS = Number(process.env.HOT_SIM_MIN_MS ?? 400);
const HOT_SIM_CONCURRENCY = Number(process.env.HOT_SIM_CONCURRENCY ?? 2);
const HOT_ROUTE_TTL_MS = Number(process.env.HOT_ROUTE_TTL_MS ?? 6 * 3600_000);
const hotStats = { marketWins: 0, sims: 0, simProfit: 0, simProfitLamports: BigInt(0), sent: 0 };
let hotInFlight = 0;

function onMarketWin(c: ProfitableCall) {
  hotStats.marketWins++;
  let r = hotRoutes.get(c.mint);
  if (!r) {
    r = { pools: new Set(), wins: 0, bestNet: BigInt(0), lastWinAt: 0, lastSimAt: 0 };
    hotRoutes.set(c.mint, r);
    if (!(c.mint in isToken2022Bitmap)) detectTokenPrograms([c.mint]).catch(() => {});
  }
  for (const p of c.pools) {
    r.pools.add(p);
    hotPoolToMint.set(p, c.mint);
  }
  r.wins++;
  if (c.net > r.bestNet) r.bestNet = c.net;
  r.lastWinAt = Math.max(r.lastWinAt, c.blockTime * 1000);
  setShredTrackedPools([...poolToPairKey.keys(), ...hotPoolToMint.keys()]);
  if (r.wins > 1 && Date.now() - (r as any).loggedAt < 60000) return;
  (r as any).loggedAt = Date.now();
  logger.info(`[MARKET WIN] ${c.mint.slice(0, 8)} +${(Number(c.net) / LAMPORTS_PER_SOL).toFixed(6)} SOL by ${c.signer.slice(0, 6)} pools=${c.pools.length} (hot routes ${hotRoutes.size})`);
}

// Every profitable arbitrage in the market (any program), seen on pumpapi:
// its pools become hot routes when the SMB executor can trade them.
const SMB_VENUES = new Set(["pump-amm", "meteora-dlmm", "meteora-damm-v2", "raydium-clmm", "orca-whirlpool", "raydium-cpmm", "raydium-v4"]);
const MARKET_ARB_MIN_LAMPORTS = BigInt(Math.floor(Number(process.env.MARKET_ARB_MIN_SOL ?? 0.00002) * LAMPORTS_PER_SOL));
const feedMarketArb = createMarketArbDetector((a) => {
  const pools = a.pools.filter((_, i) => SMB_VENUES.has(a.venues[i]!));
  if (pools.length < 2 || a.net < MARKET_ARB_MIN_LAMPORTS) return;
  onMarketWin({ signature: a.signature, slot: 0, blockTime: Math.floor(a.at / 1000), signer: a.signer, net: a.net, mint: a.mint, pools });
});

function pruneHotRoutes() {
  const cutoff = Date.now() - HOT_ROUTE_TTL_MS;
  for (const [mint, r] of hotRoutes) {
    if (r.lastWinAt >= cutoff) continue;
    hotRoutes.delete(mint);
    for (const p of r.pools) if (hotPoolToMint.get(p) === mint) hotPoolToMint.delete(p);
  }
}

function triggerHotSim(mint: string, trigger: string) {
  const r = hotRoutes.get(mint);
  if (!r || !blockhashFresh() || hotInFlight >= HOT_SIM_CONCURRENCY) return;
  const now = Date.now();
  if (now - r.lastSimAt < HOT_SIM_MIN_MS) return;
  if (sendingEnabled && now - lastSendAt < SEND_COOLDOWN_MS) return;
  r.lastSimAt = now;
  hotInFlight++;
  void runHotSim(mint, r, trigger).finally(() => { hotInFlight--; });
}

// ---------------------------------------------------------------------------
// Dual send: a Jito bundle (never lands when our tx would fail, so free) AND a
// plain RPC tx (fastest path, a landed failure costs ~fee). Plain sends are
// capped per hour so failures can never burn more than a known budget.
// ---------------------------------------------------------------------------
const SMB_BUNDLE = (process.env.SMB_BUNDLE ?? "true").trim().toLowerCase() !== "false";
const SMB_PLAIN = (process.env.SMB_PLAIN ?? "true").trim().toLowerCase() !== "false";
const PLAIN_MAX_PER_HOUR = Number(process.env.PLAIN_MAX_PER_HOUR ?? 60);
const BUNDLE_TIP_LAMPORTS = BigInt(process.env.BUNDLE_TIP_LAMPORTS ?? JITO_TIP_LAMPORTS);
const plainSentAt: number[] = [];
let bundleTipAccount = "";

function plainAllowed(): boolean {
  const cutoff = Date.now() - 3600_000;
  while (plainSentAt.length && plainSentAt[0]! < cutoff) plainSentAt.shift();
  return plainSentAt.length < PLAIN_MAX_PER_HOUR;
}

/** `verified` = a simulation showed profit at the current state (only then a paid plain tx). */
function sendPaths(prefix: string[], verified = true) {
  const plain = verified && SMB_PLAIN && plainAllowed();
  const bundle = SMB_BUNDLE && bundleTipAccount
    ? { send: (txs: string[]) => sendJitoBundle(txs), tip: { to: new PublicKey(bundleTipAccount), lamports: BUNDLE_TIP_LAMPORTS }, prefix }
    : undefined;
  return { plain, bundle };
}

const backrunStats = { seen: 0, skippedArb: 0, sent: 0, dry: 0 };
const backrunAt = new Map<string, number>();

/**
 * Shreds: a pending trade on a hot pool. Our tx goes in a bundle right after
 * the victim (it can only profit from the state the victim leaves), plus a
 * plain copy. No simulation: the victim has not executed yet.
 */
async function backrunPending(mint: string, r: HotRoute, t: PendingPoolTrade) {
  backrunStats.seen++;
  if (!blockhashFresh()) return;
  if (t.isSmbCall) {
    backrunStats.skippedArb++;
    return;
  }
  const now = Date.now();
  if (now - (backrunAt.get(mint) ?? 0) < Number(process.env.BACKRUN_MIN_MS ?? 150)) return;
  backrunAt.set(mint, now);
  if (!sendingEnabled) {
    backrunStats.dry++;
    if (process.env.HOT_LOG_ALL === "true") logger.info(`[backrun dry] ${mint.slice(0, 8)} victim=${t.signature.slice(0, 10)} pool=${t.pool.slice(0, 6)}`);
    return;
  }
  const extra = (mintToPairKeys.get(mint) ?? []).map((k) => k.split("_")[2]).filter((p) => !r.pools.has(p));
  const res = await smbTry({
    conn: smbConnection,
    sendConns: [smbSendConnection],
    // Shreds arrive after the leader executed the entry: the victim is
    // already processed (Jito rejects a bundle carrying it), so our tx goes
    // alone and aims at the state the victim left.
    // Unverified (no sim possible): bundle only, which is free when it fails.
    ...sendPaths([], false),
    signer: wallet,
    mint: new PublicKey(mint),
    tokenProgram: isToken2022Bitmap[mint] ? TOKEN_2022_PROGRAM_ID : TOKEN_PROGRAM_ID,
    pools: [t.pool, ...[...r.pools].filter((p) => p !== t.pool), ...extra].map((p) => new PublicKey(p)),
    blockhash: recentBlockhash,
    live: true,
    skipSim: true,
    s: SMB,
  });
  if (res.stage === "sent") {
    backrunStats.sent++;
    trackSent(res.signature, res.bundleSignature, mint);
  }
  logger.info(`[backrun ${res.stage}] ${mint.slice(0, 8)} victim=${t.signature.slice(0, 10)} ${res.reason.slice(0, 180)}${res.signature ? ` plain=${res.signature}` : ""}${res.bundleSignature ? ` bundle=${res.bundleSignature}` : ""}`);
}

// Outcome of what we sent: landed ok (profit) / landed failed (fee) / never landed.
const sendOutcome = { landedOk: 0, landedFail: 0, notLanded: 0 };
const watchSigs: { sig: string; kind: string; mint: string; at: number }[] = [];
function trackSent(plain: string | undefined, bundle: string | undefined, mint: string) {
  if (plain) {
    plainSentAt.push(Date.now());
    watchSigs.push({ sig: plain, kind: "plain", mint, at: Date.now() });
  }
  if (bundle) watchSigs.push({ sig: bundle, kind: "bundle", mint, at: Date.now() });
}
setInterval(async () => {
  const due = watchSigs.filter((w) => Date.now() - w.at > 20000);
  if (!due.length) return;
  try {
    const st = await connection.getSignatureStatuses(due.map((d) => d.sig).slice(0, 256));
    due.slice(0, 256).forEach((d, i) => {
      const v = st.value[i];
      if (!v) sendOutcome.notLanded++;
      else if (v.err) sendOutcome.landedFail++;
      else {
        sendOutcome.landedOk++;
        logger.warn(`[LANDED PROFIT] ${d.kind} ${d.mint} sig=${d.sig}`);
        sendTelegramAlert(`LANDED arb (${d.kind}) ${d.mint}\nhttps://solscan.io/tx/${d.sig}`);
      }
      const idx = watchSigs.indexOf(d);
      if (idx >= 0) watchSigs.splice(idx, 1);
    });
  } catch (e) {}
}, 10000);

async function runHotSim(mint: string, r: HotRoute, trigger: string) {
  try {
    const extra = (mintToPairKeys.get(mint) ?? []).map((k) => k.split("_")[2]).filter((p) => !r.pools.has(p));
    const live = sendingEnabled;
    if (live) lastSendAt = Date.now();
    hotStats.sims++;
    const res = await smbTry({
      conn: smbConnection,
      sendConns: [smbSendConnection],
      ...sendPaths([]),
      signer: wallet,
      mint: new PublicKey(mint),
      tokenProgram: isToken2022Bitmap[mint] ? TOKEN_2022_PROGRAM_ID : TOKEN_PROGRAM_ID,
      pools: [...r.pools, ...extra].map((p) => new PublicKey(p)),
      blockhash: recentBlockhash,
      live,
      s: SMB,
    });
    const found = res.stage === "sent" || (res.stage === "dry" && res.profit !== undefined && res.profit > BigInt(0));
    if (res.stage === "sent") {
      hotStats.sent++;
      trackSent(res.signature, res.bundleSignature, mint);
    }
    if (found) {
      hotStats.simProfit++;
      if (res.profit) hotStats.simProfitLamports += res.profit;
      const msg = `[REAL OPPORTUNITY] ${mint} ${res.reason}${res.signature ? ` sig=${res.signature}` : ""} trigger=${trigger}`;
      logger.warn(msg);
      fs.promises.appendFile("opportunities.csv", `${new Date().toISOString()},${mint},${res.stage},${res.profit ?? ""},${res.signature ?? ""},${trigger},"${res.reason.replace(/"/g, "'")}"
`).catch(() => {});
      const t = Date.now();
      if (t - lastAlertAt >= TELEGRAM_ALERT_MS) {
        lastAlertAt = t;
        sendTelegramAlert(msg);
      }
    } else if (res.stage !== "dry" || process.env.HOT_LOG_ALL === "true") {
      logger.info(`[hot ${res.stage}] ${mint.slice(0, 8)} ${res.reason.slice(0, 160)}`);
    }
  } catch (e) {
    logger.error(`hot sim failed: ${String(e).slice(0, 160)}`);
  }
}

// Auto-discovery: a mint seen trading on >= 2 distinct supported pools in the
// pumpapi stream is a candidate; its pools are then looked up on chain.
const AUTO_DISCOVER = (process.env.AUTO_DISCOVER ?? "true").trim().toLowerCase() !== "false";
const DISCOVER_INTERVAL_MS = Number(process.env.DISCOVER_INTERVAL_MS ?? 5000);
const MAX_TRACKED_TOKENS = Number(process.env.MAX_TRACKED_TOKENS ?? 50);
let seenPools = new Map<string, Set<string>>();
const discoverQueue: string[] = [];
const discoverTried = new Map<string, number>();

function noteSeenPool(mint: string, poolId: string) {
  if (discoverTried.has(mint) || mintToPairKeys.has(mint)) return;
  let set = seenPools.get(mint);
  if (!set) seenPools.set(mint, (set = new Set()));
  set.add(poolId);
  if (set.size >= 2) {
    discoverTried.set(mint, Date.now());
    seenPools.delete(mint);
    discoverQueue.push(mint);
  }
}

if (AUTO_DISCOVER) {
  setInterval(() => {
    const mint = discoverQueue.shift();
    if (!mint || mintToPairKeys.size >= MAX_TRACKED_TOKENS) return;
    if (!tokens.includes(mint)) {
      tokens.push(mint);
      detectTokenPrograms([mint]).catch(() => {});
    }
    discoverPairsFor(mint).catch((e) => logger.error(`pair discovery ${mint}: ${e}`));
  }, DISCOVER_INTERVAL_MS);
  // Forget one-pool mints and old attempts so memory stays bounded.
  setInterval(() => {
    seenPools = new Map();
    const cutoff = Date.now() - 30 * 60000;
    for (const [m, t] of discoverTried) if (t < cutoff) discoverTried.delete(m);
  }, 10 * 60000);
}

function onPumpApiTick(ev: PumpApiEvent) {
  if (ev.signature) noteStreamedSignature(String(ev.signature));
  if (ARB_PROGRAM === "smb") {
    const hot = hotPoolToMint.get(String(ev.poolId));
    if (hot) triggerHotSim(hot, `pumpapi:${String(ev.signature ?? "").slice(0, 10)}`);
  }
  const pairKey = poolToPairKey.get(String(ev.poolId));
  if (!pairKey) {
    if (AUTO_DISCOVER && ev.mint && PUMPAPI_POOL_DEX[String(ev.pool)]) noteSeenPool(String(ev.mint), String(ev.poolId));
    return;
  }
  trackedTicks++;
  const [mint, dex, poolAddress] = pairKey.split("_");
  if (PUMPAPI_POOL_DEX[String(ev.pool)] !== dex || String(ev.mint) !== mint) return;
  const decimals = Number(ev.decimals);
  const price = Number(ev.price);
  const tokensInPool = Number(ev.tokensInPool);
  const quoteInPool = Number(ev.quoteInPool);
  const feeRate = Number(ev.poolFeeRate);
  const feePct = Number.isFinite(feeRate) && feeRate > 0 ? feeRate * 100 : undefined;
  if (!Number.isInteger(decimals) || !(price > 0) || !(tokensInPool > 0) || !(quoteInPool > 0)) return;
  // Without pool account data the bot cannot read a CLMM/DLMM/Whirlpool fee itself.
  if (!RESERVE_DEXES.has(dex) && feePct === undefined) return;
  const reserveA = new BN(BigInt(Math.floor(tokensInPool * 10 ** decimals)).toString());
  const reserveB = new BN(BigInt(Math.floor(quoteInPool * LAMPORTS_PER_SOL)).toString());
  if (RESERVE_DEXES.has(dex)) {
    const cur = pairAddresses[pairKey];
    if (cur[0].eq(reserveA) && cur[1].eq(reserveB)) return;
    cur[0] = reserveA;
    cur[1] = reserveB;
    cur[2] = new BN(decimals);
    cur[3] = new BN(9);
  }
  findArbtrageOpportunities({
    dex,
    poolAddress,
    poolData: Buffer.from([0]),
    poolReserves: { reserveA, reserveB, decimalA: decimals, decimalB: 9, preReserveA: new BN(0), preReserveB: new BN(0) },
    sig: String(ev.signature ?? "pumpapi"),
    // Raw units (lamports per smallest token unit), like the gRPC paths.
    priceOverride: RESERVE_DEXES.has(dex) ? undefined : price * 10 ** (9 - decimals),
    feePctOverride: feePct,
  });
}

/**
 * Apply a pending top-level PumpSwap swap (decoded from shreds) to the pool's
 * vault balances, constant product. The LP fee that stays in the pool is
 * ignored (error <= that fee on the trade size); pools with virtual quote
 * reserves are off by the same amount as the bot's gRPC pricing of them.
 */
function predictPumpSwap(kind: string, amount: bigint, token: bigint, sol: bigint, feePct: number): { token: bigint; sol: bigint } | null {
  if (amount <= BigInt(0)) return null;
  if (kind === "buy") {
    if (amount >= token) return null;
    const quoteIn = (sol * amount + (token - amount) - BigInt(1)) / (token - amount);
    return { token: token - amount, sol: sol + quoteIn };
  }
  if (kind === "sell") {
    const quoteOut = (sol * amount) / (token + amount);
    return { token: token + amount, sol: sol - quoteOut };
  }
  // buyExactQuoteIn: amount is the spendable quote including fees.
  const feeBps = BigInt(Math.round(feePct * 100));
  const eff = (amount * BigInt(10000)) / (BigInt(10000) + feeBps);
  const baseOut = (token * eff) / (sol + eff);
  return { token: token - baseOut, sol: sol + eff };
}

let shredUnpredicted = 0;
function onShredPendingTrade(t: PendingPoolTrade) {
  if (ARB_PROGRAM === "smb") {
    const hot = hotPoolToMint.get(t.pool);
    const route = hot ? hotRoutes.get(hot) : undefined;
    if (hot && route) void backrunPending(hot, route, t).catch((e) => logger.error(`backrun: ${String(e).slice(0, 120)}`));
  }
  const pairKey = poolToPairKey.get(t.pool);
  if (!pairKey) return;
  const [mint, dex] = pairKey.split("_");
  const s = t.pumpSwap;
  if (dex !== "pumpswap" || !s || s.baseMint !== mint || s.quoteMint !== NATIVE_MINT.toBase58()) {
    shredUnpredicted++;
    return;
  }
  const cur = pairAddresses[pairKey];
  const token = BigInt(cur[0].toString());
  const sol = BigInt(cur[1].toString());
  if (token <= BigInt(0) || sol <= BigInt(0)) return;
  const next = predictPumpSwap(s.kind, s.amount, token, sol, fees[t.pool] ?? 1);
  if (!next || next.token <= BigInt(0) || next.sol <= BigInt(0)) return;
  // Only the price moves to the prediction; the real reserves arrive from the
  // gRPC / pumpapi stream once the trade executes.
  findArbtrageOpportunities({
    dex: "pumpswap",
    poolAddress: t.pool,
    poolData: Buffer.from([0]),
    poolReserves: {
      reserveA: new BN(next.token.toString()),
      reserveB: new BN(next.sol.toString()),
      decimalA: cur[2].toNumber(),
      decimalB: 9,
      preReserveA: new BN(token.toString()),
      preReserveB: new BN(sol.toString()),
    },
    sig: `shred:${t.signature}`,
  });
}

let dryOpportunities = 0;
let spreadCandidates = 0;
let trackedTicks = 0;
setInterval(() => {
  const sh = SHRED_GRPC_URL ? ` shred(conn=${shredStats.connected} hits=${shredStats.hits} pumpswap=${shredStats.pumpSwapDecoded} unpred=${shredUnpredicted})` : "";
  if (ARB_PROGRAM === "smb") logger.info(`hot: routes=${hotRoutes.size} pools=${hotPoolToMint.size} marketWins=${hotStats.marketWins} marketArbs(all=${marketArbStats.profitable} ${(Number(marketArbStats.lamports) / LAMPORTS_PER_SOL).toFixed(4)} SOL) sims=${hotStats.sims} REAL=${hotStats.simProfit} (${(Number(hotStats.simProfitLamports) / LAMPORTS_PER_SOL).toFixed(6)} SOL) sent=${hotStats.sent} backrun(seen=${backrunStats.seen} arbSkip=${backrunStats.skippedArb} dry=${backrunStats.dry} sent=${backrunStats.sent}) outcome(ok=${sendOutcome.landedOk} fail=${sendOutcome.landedFail} none=${sendOutcome.notLanded}) plainLastHour=${plainSentAt.length} harvest(read=${harvestStats.txsRead} noop=${harvestStats.noop}) wallets(read=${walletHarvestStats.txsRead} wins=${walletHarvestStats.wins})`);
  logger.info(`stats: pumpapi(conn=${pumpApiStats.connected} ev=${pumpApiStats.events} ticks=${pumpApiStats.ticks} mig=${pumpApiStats.migrations}) pools=${poolToPairKey.size} trackedTicks=${trackedTicks} spread>fee=${spreadCandidates} opps=${dryOpportunities}${sh}`);
}, Number(process.env.STATS_MS ?? 30000));

// pumpapi allows one socket per IP: PUMPAPI_ENABLED=false on a machine where
// another bot already holds it (routes then come from ARB_WALLETS, triggers from shreds).
const PUMPAPI_ENABLED = (process.env.PUMPAPI_ENABLED ?? "true").trim().toLowerCase() !== "false";
if (PUMPAPI_ENABLED) startPumpApiStream({ onEvent: (ev) => { if (ARB_PROGRAM === "smb") feedMarketArb(ev); }, onMigrate: (ev) => { onPumpApiMigrate(ev).catch((e) => logger.error(`migrate handler: ${e}`)); }, onPoolTick: onPumpApiTick });
async function getTokenPairaddressesFromDexscreener(tokenAddress:string) {
  try {
    const response = await fetch(`https://api.dexscreener.com/token-pairs/v1/solana/${tokenAddress}`, {
        method: 'GET',
        headers: {
          "Accept": "application/json"
        },
    });

    if (!response.ok) {
      logger.error(`API error for token ${tokenAddress}: ${response.status} ${response.statusText}`);
      return {};
    }

    const contentType = response.headers.get("content-type");
    if (!contentType || !contentType.includes("application/json")) {
      const text = await response.text();
      logger.error(`Non-JSON response for token ${tokenAddress}. Content-Type: ${contentType}, First 100 chars: ${text.substring(0, 100)}`);
      return {};
    }

    const data = await response.json();
    
    // Handle case where API returns an object with pairs array
    const pairs = Array.isArray(data) ? data : (data.pairs || []);
    
    const addresses: Record<string, BN[]> = {};
    for (let info of pairs){
      try{
        if(info["baseToken"]["address"]=="So11111111111111111111111111111111111111112"||info["quoteToken"]["address"]=="So11111111111111111111111111111111111111112"){
          if(info["dexId"]=="pumpswap"){
            if(info["liquidity"] && info["liquidity"]["usd"]>=500&&info["pairAddress"]){
              addresses[`${tokenAddress}_pumpswap_${info["pairAddress"]}`]=[new BN(0),new BN(0),new BN(0),new BN(0),new BN(0)];
            }
          }
          if(info["dexId"]=="meteora"&&info["labels"].includes("DLMM")){
            if(info["liquidity"] && info["liquidity"]["usd"]>=500&&info["pairAddress"]){
              addresses[`${tokenAddress}_dlmm_${info["pairAddress"]}`]=[new BN(0),new BN(0),new BN(0),new BN(0),new BN(0)];
            }
          }
          if(info["dexId"]=="raydium"&&info["labels"]==undefined){
            if(info["liquidity"] && info["liquidity"]["usd"]>=500&&info["pairAddress"]){
              addresses[`${tokenAddress}_raydium_${info["pairAddress"]}`]=[new BN(0),new BN(0),new BN(0),new BN(0),new BN(0)];
            }
          }
          if(info["dexId"]=="raydium"&&info["labels"].includes("CLMM")){
            if(info["liquidity"] && info["liquidity"]["usd"]>=500&&info["pairAddress"]){
              addresses[`${tokenAddress}_clmm_${info["pairAddress"]}`]=[new BN(0),new BN(0),new BN(0),new BN(0),new BN(0)];
            }
          }
          if(info["dexId"]=="orca"&&info["labels"].includes("wp")){
            if(info["liquidity"] && info["liquidity"]["usd"]>=500&&info["pairAddress"]){
              addresses[`${tokenAddress}_orcawp_${info["pairAddress"]}`]=[new BN(0),new BN(0),new BN(0),new BN(0),new BN(0)];
            }
          }
          // if(info["dexId"]=="meteora"&&info["labels"].includes("DYN2")){
          //   if(info["liquidity"] && info["liquidity"]["usd"]>=50000&&info["pairAddress"]){
          //     addresses[`${tokenAddress}_dyn2_${info["pairAddress"]}`]=[new BN(0),new BN(0),new BN(0),new BN(0),new BN(0)];
          //   }
          // }
          if(info["dexId"]=="raydium"&&info["labels"].includes("CPMM")){
            if(info["liquidity"] && info["liquidity"]["usd"]>=500&&info["pairAddress"]){

              addresses[`${tokenAddress}_cpmm_${info["pairAddress"]}`]=[new BN(0),new BN(0),new BN(0),new BN(0),new BN(0)];
            }
          }
        }
      }catch(e){}
    }
    // if(Object.keys(addresses).length>2){
    //   console.log(tokenAddress)
    // }
    return addresses;
  } catch (error: any) {
    logger.error(`Error fetching pair addresses for token ${tokenAddress}: ${error.message}`);
    return {};
  }
}

const GPA_V2_LIMIT = 10000;
const GPA_CONCURRENCY = Math.max(1, Number(process.env.GPA_CONCURRENCY ?? 4));
let gpaActive = 0;
const gpaWaiters: Array<() => void> = [];
function gpaAcquire(): Promise<void> {
  if (gpaActive < GPA_CONCURRENCY) {
    gpaActive++;
    return Promise.resolve();
  }
  return new Promise((resolve) => gpaWaiters.push(resolve));
}
function gpaRelease() {
  const next = gpaWaiters.shift();
  if (next) next();
  else gpaActive--;
}

type ProgramAccountResult = Array<{ pubkey: PublicKey; account: { executable: boolean; owner: PublicKey; lamports: number; rentEpoch?: number; data: Buffer } }>;

/** Helius getProgramAccountsV2 – single request with limit (same response shape as getProgramAccounts). */
async function getProgramAccountsV2(
  rpcUrl: string,
  programId: string,
  options: { filters: Array<{ dataSize: number } | { memcmp: { offset: number; bytes: string } }>; dataSlice?: { offset: number; length: number }; limit?: number }
): Promise<ProgramAccountResult> {
  const limit = options.limit ?? GPA_V2_LIMIT;
  const body = {
    jsonrpc: "2.0",
    id: "1",
    method: "getProgramAccountsV2",
    params: [
      programId,
      {
        encoding: "base64",
        filters: options.filters,
        ...(options.dataSlice && { dataSlice: options.dataSlice }),
        commitment: "confirmed",
        limit,
      },
    ],
  };
  // Every token fires 12 of these at once; unthrottled that is a 429 storm on
  // Helius. A small semaphore plus backoff on 429 keeps discovery reliable.
  let res: Response | null = null;
  for (let attempt = 0; ; attempt++) {
    await gpaAcquire();
    try {
      res = await rpcFetch(rpcUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
    } finally {
      gpaRelease();
    }
    if (res.status !== 429 || attempt >= 6) break;
    await delay(400 * 2 ** attempt + Math.floor(Math.random() * 200));
  }
  if (!res.ok) throw new Error(`getProgramAccountsV2 HTTP ${res.status}`);
  const data = (await res.json()) as {
    error?: { message?: string };
    result?: { accounts?: Array<{ pubkey: string; account: { executable?: boolean; owner: string; lamports?: number; rentEpoch?: number; data?: string | [string, string] } }> };
  };
  if (data.error) throw new Error(data.error.message || JSON.stringify(data.error));
  const accounts = data.result?.accounts ?? [];
  return accounts.map((item) => {
    const pubkey = new PublicKey(item.pubkey);
    const acc = item.account;
    const dataBuf = Array.isArray(acc.data) ? Buffer.from(acc.data[0], "base64") : Buffer.from(acc.data ?? "", "base64");
    return {
      pubkey,
      account: {
        executable: acc.executable ?? false,
        owner: new PublicKey(acc.owner),
        lamports: acc.lamports ?? 0,
        rentEpoch: acc.rentEpoch,
        data: dataBuf,
      },
    };
  });
}

async function getTokenPairaddresses(tokenAddress: string) {
  try {

    const addresses: Record<string, BN[]> = {};
    const opts = { dataSlice: { offset: 0, length: 0 }, limit: GPA_V2_LIMIT };

    const [
      pumpamm_basePools,
      pumpamm_quotePools,
      raydium_basePools,
      raydium_quotePools,
      raydiumcpmm_basePools,
      raydiumcpmm_quotePools,
      raydiumclmm_basePools,
      raydiumclmm_quotePools,
      orcawp_basePools,
      orcawp_quotePools,
      meteoradlmm_basePools,
      meteoradlmm_quotePools,
    ] = await Promise.all([
      getProgramAccountsV2(RPC_ENDPOINT, "pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA", {
        ...opts,
        filters: [{ dataSize: 301 }, { memcmp: { offset: 43, bytes: tokenAddress } },{ memcmp: { offset: 75, bytes: NATIVE_MINT.toString() } }],
      }),
      getProgramAccountsV2(RPC_ENDPOINT, "pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA", {
        ...opts,
        filters: [{ dataSize: 301 }, { memcmp: { offset: 75, bytes: tokenAddress } },{ memcmp: { offset: 43, bytes: NATIVE_MINT.toString() } }],
      }),
      getProgramAccountsV2(RPC_ENDPOINT, "675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8", {
        ...opts,
        filters: [{ dataSize: 752 }, { memcmp: { offset: 400, bytes: tokenAddress } },{ memcmp: { offset: 432, bytes: NATIVE_MINT.toString() } }],
      }),
      getProgramAccountsV2(RPC_ENDPOINT, "675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8", {
        ...opts,
        filters: [{ dataSize: 752 }, { memcmp: { offset: 432, bytes: tokenAddress } },{ memcmp: { offset: 400, bytes: NATIVE_MINT.toString() } }],
      }),
      getProgramAccountsV2(RPC_ENDPOINT, "CPMMoo8L3F4NbTegBCKVNunggL7H1ZpdTHKxQB5qKP1C", {
        ...opts,
        filters: [{ dataSize: 637 }, { memcmp: { offset: 168, bytes: tokenAddress } },{ memcmp: { offset: 200, bytes: NATIVE_MINT.toString() } }],
      }),
      getProgramAccountsV2(RPC_ENDPOINT, "CPMMoo8L3F4NbTegBCKVNunggL7H1ZpdTHKxQB5qKP1C", {
        ...opts,
        filters: [{ dataSize: 637 }, { memcmp: { offset: 200, bytes: tokenAddress } },{ memcmp: { offset: 168, bytes: NATIVE_MINT.toString() } }],
      }),
      getProgramAccountsV2(RPC_ENDPOINT, "CAMMCzo5YL8w4VFF8KVHrK22GGUsp5VTaW7grrKgrWqK", {
        ...opts,
        filters: [{ dataSize: 1544 }, { memcmp: { offset: 73, bytes: tokenAddress } },{ memcmp: { offset: 105, bytes: NATIVE_MINT.toString() } }],
      }),
      getProgramAccountsV2(RPC_ENDPOINT, "CAMMCzo5YL8w4VFF8KVHrK22GGUsp5VTaW7grrKgrWqK", {
        ...opts,
        filters: [{ dataSize: 1544 }, { memcmp: { offset: 105, bytes: tokenAddress } },{ memcmp: { offset: 73, bytes: NATIVE_MINT.toString() } }],
      }),
      getProgramAccountsV2(RPC_ENDPOINT, "whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc", {
        ...opts,
        filters: [{ dataSize: 653 }, { memcmp: { offset: 101, bytes: tokenAddress } },{ memcmp: { offset: 181, bytes: NATIVE_MINT.toString() } }],
      }),
      getProgramAccountsV2(RPC_ENDPOINT, "whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc", {
        ...opts,
        filters: [{ dataSize: 653 }, { memcmp: { offset: 181, bytes: tokenAddress } },{ memcmp: { offset: 101, bytes: NATIVE_MINT.toString() } }],
      }),
      getProgramAccountsV2(RPC_ENDPOINT, "LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo", {
        ...opts,
        filters: [{ dataSize: 904 }, { memcmp: { offset: 88, bytes: tokenAddress } },{ memcmp: { offset: 120, bytes: NATIVE_MINT.toString() } }],
      }),
      getProgramAccountsV2(RPC_ENDPOINT, "LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo", {
        ...opts,
        filters: [{ dataSize: 904 }, { memcmp: { offset: 120, bytes: tokenAddress } },{ memcmp: { offset: 88, bytes: NATIVE_MINT.toString() } }],
      }),
    ]);

    // const meteoradyn2_basePools = await connection.getProgramAccounts(new PublicKey("cpamdpZCGKUy5JxQXB4dcpGPiikHawvSWAd6mEn1sGG"), {
    //   dataSlice: { offset: 0, length: 0 }, 
    //   filters: [
    //     { dataSize: 1112 },
    //     { memcmp: { offset: 168, bytes: tokenAddress } },
    //   ],
    // });
    // const meteoradyn2_quotePools = await connection.getProgramAccounts(new PublicKey("cpamdpZCGKUy5JxQXB4dcpGPiikHawvSWAd6mEn1sGG"), {
    //   dataSlice: { offset: 0, length: 0 },
    //   filters: [
    //     { dataSize: 1112 },
    //     { memcmp: { offset: 200, bytes: tokenAddress } },
    //   ],
    // });
    for (const acc of pumpamm_basePools) {
      addresses[`${tokenAddress}_pumpswap_${acc.pubkey.toBase58()}`]=[new BN(0),new BN(0),new BN(0),new BN(0),new BN(0)];
    }
    for (const acc of pumpamm_quotePools) {
      addresses[`${tokenAddress}_pumpswap_${acc.pubkey.toBase58()}`]=[new BN(0),new BN(0),new BN(0),new BN(0),new BN(0)];
    }
    for (const acc of raydium_basePools) {
      addresses[`${tokenAddress}_raydium_${acc.pubkey.toBase58()}`]=[new BN(0),new BN(0),new BN(0),new BN(0),new BN(0)];
    }
    for (const acc of raydium_quotePools) {
      addresses[`${tokenAddress}_raydium_${acc.pubkey.toBase58()}`]=[new BN(0),new BN(0),new BN(0),new BN(0),new BN(0)];
    }
    for (const acc of raydiumcpmm_basePools) {
      addresses[`${tokenAddress}_cpmm_${acc.pubkey.toBase58()}`]=[new BN(0),new BN(0),new BN(0),new BN(0),new BN(0)];
    }
    for (const acc of raydiumcpmm_quotePools) {
      addresses[`${tokenAddress}_cpmm_${acc.pubkey.toBase58()}`]=[new BN(0),new BN(0),new BN(0),new BN(0),new BN(0)];
    }
    for (const acc of raydiumclmm_basePools) {
      addresses[`${tokenAddress}_clmm_${acc.pubkey.toBase58()}`]=[new BN(0),new BN(0),new BN(0),new BN(0),new BN(0)];
    }
    for (const acc of raydiumclmm_quotePools) {
      addresses[`${tokenAddress}_clmm_${acc.pubkey.toBase58()}`]=[new BN(0),new BN(0),new BN(0),new BN(0),new BN(0)];
    }
    for (const acc of orcawp_basePools) {
      addresses[`${tokenAddress}_orcawp_${acc.pubkey.toBase58()}`]=[new BN(0),new BN(0),new BN(0),new BN(0),new BN(0)];
    }
    for (const acc of orcawp_quotePools) {
      addresses[`${tokenAddress}_orcawp_${acc.pubkey.toBase58()}`]=[new BN(0),new BN(0),new BN(0),new BN(0),new BN(0)];
    }
    for (const acc of meteoradlmm_basePools) {
      addresses[`${tokenAddress}_dlmm_${acc.pubkey.toBase58()}`]=[new BN(0),new BN(0),new BN(0),new BN(0),new BN(0)];
    }
    for (const acc of meteoradlmm_quotePools) {
      addresses[`${tokenAddress}_dlmm_${acc.pubkey.toBase58()}`]=[new BN(0),new BN(0),new BN(0),new BN(0),new BN(0)];
    }
    // for (const acc of meteoradyn2_basePools) {
    //   addresses.push(acc.pubkey.toBase58());
    // }
    // for (const acc of meteoradyn2_quotePools) {
    //   addresses.push(acc.pubkey.toBase58());
    // }

    return addresses;
  } catch (error: any) {
    logger.error(`Error fetching pair addresses for token ${tokenAddress}: ${error}`);
    return {};
  }
}

(async () => {
  const accounts = (await connection.getAddressLookupTable(lookupTableAddress)).value;
  if (accounts) {
    lookupTableAccount=accounts;
  } else if (ARB_PROGRAM === "legacy") {
    throw new Error('Failed to fetch lookup table');
  } else {
    // The SMB path sends v1 transactions, which carry no lookup tables.
    logger.info(`lookup table ${lookupTableAddress.toBase58()} not found (not needed for ARB_PROGRAM=smb)`);
  }
  await checkSendingEnabled();
  // Jito tip account up front: bundles must not wait for pair discovery.
  const refreshTip = async () => {
    try {
      const accs = await getJitoTipAccountList();
      if (accs.length) {
        bundleTipAccount = accs[Math.floor(Math.random() * accs.length)]!;
        jitoTipAccount = jitoTipAccount || bundleTipAccount;
      }
    } catch (e) { logger.error(`Jito tip accounts: ${String(e).slice(0, 120)}`); }
  };
  await refreshTip();
  if (!bundleTipAccount) setTimeout(refreshTip, 5000);
  setInterval(refreshTip, 600000);
  logger.info(`bundle path: ${SMB_BUNDLE && bundleTipAccount ? `on (tip ${BUNDLE_TIP_LAMPORTS} lamports)` : "off"}, plain path: ${SMB_PLAIN ? `on (max ${PLAIN_MAX_PER_HOUR}/h)` : "off"}`);
  // Blockhash first: hot-route sims start as soon as the harvester reports.
  // Own unthrottled connection, from the very start: a stale blockhash makes
  // every send expire (plain dropped, Jito "expired blockhash").
  const refreshBlockhash = async () => {
    try {
      recentBlockhash = (await smbSendConnection.getLatestBlockhash({ commitment: "confirmed" })).blockhash;
      recentBlockhashAt = Date.now();
    } catch (e) {}
  };
  await refreshBlockhash();
  setInterval(refreshBlockhash, Number(process.env.BLOCKHASH_REFRESH_MS ?? 1000));
  if (ARB_PROGRAM === "smb" && (process.env.HOT_ROUTES ?? "true").trim().toLowerCase() !== "false") {
    startHarvester(harvestConnection, onMarketWin, Number(process.env.HARVEST_POLL_MS ?? 10000));
    const arbWallets = (process.env.ARB_WALLETS ?? "").split(",").map((w) => w.trim()).filter(Boolean);
    if (arbWallets.length) {
      logger.info(`watching ${arbWallets.length} arbitrage wallets for routes`);
      startWalletHarvester(harvestConnection, arbWallets, onMarketWin, Number(process.env.WALLET_HARVEST_POLL_MS ?? 15000), Number(process.env.WALLET_HARVEST_MAX_READS ?? 20));
    }
    setInterval(pruneHotRoutes, 600000);
  }
  // Re-check every 5 minutes (program closed or upgraded -> stop sending).
  setInterval(() => { checkSendingEnabled().catch(() => {}); }, 300000);
  if (KAMINO_ENABLED && ARB_PROGRAM === "legacy") {
    kaminoLookupTableAccount = (await connection.getAddressLookupTable(KAMINO_LOOKUP_TABLE)).value;
    if (!kaminoLookupTableAccount) logger.warn(`Kamino ALT ${KAMINO_LOOKUP_TABLE.toBase58()} not found; flash txs will be larger`);
    const r = await readKaminoReserve(connection);
    logger.info(r.ok ? `Kamino SOL reserve available: ${(Number(r.available) / LAMPORTS_PER_SOL).toFixed(0)} SOL` : `Kamino reserve unusable: ${r.reason}`);
  }
  if (SHRED_GRPC_URL) {
    startShredFeed({ url: SHRED_GRPC_URL, connection, onPendingTrade: onShredPendingTrade });
  } else {
    logger.info("SHRED_GRPC_URL not set: shred feed off (pumpapi + gRPC only)");
  }
  for (let i = 0; i < tokens.length; i += 290) {
    const batch = tokens.slice(i, i + 290);
    const promises: Promise<Record<string, BN[]>>[] = [];
    for (let j = 0; j < batch.length; j++) {
      promises.push(getTokenPairaddresses(batch[j]));
    }
    const pairAddressesResults = await Promise.allSettled(promises);
    pairAddressesResults.forEach((result, index) => {
      if (result.status === 'fulfilled') {
        const pairAddressesForToken = result.value;
        if(Object.keys(pairAddressesForToken).length>=2){
          Object.assign(pairAddresses, pairAddressesForToken);
        }
      } else {
        logger.error(`Failed to fetch addresses for token ${batch[index]}: ${result.reason}`);
      }
    });
    if (i + 290 < tokens.length) {
      await delay(65000);
    }
  }
  // Read-only: the arb transaction creates the ATAs it needs (idempotent), so
  // startup never spends rent on tokens that may never trade.
  await detectTokenPrograms(tokens);
  // "confirmed": a processed blockhash can sit on a dropped fork.
  await start_arbitrage();
  
})();

setInterval(async () => {
  let updatedPairAddresses: Record<string, BN[]> = {};
  for (let i = 0; i < tokens.length; i += 290) {
    const batch = tokens.slice(i, i + 290);
    const promises: Promise<Record<string, BN[]>>[] = [];
    for (let j = 0; j < batch.length; j++) {
      promises.push(getTokenPairaddresses(batch[j]));
    }
    const pairAddressesResults = await Promise.allSettled(promises);
    pairAddressesResults.forEach((result, index) => {
      if (result.status === 'fulfilled') {
        const pairAddressesForToken = result.value;
        if(Object.keys(pairAddressesForToken).length>=2){
          Object.assign(updatedPairAddresses, pairAddressesForToken);
        }
      } else {
        logger.error(`Failed to fetch addresses for token ${batch[index]}: ${result.reason}`);
      }
    });
    if (i + 290 < tokens.length) {
      await delay(65000);
    }
  }
  // if(Object.keys(pairAddresses).length!=Object.keys(updatedPairAddresses).length){
    pairAddresses=updatedPairAddresses;
    await start_arbitrage();
  // }
}, Number(process.env.PAIR_REFRESH_MS ?? 1800000));

async function startStream2(){
  streamStarted2=true;
  try{
    accountKeysForStream= [...new Set(accountKeysForStream)];
    let is_running=false;
    const request: SubscribeRequest = {
      slots: {},
      accounts: {
          "arb":{
              account:accountKeysForStream,
              owner:[],
              filters:[]
          }
      },
      transactions: {},
      blocks: {},
      blocksMeta: {},
      accountsDataSlice: [],
      commitment: CommitmentLevel.PROCESSED, // Subscribe to processed blocks for the fastest updates
      entry: {},
      transactionsStatus: {}
    }
    clearInterval(inter3);
    inter3=setInterval(async()=>{
      try{
          if(is_running==false){
              is_running=true;
              stream2=await client.subscribe();
              const streamClosed = new Promise<void>((resolve, reject) => {
                  stream2.on("error", (error:any) => {
                      reject(error);
                      if(error.code==1||error.code==7){
                          clearInterval(inter);
                      }
                      is_running=false;
                  });
                  stream2.on("end", resolve); 
                  stream2.on("close", resolve);
              });
              let signature="";
              let prev_data:Buffer;
              stream2.on("data", async (data:any) => {
                if(data.account!=undefined){                           
                  const sig=bs58.encode(data.account.account.txnSignature);
                  if(signature!=sig){
                      signature=sig;
                      try{

                        if(prev_data!=data.account.account.data){
                            currentSlot=new BN(data.account.account.slot);
                            prev_data=data.account.account.data;
                            const poolData=data.account.account.data;
                            const poolAddress=bs58.encode(data.account.account["pubkey"]);
                            if(poolData.length==1544){
                              // console.log("Raydium clmm data",1544,"\n", bs58.encode(data.account.account.pubkey));
                              
                              findArbtrageOpportunities({
                                dex:"clmm",
                                poolAddress:poolAddress,
                                poolData:poolData,
                                poolReserves:{
                                  reserveA: new BN(0),
                                  decimalA: 0,
                                  reserveB: new BN(0),
                                  decimalB: 0,
                                  preReserveA: new BN(0),
                                  preReserveB: new BN(0)
                                },
                                sig:sig
                              });
                            }else if(poolData.length==653){
                              // console.log("Orca whirlpool data",653,"\n", bs58.encode(data.account.account.pubkey));
                              findArbtrageOpportunities({
                                dex:"orcawp",
                                poolAddress:poolAddress,
                                poolData:poolData,
                                poolReserves:{
                                  reserveA: new BN(0),
                                  decimalA: 0,
                                  reserveB: new BN(0),
                                  decimalB: 0,
                                  preReserveA: new BN(0),
                                  preReserveB: new BN(0)
                                },
                                sig:sig
                              });
                            }else if(poolData.length==904){
                              // if(poolAddress=="4CTUHtiHrPHFT4Zc1qNScrposmM7xfupU7EVDWCR7PZw"){
                              //   logger.info(sig);
                              // }
                              // console.log("Meteora dlmm data",904,"\n", bs58.encode(data.account.account.pubkey));
                              findArbtrageOpportunities({
                                dex:"dlmm",
                                poolAddress:poolAddress,
                                poolData:poolData,
                                poolReserves:{
                                  reserveA: new BN(0),
                                  decimalA: 0,
                                  reserveB: new BN(0),
                                  decimalB: 0,
                                  preReserveA: new BN(0),
                                  preReserveB: new BN(0)
                                },
                                sig:sig
                              });
                            }else if(poolData.length==1112){
                              // console.log("Meteora damm v2 data",1112,"\n", bs58.encode(data.account.account.pubkey));
                              findArbtrageOpportunities({
                                dex:"dyn2",
                                poolAddress:poolAddress,
                                poolData:poolData,
                                poolReserves:{
                                  reserveA: new BN(0),
                                  decimalA: 0,
                                  reserveB: new BN(0),
                                  decimalB: 0,
                                  preReserveA: new BN(0),
                                  preReserveB: new BN(0)
                                },
                                sig:sig
                              });
                            }else{
                              // console.log("Invalid data", poolData.length, "\n", bs58.encode(data.account.account.pubkey));
                            }
                        }

                      }catch(e){console.log(e)}
                  }
                }
              })
              await new Promise<void>((resolve, reject) => {
                  stream2.write(request, (err: null | undefined) => {
                      if (err === null || err === undefined) {
                      resolve();
                      } else {
                      reject(err);
                      }
                  });
              }).catch((reason) => {
                  throw reason;
              });
              await streamClosed;
          }
      }catch(e){
        logStreamError("stream", e)
      }
    }, 400)
  }catch(e){
    console.log("Error while creating stream...");
  }
}
async function startStream(){
  streamStarted=true;
  try{
    let is_running=false;
    const request: SubscribeRequest = {
        "slots": {},
        accounts: {},
        "transactions": {
          pumpfun: {
              "vote": false,
              "failed": false,
              accountInclude: stream_keys,
              accountExclude: [],
              accountRequired: []
          }
        },
        "blocks": {},
        "blocksMeta": {},
        "accountsDataSlice": [],
        "commitment": CommitmentLevel.PROCESSED, // Subscribe to processed blocks for the fastest updates
        entry: {},
        transactionsStatus: {}
    }
    clearInterval(inter);
    inter=setInterval(async()=>{
      try{
          if(is_running==false){
              is_running=true;
              stream=await client.subscribe();
              const streamClosed = new Promise<void>((resolve, reject) => {
                  stream.on("error", (error:any) => {
                      reject(error);
                      if(error.code==1||error.code==7){
                          clearInterval(inter);
                      }
                      is_running=false;
                  });
                  stream.on("end", resolve); 
                  stream.on("close", resolve);
              });
              let signature="";
              stream.on("data", async (data:any) => {       
                if(data.transaction!=undefined){         
                    currentSlot = new BN(data.transaction.slot);        
                    // console.log("tx", data)                  
                      const sig=bs58.encode(data.transaction.transaction.signature);
                      if(signature!=sig){
                        signature=sig;
                        let keys: string[]=[];
                        for (let i = 0; i < data.transaction.transaction.transaction.message.accountKeys.length; i++) {
                          const key = data.transaction.transaction.transaction.message.accountKeys[i];
                          keys.push(bs58.encode(key));
                        }
                        for (let i = 0; i < data.transaction.transaction.meta.loadedWritableAddresses.length; i++) {
                          const key = data.transaction.transaction.meta.loadedWritableAddresses[i];
                          keys.push(bs58.encode(key));
                        }
                        for (let i = 0; i < data.transaction.transaction.meta.loadedReadonlyAddresses.length; i++) {
                          const key = data.transaction.transaction.meta.loadedReadonlyAddresses[i];
                          keys.push(bs58.encode(key));
                        }
                        
                        for(let log of data.transaction.transaction.meta.logMessages){
                          if(log.includes("Program log: No arbitrage profit found!")){
                            return
                          }
                        };
                        
                        for (let keyIndex = 0; keyIndex < keys.length; keyIndex++) {
                          const key = keys[keyIndex];
                          for(const pairAddress of Object.keys(pairAddresses)){
                            if(pairAddress.split("_")[2]==key){
                              try {
                                const poolReserves: PoolReserves = {
                                  reserveA: new BN(0),
                                  reserveB: new BN(0),
                                  preReserveA:new BN(0),
                                  preReserveB:new BN(0),
                                  decimalA: 0,
                                  decimalB: 0
                                }
                                if(pairAddress.split("_")[1]=="pumpswap") {
                                  for (let i = 0; i < data.transaction.transaction.meta.preTokenBalances.length; i++) {
                                    const balance = data.transaction.transaction.meta.preTokenBalances[i];
                                    if(balance.owner==key){
                                      if(balance.mint=="So11111111111111111111111111111111111111112"){
                                        poolReserves.preReserveB=new BN(balance.uiTokenAmount.amount);
                                      }else if(balance.mint==pairAddress.split("_")[0]){
                                        poolReserves.preReserveA=new BN(balance.uiTokenAmount.amount); 
                                      }                                      
                                    }
                                  }
                                  for (let i = 0; i < data.transaction.transaction.meta.postTokenBalances.length; i++) {
                                    const balance = data.transaction.transaction.meta.postTokenBalances[i];
                                    if(balance.owner==key){
                                      if(balance.mint=="So11111111111111111111111111111111111111112"){
                                        poolReserves.reserveB=new BN(balance.uiTokenAmount.amount);
                                        poolReserves.decimalB=balance.uiTokenAmount.decimals;                                     
                                      }else if(balance.mint==pairAddress.split("_")[0]){
                                        poolReserves.reserveA=new BN(balance.uiTokenAmount.amount); 
                                        poolReserves.decimalA=balance.uiTokenAmount.decimals;
                                      }                                      
                                    }
                                  }
                                  if(poolReserves.reserveA.isZero() || poolReserves.reserveB.isZero()){
                                    return;
                                  }               
                                  if((pairAddresses[pairAddress][0] && pairAddresses[pairAddress][0].eq(poolReserves.reserveA)) || 
                                     (pairAddresses[pairAddress][1] && pairAddresses[pairAddress][1].eq(poolReserves.reserveB))){
                                    return;
                                  }
                                  pairAddresses[pairAddress][0]=(poolReserves.reserveA);
                                  pairAddresses[pairAddress][1]=(poolReserves.reserveB);
                                  pairAddresses[pairAddress][2]=new BN(poolReserves.decimalA);
                                  pairAddresses[pairAddress][3]=new BN(poolReserves.decimalB);    
                                  let isBuy=true;
                                  if(poolReserves.reserveB.gt(poolReserves.preReserveB)){
                                    isBuy=true;
                                  }else{
                                    isBuy = false;
                                  }
                                  // const tradeAmount = (poolReserves.reserveB.sub(poolReserves.preReserveB)).div(new BN(LAMPORTS_PER_SOL)).abs();
                                  // logger.info(`${sig}  pumpswap`);
                                  findArbtrageOpportunities({
                                    dex:"pumpswap",
                                    poolAddress:pairAddress.split("_")[2],
                                    poolReserves:poolReserves,
                                    poolData:Buffer.from([0]),
                                    sig:sig
                                  })
                                }
                                if(pairAddress.split("_")[1]=="cpmm") {
                                  const pool_accounts=pairAddress_accounts[pairAddress];
                                  if(!pool_accounts?.length) return;
                                  let wsolATA="";
                                  let tokenATA="";
                                  if(pool_accounts[0].toString()==NATIVE_MINT.toString()){
                                    wsolATA=pool_accounts[4].toString();
                                    tokenATA=pool_accounts[5].toString();
                                  }else{
                                    tokenATA=pool_accounts[4].toString();
                                    wsolATA=pool_accounts[5].toString();
                                  }
                                  const wsolAtaIndex=keys.indexOf(wsolATA);
                                  const tokenAtaIndex=keys.indexOf(tokenATA);
                                  for (let i = 0; i < data.transaction.transaction.meta.preTokenBalances.length; i++) {
                                    const balance = data.transaction.transaction.meta.preTokenBalances[i];
                                    if(balance.accountIndex==wsolAtaIndex){
                                      poolReserves.preReserveB=new BN(balance.uiTokenAmount.amount);
                                    }
                                    if(balance.accountIndex==tokenAtaIndex){
                                      poolReserves.preReserveA=new BN(balance.uiTokenAmount.amount);
                                    }
                                  }
                                  for (let i = 0; i < data.transaction.transaction.meta.postTokenBalances.length; i++) {
                                    const balance = data.transaction.transaction.meta.postTokenBalances[i];
                                    if(balance.accountIndex==wsolAtaIndex){
                                      poolReserves.reserveB=new BN(balance.uiTokenAmount.amount);
                                      poolReserves.decimalB=balance.uiTokenAmount.decimals
                                    }
                                    if(balance.accountIndex==tokenAtaIndex){
                                      poolReserves.reserveA=new BN(balance.uiTokenAmount.amount);
                                      poolReserves.decimalA=balance.uiTokenAmount.decimals
                                    }
                                  } 
                                  if(poolReserves.reserveA.isZero() || poolReserves.reserveB.isZero()){
                                    return;
                                  }                         
                                  if((pairAddresses[pairAddress][0] && pairAddresses[pairAddress][0].eq(poolReserves.reserveA)) || 
                                     (pairAddresses[pairAddress][1] && pairAddresses[pairAddress][1].eq(poolReserves.reserveB))){
                                    return;
                                  }
                                  pairAddresses[pairAddress][0]=(poolReserves.reserveA);
                                  pairAddresses[pairAddress][1]=(poolReserves.reserveB);
                                  pairAddresses[pairAddress][2]=new BN(poolReserves.decimalA);
                                  pairAddresses[pairAddress][3]=new BN(poolReserves.decimalB);  
                                  let isBuy=true;
                                  if(poolReserves.reserveB.gt(poolReserves.preReserveB)){
                                    isBuy=true;
                                  }else{
                                    isBuy = false;
                                  }
                                  // logger.info(`${sig}  cpmm`);
                                  // const tradeAmount = (poolReserves.reserveB.sub(poolReserves.preReserveB)).div(new BN(LAMPORTS_PER_SOL)).abs();
                                  findArbtrageOpportunities({
                                    dex:"cpmm",
                                    poolAddress:pairAddress.split("_")[2],
                                    poolReserves:poolReserves,
                                    poolData:Buffer.from([0]),
                                    sig:sig
                                  })
                                }
                                if(pairAddress.split("_")[1]=="dyn2") {
                                  const pool_accounts=pairAddress_accounts[pairAddress];
                                  if(!pool_accounts?.length) return;
                                  let wsolATA="";
                                  let tokenATA="";
                                  if(pool_accounts[0].toString()==NATIVE_MINT.toString()){
                                    wsolATA=pool_accounts[3].toString();
                                    tokenATA=pool_accounts[4].toString();
                                  }else{
                                    tokenATA=pool_accounts[3].toString();
                                    wsolATA=pool_accounts[4].toString();
                                  }
                                  const wsolAtaIndex=keys.indexOf(wsolATA);
                                  const tokenAtaIndex=keys.indexOf(tokenATA);
                                  for (let i = 0; i < data.transaction.transaction.meta.preTokenBalances.length; i++) {
                                    const balance = data.transaction.transaction.meta.preTokenBalances[i];
                                    if(balance.accountIndex==wsolAtaIndex){
                                      poolReserves.preReserveB=new BN(balance.uiTokenAmount.amount);
                                    }
                                    if(balance.accountIndex==tokenAtaIndex){
                                      poolReserves.preReserveA=new BN(balance.uiTokenAmount.amount);
                                    }
                                  }
                                  for (let i = 0; i < data.transaction.transaction.meta.postTokenBalances.length; i++) {
                                    const balance = data.transaction.transaction.meta.postTokenBalances[i];
                                    if(balance.accountIndex==wsolAtaIndex){
                                      poolReserves.reserveB=new BN(balance.uiTokenAmount.amount);
                                      poolReserves.decimalB=balance.uiTokenAmount.decimals
                                    }
                                    if(balance.accountIndex==tokenAtaIndex){
                                      poolReserves.reserveA=new BN(balance.uiTokenAmount.amount);
                                      poolReserves.decimalA=balance.uiTokenAmount.decimals
                                    }
                                  } 
                                  if(poolReserves.reserveA.isZero() || poolReserves.reserveB.isZero()){
                                    return;
                                  }                   
                                  if((pairAddresses[pairAddress][0] && pairAddresses[pairAddress][0].eq(poolReserves.reserveA)) || 
                                     (pairAddresses[pairAddress][1] && pairAddresses[pairAddress][1].eq(poolReserves.reserveB))){
                                    return;
                                  }
                                  pairAddresses[pairAddress][0]=(poolReserves.reserveA);
                                  pairAddresses[pairAddress][1]=(poolReserves.reserveB);
                                  pairAddresses[pairAddress][2]=new BN(poolReserves.decimalA);
                                  pairAddresses[pairAddress][3]=new BN(poolReserves.decimalB);  
                                  let isBuy=true;
                                  if(poolReserves.reserveB.gt(poolReserves.preReserveB)){
                                    isBuy=true;
                                  }else{
                                    isBuy = false;
                                  }
                                  // logger.info(`${sig}  dyn2`);
                                  // const tradeAmount = (poolReserves.reserveB.sub(poolReserves.preReserveB)).div(new BN(LAMPORTS_PER_SOL)).abs();
                                  // findArbtrageOpportunities(pairAddress, "dyn2", isBuy, tradeAmount, poolReserves, sig)


                                }
                                if(pairAddress.split("_")[1]=="dlmm") {
                                  // if(key=="4CTUHtiHrPHFT4Zc1qNScrposmM7xfupU7EVDWCR7PZw"){
                                  //   logger.info(`Dlmm ,  ${sig}`);
                                  // }
                                  for (let i = 0; i < data.transaction.transaction.meta.preTokenBalances.length; i++) {
                                    const balance = data.transaction.transaction.meta.preTokenBalances[i];
                                    if(balance.owner==key){
                                      if(balance.mint=="So11111111111111111111111111111111111111112"){
                                        poolReserves.preReserveB=new BN(balance.uiTokenAmount.amount);
                                        
                                      }else if(balance.mint==pairAddress.split("_")[0]){
                                        poolReserves.preReserveA=new BN(balance.uiTokenAmount.amount); 
                                      }
                                      
                                    }
                                  }
                                  for (let i = 0; i < data.transaction.transaction.meta.postTokenBalances.length; i++) {
                                    const balance = data.transaction.transaction.meta.postTokenBalances[i];
                                    if(balance.owner==key){
                                      if(balance.mint=="So11111111111111111111111111111111111111112"){
                                        poolReserves.reserveB=new BN(balance.uiTokenAmount.amount);
                                        poolReserves.decimalB=balance.uiTokenAmount.decimals;
                                        
                                      }else if(balance.mint==pairAddress.split("_")[0]){
                                        poolReserves.reserveA=new BN(balance.uiTokenAmount.amount); 
                                        poolReserves.decimalA=balance.uiTokenAmount.decimals;
                                      }
                                      
                                    }
                                  }
                                  if(poolReserves.reserveA.isZero() || poolReserves.reserveB.isZero()){
                                    return;
                                  }               
                                  if((pairAddresses[pairAddress][0] && pairAddresses[pairAddress][0].eq(poolReserves.reserveA)) || 
                                     (pairAddresses[pairAddress][1] && pairAddresses[pairAddress][1].eq(poolReserves.reserveB))){
                                    return;
                                  }
                                  pairAddresses[pairAddress][0]=(poolReserves.reserveA);
                                  pairAddresses[pairAddress][1]=(poolReserves.reserveB);
                                  pairAddresses[pairAddress][2]=new BN(poolReserves.decimalA);
                                  pairAddresses[pairAddress][3]=new BN(poolReserves.decimalB);    
                                  let isBuy=true;
                                  if(poolReserves.reserveB.gt(poolReserves.preReserveB)){
                                    isBuy=true;
                                  }else{
                                    isBuy = false;
                                  }
                                  // logger.info(`${sig}  dlmm`);
                                  // const tradeAmount = (poolReserves.reserveB.sub(poolReserves.preReserveB)).div(new BN(LAMPORTS_PER_SOL)).abs();
                                  // findArbtrageOpportunities(pairAddress, "dlmm", isBuy, tradeAmount, poolReserves, sig)

                                }
                                if(pairAddress.split("_")[1]=="raydium") {
                                  const pool_accounts=pairAddress_accounts[pairAddress];
                                  if(!pool_accounts?.length) return;
                                  let wsolATA="";
                                  let tokenATA="";
                                  if(pool_accounts[0].toString()==NATIVE_MINT.toString()){
                                    wsolATA=pool_accounts[3].toString();
                                    tokenATA=pool_accounts[4].toString();
                                  }else{
                                    tokenATA=pool_accounts[3].toString();
                                    wsolATA=pool_accounts[4].toString();
                                  }
                                  const wsolAtaIndex=keys.indexOf(wsolATA);
                                  const tokenAtaIndex=keys.indexOf(tokenATA);
                                  for (let i = 0; i < data.transaction.transaction.meta.preTokenBalances.length; i++) {
                                    const balance = data.transaction.transaction.meta.preTokenBalances[i];
                                    if(balance.accountIndex==wsolAtaIndex){
                                      poolReserves.preReserveB=new BN(balance.uiTokenAmount.amount);
                                    }
                                    if(balance.accountIndex==tokenAtaIndex){
                                      poolReserves.preReserveA=new BN(balance.uiTokenAmount.amount);
                                    }
                                  }
                                  for (let i = 0; i < data.transaction.transaction.meta.postTokenBalances.length; i++) {
                                    const balance = data.transaction.transaction.meta.postTokenBalances[i];
                                    if(balance.accountIndex==wsolAtaIndex){
                                      poolReserves.reserveB=new BN(balance.uiTokenAmount.amount);
                                      poolReserves.decimalB=balance.uiTokenAmount.decimals
                                    }
                                    if(balance.accountIndex==tokenAtaIndex){
                                      poolReserves.reserveA=new BN(balance.uiTokenAmount.amount);
                                      poolReserves.decimalA=balance.uiTokenAmount.decimals
                                    }
                                  } 
                                  if(poolReserves.reserveA.isZero() || poolReserves.reserveB.isZero()){
                                    return;
                                  }             
                                  if((pairAddresses[pairAddress][0] && pairAddresses[pairAddress][0].eq(poolReserves.reserveA)) || 
                                     (pairAddresses[pairAddress][1] && pairAddresses[pairAddress][1].eq(poolReserves.reserveB))){
                                    return;
                                  }
                                  pairAddresses[pairAddress][0]=poolReserves.reserveA;
                                  pairAddresses[pairAddress][1]=poolReserves.reserveB;
                                  pairAddresses[pairAddress][2]=new BN(poolReserves.decimalA);
                                  pairAddresses[pairAddress][3]=new BN(poolReserves.decimalB);
                                  let isBuy=true;
                                  if(poolReserves.reserveB.gt(poolReserves.preReserveB)){
                                    isBuy=true;
                                  }else{
                                    isBuy = false;
                                  }
                                  // logger.info(`${sig}  raydium`);
                                  // const tradeAmount = (poolReserves.reserveB.sub(poolReserves.preReserveB)).div(new BN(LAMPORTS_PER_SOL)).abs();
                                  // console.log(key, poolReserves.reserveA.toString(), poolReserves.reserveB.toString());
                                  findArbtrageOpportunities({
                                    dex:"raydium",
                                    poolAddress:pairAddress.split("_")[2],
                                    poolReserves:poolReserves,
                                    poolData:Buffer.from([0]),
                                    sig:sig
                                  })                                }
                                if(pairAddress.split("_")[1]=="clmm") {
                                  for (let i = 0; i < data.transaction.transaction.meta.preTokenBalances.length; i++) {
                                    const balance = data.transaction.transaction.meta.preTokenBalances[i];
                                    if(balance.owner==key){
                                      if(balance.mint=="So11111111111111111111111111111111111111112"){
                                        poolReserves.preReserveB=new BN(balance.uiTokenAmount.amount);
                                        
                                      }else if(balance.mint==pairAddress.split("_")[0]){
                                        poolReserves.preReserveA=new BN(balance.uiTokenAmount.amount); 
                                      }
                                      
                                    }
                                  }
                                  for (let i = 0; i < data.transaction.transaction.meta.postTokenBalances.length; i++) {
                                    const balance = data.transaction.transaction.meta.postTokenBalances[i];
                                    if(balance.owner==key){
                                      if(balance.mint=="So11111111111111111111111111111111111111112"){
                                        poolReserves.reserveB=new BN(balance.uiTokenAmount.amount);
                                        poolReserves.decimalB=balance.uiTokenAmount.decimals;
                                        
                                      }else if(balance.mint==pairAddress.split("_")[0]){
                                        poolReserves.reserveA=new BN(balance.uiTokenAmount.amount); 
                                        poolReserves.decimalA=balance.uiTokenAmount.decimals;
                                      }
                                      
                                    }
                                  } 
                                  if(poolReserves.reserveA.isZero() || poolReserves.reserveB.isZero()){
                                    return;
                                  }             
                                  if((pairAddresses[pairAddress][0] && pairAddresses[pairAddress][0].eq(poolReserves.reserveA)) || 
                                     (pairAddresses[pairAddress][1] && pairAddresses[pairAddress][1].eq(poolReserves.reserveB))){
                                    return;
                                  }
                                  pairAddresses[pairAddress][0]=(poolReserves.reserveA);
                                  pairAddresses[pairAddress][1]=(poolReserves.reserveB);
                                  pairAddresses[pairAddress][2]=new BN(poolReserves.decimalA);
                                  pairAddresses[pairAddress][3]=new BN(poolReserves.decimalB);
                                  let isBuy=true;
                                  if(poolReserves.reserveB.gt(poolReserves.preReserveB)){
                                    isBuy=true;
                                  }else{
                                    isBuy = false;
                                  }
                                  // logger.info(`${sig}  clmm`);
                                  // const tradeAmount = (poolReserves.reserveB.sub(poolReserves.preReserveB)).div(new BN(LAMPORTS_PER_SOL)).abs();
                                  // findArbtrageOpportunities(pairAddress, "clmm", isBuy, tradeAmount, poolReserves, sig)
                                }
                                if(pairAddress.split("_")[1]=="orcawp") {
                                  // if(key=="GpuWWgWuiWkn9fL6EQK55rdwQExkwQJsjuDmhnT3otdK"){
                                  //   // console.log("orca", sig)
                                  //   logger.info(`orca ,  ${sig}`);
                                  // }
                                  for (let i = 0; i < data.transaction.transaction.meta.preTokenBalances.length; i++) {
                                    const balance = data.transaction.transaction.meta.preTokenBalances[i];
                                    if(balance.owner==key){
                                      if(balance.mint=="So11111111111111111111111111111111111111112"){
                                        poolReserves.preReserveB=new BN(balance.uiTokenAmount.amount);
                                        
                                      }else if(balance.mint==pairAddress.split("_")[0]){
                                        poolReserves.preReserveA=new BN(balance.uiTokenAmount.amount); 
                                      }
                                      
                                    }
                                  }
                                  for (let i = 0; i < data.transaction.transaction.meta.postTokenBalances.length; i++) {
                                    const balance = data.transaction.transaction.meta.postTokenBalances[i];
                                    if(balance.owner==key){
                                      if(balance.mint=="So11111111111111111111111111111111111111112"){
                                        poolReserves.reserveB=new BN(balance.uiTokenAmount.amount);
                                        poolReserves.decimalB=balance.uiTokenAmount.decimals;
                                        
                                      }else if(balance.mint==pairAddress.split("_")[0]){
                                        poolReserves.reserveA=new BN(balance.uiTokenAmount.amount); 
                                        poolReserves.decimalA=balance.uiTokenAmount.decimals;
                                      }
                                      
                                    }
                                  }
                                  if(poolReserves.reserveA.isZero() || poolReserves.reserveB.isZero()){
                                    return;
                                  }           
                                  if((pairAddresses[pairAddress][0] && pairAddresses[pairAddress][0].eq(poolReserves.reserveA)) || 
                                     (pairAddresses[pairAddress][1] && pairAddresses[pairAddress][1].eq(poolReserves.reserveB))){
                                    return;
                                  }
                                  pairAddresses[pairAddress][0]=(poolReserves.reserveA);
                                  pairAddresses[pairAddress][1]=(poolReserves.reserveB);
                                  pairAddresses[pairAddress][2]=new BN(poolReserves.decimalA);
                                  pairAddresses[pairAddress][3]=new BN(poolReserves.decimalB);    
                                  let isBuy=true;
                                  if(poolReserves.reserveB.gt(poolReserves.preReserveB)){
                                    isBuy=true;
                                  }else{
                                    isBuy = false;
                                  }
                                  // logger.info(`${sig}  orcawp`);
                                  // const tradeAmount = (poolReserves.reserveB.sub(poolReserves.preReserveB)).div(new BN(LAMPORTS_PER_SOL)).abs();
                                  // findArbtrageOpportunities(pairAddress, "orcawp", isBuy, tradeAmount, poolReserves, sig)
                                     
                                  // const swapOutput = await calculateSwapOutput("orcawp", pairAddress.split("_")[2], new BN(QUOTE_AMOUNT*LAMPORTS_PER_SOL), {
                                  //   reserves: poolReserves,
                                  //   inputTokenMint: "So11111111111111111111111111111111111111112",
                                  //   isSOLToToken: true,
                                  //   supply: supply
                                  // });
                                  // if(swapOutput==undefined) break;
                                  // pairAddress_accounts[pairAddress]=swapOutput.accounts;
                                  // findArbtrageOpportunities(pairAddress, swapOutput.accounts, swapOutput.outputAmount, currentSlot);
                                }
                              } catch (error: any) {
                                console.log(error)
                              }
                            }
                          }
                        }
                      }
                  }
              })
              await new Promise<void>((resolve, reject) => {
                  stream.write(request, (err: null | undefined) => {
                      if (err === null || err === undefined) {
                      resolve();
                      } else {
                      reject(err);
                      }
                  });
              }).catch((reason) => {
                  throw reason;
              });
              await streamClosed;
          }
      }catch(e){
        logStreamError("stream2", e)
      }
    }, 400)
  }catch(e){
    console.log("Error while creating stream...")
  }
}
async function startStream3(){
  try{
    let is_running=false;
    const request: SubscribeRequest = {
        "slots": {},
        accounts: {},
        "transactions": {},
        "blocks": {},
        "blocksMeta": {"blockmetadata": {}},
        "accountsDataSlice": [],
        "commitment": CommitmentLevel.PROCESSED, // Subscribe to processed blocks for the fastest updates
        entry: {},
        transactionsStatus: {}
    }
    clearInterval(inter5);
    inter5=setInterval(async()=>{
      try{
          if(is_running==false){
              is_running=true;
              stream3=await client.subscribe();
              const streamClosed = new Promise<void>((resolve, reject) => {
                  stream3.on("error", (error:any) => {
                      reject(error);
                      if(error.code==1||error.code==7){
                          clearInterval(inter5);
                      }
                      is_running=false;
                  });
                  stream3.on("end", resolve); 
                  stream3.on("close", resolve);
              });
              let signature="";
              stream3.on("data", async (data:any) => {       
                if(data.blockMeta!=undefined){         
                    blockTime=new BN(data.blockMeta.blockTime.timestamp);
                }
              })
              await new Promise<void>((resolve, reject) => {
                  stream3.write(request, (err: null | undefined) => {
                      if (err === null || err === undefined) {
                      resolve();
                      } else {
                      reject(err);
                      }
                  });
              }).catch((reason) => {
                  throw reason;
              });
              await streamClosed;
          }
      }catch(e){
        logStreamError("stream3", e)
      }
    }, 400)
  }catch(e){
    console.log("Error while creating stream...")
  }
}
async function start_arbitrage(){
  try{
    jitoTipAccount=await getJitoTipAccounts();
    bundleTipAccount=jitoTipAccount;
  }catch(e){ logger.error(`Jito tip accounts: ${e}`); }
  clearInterval(inter2);
  accountKeysForStream=[];
  stream_keys=[];
  Object.keys(pairAddresses).map((key:string)=>{
    if(excludedPairAddresses.includes(key.split("_")[2])){
      delete pairAddresses[key];
    }
  });
  rebuildPoolIndex();
  logger.info(`Total pair counts-> ${Object.keys(pairAddresses).length} (${mintToPairKeys.size} tokens)`);
  // Line 1193: initial fetch runs in worker thread; main thread waits for result
  await getDexAccountsForPairs(connection, false);
  // Lines 1194-1196: interval runs getDexAccountsForPairs in worker thread (noAwait = don't block main thread)
  inter2=setInterval(()=>{
     getDexAccountsForPairs(connection, true, { noAwait: true });
  }, DEX_ACCOUNTS_REFRESH_MS);
  const pairAddressKeys = Object.keys(pairAddresses);
  for (let i = 0; i < pairAddressKeys.length; i++) {
    const key = pairAddressKeys[i];
    stream_keys.push(key.split("_")[2]);
    if(key.split("_")[1]=="clmm"||key.split("_")[1]=="orcawp"||key.split("_")[1]=="dlmm"||key.split("_")[1]=="dyn2"){
      accountKeysForStream.push(key.split("_")[2]);
    }
  }
  logger.info(`Total account counts-> ${accountKeysForStream.length}`);
  if(!streamStarted){
    startStream();
  }else{
    const request: SubscribeRequest = {
      "slots": {},
      accounts: {},
      "transactions": {
        pumpfun: {
            "vote": false,
            "failed": false,
            accountInclude: stream_keys,
            accountExclude: [],
            accountRequired: []
        }
      },
      "blocks": {},
      "blocksMeta": {},
      "accountsDataSlice": [],
      "commitment": CommitmentLevel.PROCESSED, // Subscribe to processed blocks for the fastest updates
      entry: {},
      transactionsStatus: {}
    };
    await new Promise<void>((resolve, reject) => {
      stream.write(request, (err: null | undefined) => {
          if (err === null || err === undefined) {
          resolve();
          } else {
          reject(err);
          }
      });
    }).catch((reason) => {
        throw reason;
    });
  }
  
  if(!streamStarted2){
    startStream2();
  }else{
    const request: SubscribeRequest = {
      slots: {},
      accounts: {
          "arb":{
              account:accountKeysForStream,
              owner:[],
              filters:[]
          }
      },
      transactions: {},
      blocks: {},
      blocksMeta: {},
      accountsDataSlice: [],
      commitment: CommitmentLevel.PROCESSED, // Subscribe to processed blocks for the fastest updates
      entry: {},
      transactionsStatus: {}
    }
    await new Promise<void>((resolve, reject) => {
      stream2.write(request, (err: null | undefined) => {
          if (err === null || err === undefined) {
          resolve();
          } else {
          reject(err);
          }
      });
    }).catch((reason) => {
        throw reason;
    });
  }
  
}
// One line per stream per 30 s instead of a full gRPC stack trace every retry.
const streamErrorAt: Record<string, number> = {};
function logStreamError(name: string, e: unknown) {
  const now = Date.now();
  if (now - (streamErrorAt[name] ?? 0) < 30000) return;
  streamErrorAt[name] = now;
  const err = e as { details?: string; message?: string };
  logger.warn(`gRPC ${name} down: ${err?.details ?? err?.message ?? String(e)}`.slice(0, 200));
}

let preTradeAmount=BigInt(0);
async function findArbtrageOpportunities(
  params:{
    dex:string,
    poolAddress:string,
    poolData:Buffer,
    poolReserves:PoolReserves,
    sig:string,
    /** Raw-unit price from a stream that has no pool account data (pumpapi). */
    priceOverride?:number,
    /** Pool fee in percent, from the same stream. */
    feePctOverride?:number,
  }
){
  try{
    let newPrice=0;
    const fee=params.feePctOverride ?? await getDexFee(connection, params);

    const pairAddress=poolToPairKey.get(params.poolAddress) ?? "";
    if(!pairAddress) return;
    if(params.priceOverride!==undefined){
      newPrice=params.priceOverride;
    }else if(params.dex=="pumpswap"||params.dex=="cpmm"||params.dex=="raydium"){
      newPrice=Number(params.poolReserves.reserveB)/Number(params.poolReserves.reserveA);
    }else if (params.dex == "clmm") {
      const sqrtPrice=new BN(params.poolData.slice(253, 253 + 16).reverse());
      const mintA=bs58.encode(Uint8Array.from(params.poolData.slice(73,73+32)));
      newPrice=SqrtPriceMath.sqrtPriceX64ToPrice(sqrtPrice, 0, 0).toNumber();
      if(mintA==NATIVE_MINT.toString()){
        newPrice=1/newPrice;
      }
    }else if (params.dex == "orcawp") {
      const sqrtPrice=new BN(params.poolData.slice(65, 65 + 16).reverse());
      const mintA=bs58.encode(Uint8Array.from(params.poolData.slice(101, 101 + 32)));
      newPrice=SqrtPriceMath.sqrtPriceX64ToPrice(sqrtPrice, 0, 0).toNumber();
      if(mintA==NATIVE_MINT.toString()){
        newPrice=1/newPrice;
      }
    }else if(params.dex=="dlmm"){
      let active_id = new BN(params.poolData.slice(76, 76 + 4).reverse()).toNumber();
      if(active_id>4294901760){
        active_id-=4294967296
      }
      const bin_step =new BN(params.poolData.slice(80, 80+2)).toNumber();
      newPrice=getPriceOfBinByBinId(active_id, bin_step).toNumber();
      const mintA=bs58.encode(Uint8Array.from(params.poolData.slice(88,88+32)));
      if(mintA==NATIVE_MINT.toString()){
        newPrice=1/newPrice;
      }
    }else if(params.dex=="dyn2"){
      const sqrtPrice=new BN(params.poolData.slice(456, 456 + 16).reverse());
      const mintA=bs58.encode(Uint8Array.from(params.poolData.slice(168, 168 + 32)));
      newPrice=getPriceFromSqrtPrice(sqrtPrice,0, 0).toNumber();
      if(mintA==NATIVE_MINT.toString()){
        newPrice=1/newPrice;
      }
    }
    
    if(newPrice==0 || fee==undefined || fee==0) return;
    // if(params.poolAddress=="GpuWWgWuiWkn9fL6EQK55rdwQExkwQJsjuDmhnT3otdK"){
    //   // console.log("orca", sig)
    //   logger.info(`orca ,  ${newPrice}`);
    // }
    prices[params.poolAddress]=newPrice;
    fees[params.poolAddress]=fee;
    // console.log(fees)
    // if(currentSlot.isZero()||blockTime.isZero()) return;
    const pairAddressesForArbtrage=mintToPairKeys.get(pairAddress.split("_")[0]) ?? [];
    let minPrice=10000000000;
    let maxPrice=0;
    let minPriceAddress="";
    let maxPriceAddress="";
    for(let pairAddressForArbtrage of pairAddressesForArbtrage){
      if(prices[pairAddressForArbtrage.split("_")[2]]==undefined) continue;
      if(prices[pairAddressForArbtrage.split("_")[2]]<minPrice){
        minPrice=prices[pairAddressForArbtrage.split("_")[2]];
        minPriceAddress=pairAddressForArbtrage;
      }
      if(prices[pairAddressForArbtrage.split("_")[2]]>maxPrice){
        maxPrice=prices[pairAddressForArbtrage.split("_")[2]];
        maxPriceAddress=pairAddressForArbtrage;
      }
    }
    const buyFee=fees[minPriceAddress.split("_")[2]];
    const sellFee=fees[maxPriceAddress.split("_")[2]];
    const totalFee=(buyFee+sellFee)/100;
    let tradeAmount=BigInt(QUOTE_AMOUNT*LAMPORTS_PER_SOL);
    const reserveA=pairAddresses[minPriceAddress][1];
    const reserveB=pairAddresses[maxPriceAddress][1];
    let ratio=(maxPrice - minPrice) / minPrice;
    const prevRatio=ratios[pairAddress.split("_")[0]]
    ratios[pairAddress.split("_")[0]]=ratio;
    if(prevRatio==undefined) return;
    if(prevRatio==ratio) return;
    if(totalFee>=ratio) return;
    spreadCandidates++;
    if(!reserveA.isZero() &&!reserveB.isZero()){
      const baseAmount = min(reserveA, reserveB).div(new BN(10));
      const SCALE = 1_000_000;
      const scaledRatio = Math.floor((ratio-totalFee) * SCALE);
      const amount = baseAmount.mul(new BN(scaledRatio)).div(new BN(SCALE));
      tradeAmount=BigInt(amount.toNumber());
    }
    if(tradeAmount==preTradeAmount) return;
    preTradeAmount=tradeAmount;
    // if(tradeAmount<0.1*LAMPORTS_PER_SOL) return;
    const profit=Number(tradeAmount)*(ratio-totalFee)/100;
    if(profit<MINIMUM_PROFIT*LAMPORTS_PER_SOL) return;
    // console.log(totalFee, ratio, tradeAmount, profit);
    tryArbSwap(minPriceAddress, maxPriceAddress, params.sig, tradeAmount,ratio, profit)

  }catch(e){console.log(e)}
}
let tx_sig=""
let lastAlertAt=0;
let lastSendAt=0;
const SEND_COOLDOWN_MS=Number(process.env.SEND_COOLDOWN_MS ?? 300);
const CU_LIMIT=Number(process.env.CU_LIMIT ?? 700_000);
const CU_PRICE_MICROLAMPORTS=Number(process.env.CU_PRICE_MICROLAMPORTS ?? 1000);
async function tryArbSwap(sourceAddress:string, destinationAddress:string, bigTxSig:string, initialAmount:bigint, ratio:number, profit:number){
  if(ARB_PROGRAM==="smb") return trySmbArb(sourceAddress, destinationAddress, bigTxSig, ratio, profit);
  try{
    const token=sourceAddress.split("_")[0];
    const mints:MintInfo[]=[
      {mint:NATIVE_MINT, is2022:false},
      {mint:new PublicKey(token), is2022:isToken2022Bitmap[token]}
    ];
      let hop1:HopPoolAccounts={
        dexProgram: DexProgram.PumpAmm,
        dexProgramId: new PublicKey("LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo"),
        accounts: [],
        inTokenIs2022: false,
        outTokenIs2022: false
      };
      let hop2:HopPoolAccounts={
        dexProgram: DexProgram.PumpAmm,
        dexProgramId: new PublicKey("LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo"),
        accounts: [],
        inTokenIs2022: false,
        outTokenIs2022: false
      };
      const hop_1_dex=sourceAddress.split("_")[1];
      const hop_2_dex=destinationAddress.split("_")[1];
      const hop_1_pairaddress=sourceAddress.split("_")[2];
      const hop_2_pairaddress=destinationAddress.split("_")[2];
      let accounts1=pairAddress_accounts[sourceAddress];
      let accounts2=pairAddress_accounts[destinationAddress];
      let hop_1_accounts:PublicKey[]=[];
      let hop_2_accounts:PublicKey[]=[];
      let hop_1_isBaseSwap=true;
      let hop_2_isBaseSwap=true;
      if(!accounts1?.length || !accounts2?.length) return;
      accounts1=[...accounts1];
      accounts2=[...accounts2];
      const hop_1_XMint=accounts1.shift();
      const hop_2_XMint=accounts2.shift();
      if(hop_1_XMint==undefined||hop_2_XMint==undefined) return;
      if(hop_1_XMint.equals(mints[0].mint)){
        hop_1_isBaseSwap=true;
      }else{
        hop_1_isBaseSwap=false;
      }
      if(hop_2_XMint.equals(mints[0].mint)){
        hop_2_isBaseSwap=false;
      }else{
        hop_2_isBaseSwap=true;
      }
      const [userBaseAta] = PublicKey.findProgramAddressSync(
        [
          wallet.publicKey.toBuffer(),      // owner/wallet
          TOKEN_PROGRAM_ID.toBuffer(),  // token program
          new PublicKey(token).toBuffer(),        // mint
        ],
        ASSOCIATED_TOKEN_PROGRAM_ID  // ATA program derives the PDA
      );
      const [userQuoteAta] = PublicKey.findProgramAddressSync(
        [
          wallet.publicKey.toBuffer(),      // owner/wallet
          TOKEN_PROGRAM_ID.toBuffer(),  // token program
          new PublicKey("So11111111111111111111111111111111111111112").toBuffer(),        // mint
        ],
        ASSOCIATED_TOKEN_PROGRAM_ID  // ATA program derives the PDA
      );
      if(hop_1_dex=="pumpswap"){
        hop_1_accounts=accounts1;
        hop1={
          dexProgram:DexProgram.PumpAmm,
          dexProgramId:program_ids.pumpswap,
          inTokenIs2022:mints[0].is2022,
          outTokenIs2022:mints[1].is2022,
          isBaseSwap:hop_1_isBaseSwap,
          accounts:hop_1_accounts
        };
      }
      if(hop_1_dex=="clmm"){
        accounts1.splice(-3);
        hop_1_accounts=accounts1
        hop1={
          dexProgram:DexProgram.RaydiumClmm,
          dexProgramId:program_ids.clmm,
          inTokenIs2022:mints[0].is2022,
          outTokenIs2022:true,
          isBaseSwap:hop_1_isBaseSwap,
          accounts:hop_1_accounts
        };
      }
      if(hop_1_dex=="cpmm"){
        hop_1_accounts=accounts1;
        hop1={
          dexProgram:DexProgram.RaydiumCpmm,
          dexProgramId:program_ids.cpmm,
          inTokenIs2022:mints[0].is2022,
          outTokenIs2022:mints[1].is2022,
          isBaseSwap:hop_1_isBaseSwap,
          accounts:hop_1_accounts
        };
      }
      if(hop_1_dex=="orcawp"){
        if(accounts1[3]==undefined||accounts1[4]==undefined||accounts1[5]==undefined){
          return;
        }
        hop_1_accounts.push(accounts1[0]);
        hop_1_accounts.push(accounts1[1]);
        hop_1_accounts.push(accounts1[2]);
        hop_1_accounts.push(accounts1[3]);
        hop_1_accounts.push(accounts1[4]);
        hop_1_accounts.push(accounts1[5]);
        hop_1_accounts.push(accounts1[9]);
        if(mints[1].is2022){
          hop_1_accounts.push(accounts1[10]);
        }
        hop1={
          dexProgram:DexProgram.OrcaWhirlpool,
          dexProgramId:program_ids.orcawp,
          inTokenIs2022:mints[0].is2022,
          outTokenIs2022:mints[1].is2022,
          isBaseSwap:hop_1_isBaseSwap,
          accounts:hop_1_accounts
        };
      }
      if(hop_1_dex=="dlmm"){
        if(accounts1[7]==undefined||accounts1[8]==undefined||accounts1[9]==undefined){
          return;
        }
        accounts1.splice(-3);
        hop_1_accounts=accounts1;
        if(!mints[1].is2022){
          hop_1_accounts.splice(6,1);
        }
        hop1={
          dexProgram:DexProgram.MeteoraDlmm,
          dexProgramId:program_ids.dlmm,
          inTokenIs2022:mints[0].is2022,
          outTokenIs2022:mints[1].is2022,
          isBaseSwap:hop_1_isBaseSwap,
          accounts:hop_1_accounts
        };
      }
      if(hop_1_dex=="dyn2"){
        hop_1_accounts=accounts1;
        hop1={
          dexProgram:DexProgram.MeteoraDammV2,
          dexProgramId:program_ids.dyn2,
          inTokenIs2022:mints[0].is2022,
          outTokenIs2022:mints[1].is2022,
          isBaseSwap:hop_1_isBaseSwap,
          accounts:hop_1_accounts
        };
      }
      if(hop_1_dex=="raydium"){
        hop_1_accounts=accounts1;
        hop1={
          dexProgram:DexProgram.RaydiumAmmV4,
          dexProgramId:program_ids.raydium,
          inTokenIs2022:mints[0].is2022,
          outTokenIs2022:mints[1].is2022,
          isBaseSwap:hop_1_isBaseSwap,
          accounts:hop_1_accounts
        };
      }

      if(hop_2_dex=="pumpswap"){
        hop_2_accounts=accounts2;
        hop2={
          dexProgram:DexProgram.PumpAmm,
          dexProgramId:program_ids.pumpswap,
          inTokenIs2022:mints[1].is2022,
          outTokenIs2022:mints[0].is2022,
          isBaseSwap:hop_2_isBaseSwap,
          accounts:hop_2_accounts
        };
      }
      if(hop_2_dex=="clmm"){
        hop_2_accounts.push(accounts2[0]);
        hop_2_accounts.push(accounts2[1]);
        hop_2_accounts.push(accounts2[2]);
        hop_2_accounts.push(accounts2[3]);
        hop_2_accounts.push(accounts2[4]);
        hop_2_accounts.push(accounts2[5]);
        hop_2_accounts.push(accounts2[9]);
        hop_2_accounts.push(accounts2[10]);
        hop_2_accounts.push(accounts2[11]);
        hop2={
          dexProgram:DexProgram.RaydiumClmm,
          dexProgramId:program_ids.clmm,
          inTokenIs2022:true,
          outTokenIs2022:mints[0].is2022,
          isBaseSwap:hop_2_isBaseSwap,
          accounts:hop_2_accounts
        };
      }
      if(hop_2_dex=="cpmm"){
        hop_2_accounts=accounts2;
        hop2={
          dexProgram:DexProgram.RaydiumCpmm,
          dexProgramId:program_ids.cpmm,
          inTokenIs2022:mints[1].is2022,
          outTokenIs2022:mints[0].is2022,
          isBaseSwap:hop_2_isBaseSwap,
          accounts:hop_2_accounts
        };
      }
      if(hop_2_dex=="orcawp"){
        if(accounts2[6]==undefined||accounts2[7]==undefined||accounts2[8]==undefined){
          return;
        }
        hop_2_accounts.push(accounts2[0]);
        hop_2_accounts.push(accounts2[1]);
        hop_2_accounts.push(accounts2[2]);
        hop_2_accounts.push(accounts2[6]);
        hop_2_accounts.push(accounts2[7]);
        hop_2_accounts.push(accounts2[8]);
        hop_2_accounts.push(accounts2[9]);
        if(mints[1].is2022){
          hop_2_accounts.push(accounts2[10]);
        }
        hop2={
          dexProgram:DexProgram.OrcaWhirlpool,
          dexProgramId:program_ids.orcawp,
          inTokenIs2022:mints[1].is2022,
          outTokenIs2022:mints[0].is2022,
          isBaseSwap:hop_2_isBaseSwap,
          accounts:hop_2_accounts
        };
      }
      if(hop_2_dex=="dlmm"){
        if(accounts2[12]==undefined||accounts2[10]==undefined||accounts2[11]==undefined){
          return;
        }
        hop_2_accounts.push(accounts2[0]);
        hop_2_accounts.push(accounts2[1]);
        hop_2_accounts.push(accounts2[2]);
        hop_2_accounts.push(accounts2[3]);
        hop_2_accounts.push(accounts2[4]);
        hop_2_accounts.push(accounts2[5]);
        if(mints[1].is2022){
          hop_2_accounts.push(accounts2[6]);
        }
        hop_2_accounts.push(accounts2[7]);
        hop_2_accounts.push(accounts2[11]);
        hop_2_accounts.push(accounts2[12]);
        hop_2_accounts.push(accounts2[13]);
        hop2={
          dexProgram:DexProgram.MeteoraDlmm,
          dexProgramId:program_ids.dlmm,
          inTokenIs2022:mints[1].is2022,
          outTokenIs2022:mints[0].is2022,
          isBaseSwap:hop_2_isBaseSwap,
          accounts:hop_2_accounts
        };
      }
      if(hop_2_dex=="dyn2"){
        hop_2_accounts=accounts2;
        hop2={
          dexProgram:DexProgram.MeteoraDammV2,
          dexProgramId:program_ids.dyn2,
          inTokenIs2022:mints[1].is2022,
          outTokenIs2022:mints[0].is2022,
          isBaseSwap:hop_2_isBaseSwap,
          accounts:hop_2_accounts
        };
      }
      if(hop_2_dex=="raydium"){
        hop_2_accounts=accounts2;
        hop2={
          dexProgram:DexProgram.RaydiumAmmV4,
          dexProgramId:program_ids.raydium,
          inTokenIs2022:mints[1].is2022,
          outTokenIs2022:mints[0].is2022,
          isBaseSwap:hop_2_isBaseSwap,
          accounts:hop_2_accounts
        };
      }
      if(!mints[1].is2022&&(hop1.dexProgram==DexProgram.RaydiumClmm||hop2.dexProgram==DexProgram.RaydiumClmm)){
        return;
      }
      const message=`
Arbitrage opportunity found!
Price Difference Ratio:  ${ratio*100}%
Trade Amount:  ${Number(initialAmount)/LAMPORTS_PER_SOL} SOL
Profit:  ${profit/LAMPORTS_PER_SOL} SOL
Hop1:{
  pooladdress:
    ${hop_1_pairaddress}
  dex:  ${sourceAddress.split("_")[1]}
  dexProgramId:
    ${hop1.dexProgramId}
  inToken:
    ${mints[0].mint.toBase58()}
  outToken:
    ${mints[1].mint.toBase58()}
  inTokenIs2022:  ${hop1.inTokenIs2022}
  outTokenIs2022:  ${hop1.outTokenIs2022}
  isBaseSwap:  ${hop1.isBaseSwap}
}
Hop2:{
  pooladdress:
    ${hop_2_pairaddress}
  dex:  ${destinationAddress.split("_")[1]}
  dexProgramId:
    ${hop2.dexProgramId}
  inToken:
    ${mints[1].mint.toBase58()}
  outToken:
    ${mints[0].mint.toBase58()}
  inTokenIs2022:  ${hop2.inTokenIs2022}
  outTokenIs2022:  ${hop2.outTokenIs2022}
  isBaseSwap:  ${hop2.isBaseSwap}
}
      `;
      const now=Date.now();
      if(now-lastAlertAt>=TELEGRAM_ALERT_MS){
        lastAlertAt=now;
        sendTelegramAlert(message);
      }
      // Costs the swaps must cover on top of the borrowed/initial amount.
      const tipLamports=ISJITO=="true"&&jitoTipAccount ? BigInt(JITO_TIP_LAMPORTS) : BigInt(0);
      const txFeeLamports=BigInt(5000+Math.ceil(CU_LIMIT*CU_PRICE_MICROLAMPORTS/1_000_000));
      let useKamino=KAMINO_ENABLED&&initialAmount<=KAMINO_MAX_LAMPORTS;
      if(useKamino){
        const reserve=await readKaminoReserve(connection);
        useKamino=reserve.ok&&reserve.available>=initialAmount;
      }
      const flashFeeLamports=useKamino ? flashFee(initialAmount, KAMINO_FEE_BPS) : BigInt(0);
      const minProfitLamports=BigInt(Math.ceil(MINIMUM_PROFIT*LAMPORTS_PER_SOL));
      const costs=tipLamports+txFeeLamports+flashFeeLamports;
      // Never send an expected loss: the estimate must clear every cost first,
      // and the program enforces the same floor on the final output.
      if(BigInt(Math.floor(profit))<costs+minProfitLamports) return;
      const minimumFinalOutput=initialAmount+costs+minProfitLamports;
      const tag=`${sourceAddress.split("_")[1]}->${destinationAddress.split("_")[1]} ${token.slice(0,6)} amt=${(Number(initialAmount)/LAMPORTS_PER_SOL).toFixed(4)} estProfit=${(profit/LAMPORTS_PER_SOL).toFixed(6)} kamino=${useKamino}`;
      if(!sendingEnabled){
        dryOpportunities++;
        logger.info(`[DRY] ${tag}`);
        return;
      }
      if(now-lastSendAt<SEND_COOLDOWN_MS) return;
      lastSendAt=now;

      const { accounts, hops } = buildArbitrageAccounts(wallet.publicKey, mints, [hop1, hop2]);
      const instructionData = buildArbitrageInstructionData({
        hops,
        initialAmount,
        minimumFinalOutput,
      });
      const arbInstruction = new TransactionInstruction({
        programId: PROGRAM_ID,
        keys: accounts,
        data: instructionData,
      });
      const tokenProgram=mints[1].is2022 ? TOKEN_2022_PROGRAM_ID : TOKEN_PROGRAM_ID;
      const wsolAta=getAssociatedTokenAddressSync(NATIVE_MINT, wallet.publicKey);
      const tokenAta=getAssociatedTokenAddressSync(mints[1].mint, wallet.publicKey, false, tokenProgram);
      const instructions:TransactionInstruction[]=[
        ComputeBudgetProgram.setComputeUnitLimit({ units: CU_LIMIT }),
        ComputeBudgetProgram.setComputeUnitPrice({ microLamports: CU_PRICE_MICROLAMPORTS }),
        createAssociatedTokenAccountIdempotentInstruction(wallet.publicKey, wsolAta, wallet.publicKey, NATIVE_MINT),
        createAssociatedTokenAccountIdempotentInstruction(wallet.publicKey, tokenAta, wallet.publicKey, mints[1].mint, tokenProgram),
      ];
      if(useKamino){
        // Borrow lands in the WSOL ATA the arb spends from; repay pulls
        // borrow + fee back out of it, or the whole tx reverts.
        const borrowIndex=instructions.length;
        instructions.push(flashBorrowIx(wsolAta, wallet.publicKey, initialAmount));
        instructions.push(arbInstruction);
        instructions.push(flashRepayIx(wsolAta, wallet.publicKey, initialAmount, borrowIndex));
      }else{
        instructions.push(arbInstruction);
      }
      if(tipLamports>BigInt(0)){
        instructions.push(SystemProgram.transfer({
          fromPubkey: wallet.publicKey,
          toPubkey: new PublicKey(jitoTipAccount),
          lamports: tipLamports,
        }));
      }
      const alts=[lookupTableAccount];
      if(kaminoLookupTableAccount) alts.push(kaminoLookupTableAccount);
      const messageV0 = new TransactionMessage({
        payerKey: wallet.publicKey,
        recentBlockhash: recentBlockhash,
        instructions,
      }).compileToV0Message(alts);
      const transaction = new VersionedTransaction(messageV0);
      transaction.sign([wallet]);
      const sig = ISJITO=="true"
        ? await sendJitoTransaction(transaction)
        : await swqos_connection.sendTransaction(transaction, {skipPreflight:true, maxRetries:0});
      logger.info(`[SENT] ${tag} sig=${sig} trigger=${bigTxSig}`);
  }catch(e){
    logger.error(`arb send failed: ${String(e).slice(0,200)}`);
  }
}

/**
 * SMB path: hand the mint's pools (the opportunity's two first) to the
 * executor; it sizes and routes on chain and reverts below our floor.
 */
async function trySmbArb(sourceAddress:string, destinationAddress:string, bigTxSig:string, ratio:number, profit:number){
  if(smbBusy) return;
  const now=Date.now();
  if(!sendingEnabled){
    if(!SMB_DRY_SIM || now-smbLastDrySimAt<SMB_DRY_SIM_MS) return;
    smbLastDrySimAt=now;
  }else if(now-lastSendAt<SEND_COOLDOWN_MS){
    return;
  }
  smbBusy=true;
  try{
    const mint=sourceAddress.split("_")[0];
    const first=[sourceAddress, destinationAddress].map((k)=>k.split("_")[2]);
    const rest=(mintToPairKeys.get(mint) ?? []).map((k)=>k.split("_")[2]).filter((p)=>!first.includes(p));
    const live=sendingEnabled;
    if(live) lastSendAt=now;
    const r=await smbTry({
      conn: smbConnection,
      sendConns: [smbSendConnection],
      ...sendPaths([]),
      signer: wallet,
      mint: new PublicKey(mint),
      tokenProgram: isToken2022Bitmap[mint] ? TOKEN_2022_PROGRAM_ID : TOKEN_PROGRAM_ID,
      pools: [...first, ...rest].map((p)=>new PublicKey(p)),
      blockhash: recentBlockhash,
      live,
      s: SMB,
    });
    const tag=`${sourceAddress.split("_")[1]}->${destinationAddress.split("_")[1]} ${mint.slice(0,6)} ratio=${(ratio*100).toFixed(3)}% est=${(profit/LAMPORTS_PER_SOL).toFixed(6)}`;
    if(r.stage==="sent"){
      logger.info(`[SMB SENT] ${tag} ${r.reason} sig=${r.signature} trigger=${bigTxSig}`);
    }else{
      if(r.stage==="dry") dryOpportunities++;
      logger.info(`[SMB ${r.stage}] ${tag} ${r.reason}`);
    }
    const t=Date.now();
    if(r.stage==="sent" && t-lastAlertAt>=TELEGRAM_ALERT_MS){
      lastAlertAt=t;
      sendTelegramAlert(`SMB arb sent
${tag}
${r.reason}
${r.signature}`);
    }
  }catch(e){
    logger.error(`smb attempt failed: ${String(e).slice(0,200)}`);
  }finally{
    smbBusy=false;
  }
}

/**
 * Sending needs DRY_RUN=false AND a deployed arb program. A closed program
 * (programdata gone) fails every tx with UnsupportedProgramId and only burns
 * the fee, so the bot then stays in dry mode on its own.
 */
async function checkSendingEnabled() {
  if (ARB_PROGRAM === "smb") {
    let slot: bigint | null = null;
    try {
      slot = await programDeploySlot(connection, SMB_PROGRAM);
    } catch (e) {
      logger.error(`SMB program check failed: ${e}`);
    }
    const expected = process.env.SMB_EXPECTED_DEPLOY_SLOT?.trim();
    if (smbDeploySlot === null && slot !== null) smbDeploySlot = expected ? BigInt(expected) : slot;
    const live = slot !== null && slot === smbDeploySlot;
    if (slot !== null && smbDeploySlot !== null && slot !== smbDeploySlot) {
      logger.error(`SMB program was UPGRADED (deploy slot ${smbDeploySlot} -> ${slot}): sending stopped. Review it, then set SMB_EXPECTED_DEPLOY_SLOT=${slot} to accept.`);
    }
    const was = sendingEnabled;
    sendingEnabled = !DRY_RUN && live;
    if (!was || !sendingEnabled) {
      if (!live && slot === null) logger.warn(`SMB program ${SMB_PROGRAM.toBase58()} not deployed: DRY mode`);
      else if (DRY_RUN) logger.info(`ARB_PROGRAM=smb (deploy slot ${slot}); DRY_RUN=true: simulate only, nothing is sent`);
      else if (sendingEnabled && !was) logger.warn(`LIVE via SMB ${SMB_PROGRAM.toBase58()} (deploy slot ${slot}): transactions WILL be sent`);
    }
    return;
  }
  let live = false;
  try {
    const prog = await connection.getAccountInfo(PROGRAM_ID);
    if (prog?.executable && prog.owner.equals(BPF_UPGRADEABLE_LOADER) && prog.data.length >= 36) {
      const programData = new PublicKey(prog.data.subarray(4, 36));
      live = (await connection.getAccountInfo(programData)) !== null;
    } else if (prog?.executable) {
      live = true;
    }
  } catch (e) {
    logger.error(`arb program check failed: ${e}`);
  }
  sendingEnabled = !DRY_RUN && live;
  if (!live) logger.warn(`Arb program ${PROGRAM_ID.toBase58()} is NOT deployed (closed): DRY mode, nothing will be sent`);
  else if (DRY_RUN) logger.info("DRY_RUN=true: opportunities are logged, nothing is sent");
  else logger.warn("LIVE: arb transactions WILL be sent");
}

type GetDexAccountsOptions = { noAwait?: boolean };

async function getDexAccountsForPairs(connection:Connection, retry:Boolean, options?: GetDexAccountsOptions){
  const noAwait = options?.noAwait === true;
  const accounts=Object.keys(pairAddresses);
  const tasks = accounts
    .map((account) => ({
      accountKey: account,
      dex: account.split("_")[1],
      poolAddress: account.split("_")[2],
    }))
    .filter(
      (t) =>
        retry === false ||
        !["pumpswap", "cpmm", "dyn2", "raydium"].includes(t.dex)
    );

  const worker = getDexAccountsWorker();
  if (worker) {
    if (noAwait) {
      if (dexAccountsBusy) return;
      dexAccountsBusy = true;
      worker.postMessage({
        rpcEndpoint: RPC_ENDPOINT,
        walletSecretKeyBase58: PRIVATE_KEY,
        tasks,
      });
      return;
    }
    try {
      const result = await new Promise<WorkerResult>((resolve, reject) => {
        dexAccountsPendingResolve = resolve;
        dexAccountsBusy = true;
        worker.postMessage({
          rpcEndpoint: RPC_ENDPOINT,
          walletSecretKeyBase58: PRIVATE_KEY,
          tasks,
        });
        dexAccountsTimeoutId = setTimeout(() => {
          dexAccountsTimeoutId = null;
          dexAccountsBusy = false;
          if (dexAccountsPendingResolve) {
            dexAccountsPendingResolve({ results: [] });
            dexAccountsPendingResolve = null;
          }
        }, 120000);
      });
      applyWorkerResults(result);
    } catch (e) {
      logger.error("getDexAccountsForPairs worker failed:");
      await getDexAccountsForPairsMainThread(connection, retry, accounts);
    }
    return;
  }

  await getDexAccountsForPairsMainThread(connection, retry, accounts);
}

async function getDexAccountsForPairsMainThread(connection: Connection, retry: Boolean, accounts: string[]) {
  const toFetch =
    retry === true
      ? accounts.filter(
          (a) =>
            !["pumpswap", "cpmm", "dyn2", "raydium"].includes(a.split("_")[1])
        )
      : accounts;
  const promises = toFetch.map(async (account) => {
    try {
      const dex = account.split("_")[1];
      const poolAddress = account.split("_")[2];
      const dexaccounts = await getDexAccounts(dex, poolAddress, connection, wallet);
      return { account, accounts1: dexaccounts?.accounts };
    } catch (error) {
      logger.error(`Error fetching dex accounts for ${account}: ${error}`);
      return { account, accounts1: undefined };
    }
  });
  const results = await Promise.all(promises);
  for (const result of results) {
    if (result.accounts1 !== undefined)
      pairAddress_accounts[result.account] = result.accounts1;
  }
}

async function sendJitoTransaction(tx:VersionedTransaction){
  const base64Tx = Buffer.from(tx.serialize()).toString('base64');
  const response = await fetch(`${BLOCK_ENGINE_URL}/api/v1/transactions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      jsonrpc: "2.0",
      id: 1,
      method: "sendTransaction",
      params: [base64Tx, { encoding: "base64" }]
    })
  });
  const result = await response.json();
  return result.result
}

async function sendJitoBundle(txsB64:string[]){
  const response = await fetch(`${BLOCK_ENGINE_URL}/api/v1/bundles`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "sendBundle", params: [txsB64, { encoding: "base64" }] })
  });
  const result = await response.json();
  if (result.error) throw new Error(`jito bundle: ${JSON.stringify(result.error).slice(0, 160)}`);
  return result.result;
}

async function sendJitoRaw(base64Tx:string){
  const response = await fetch(`${BLOCK_ENGINE_URL}/api/v1/transactions`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "sendTransaction", params: [base64Tx, { encoding: "base64" }] })
  });
  const result = await response.json();
  if (result.error) throw new Error(`jito: ${JSON.stringify(result.error).slice(0, 120)}`);
  return result.result;
}

async function getJitoTipAccountList(): Promise<string[]> {
  const response = await fetch(`${BLOCK_ENGINE_URL}/api/v1/getTipAccounts`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ jsonrpc: "2.0", id: 1, method: "getTipAccounts", params: [] })
  });
  const result = await response.json();
  return Array.isArray(result.result) ? result.result : [];
}

async function getJitoTipAccounts(){
  const response = await fetch(`${BLOCK_ENGINE_URL}/api/v1/getTipAccounts`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      jsonrpc: "2.0",
      id: 1,
      method: "getTipAccounts",
      params:[]
    })
  });
  const result = await response.json();
  return result.result[0];
}