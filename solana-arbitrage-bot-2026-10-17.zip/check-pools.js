const fs = require("node:fs");

const tokens = fs
  .readFileSync("tokens.txt", "utf8")
  .split(/\r?\n/)
  .map((x) => x.trim())
  .filter(Boolean);

async function main() {
  const url =
    "https://api.dexscreener.com/tokens/v1/solana/" +
    tokens.join(",");

  const response = await fetch(url, {
    signal: AbortSignal.timeout(20000),
  });

  if (!response.ok) {
    throw new Error(`DexScreener HTTP ${response.status}`);
  }

  const data = await response.json();
  const pairs = Array.isArray(data) ? data : [];
  let tokensWithPools = 0;

  console.log("DexScreener havuz sayısı:", pairs.length);

  for (const [index, token] of tokens.entries()) {
    const address = token.toLowerCase();

    const matches = pairs
      .filter(
        (pair) =>
          pair.chainId === "solana" &&
          [pair.baseToken?.address, pair.quoteToken?.address].some(
            (item) => item?.toLowerCase() === address
          )
      )
      .sort(
        (a, b) =>
          (Number(b.liquidity?.usd) || 0) -
          (Number(a.liquidity?.usd) || 0)
      );

    console.log(`\n${index + 1}. ${token}`);
    console.log("Havuz sayısı:", matches.length);

    if (matches.length === 0) {
      console.log("DexScreener üzerinde havuz bulunamadı.");
      continue;
    }

    tokensWithPools++;

    for (const pair of matches.slice(0, 3)) {
      console.log(
        `DEX: ${pair.dexId || "?"} | ` +
        `Pair: ${pair.baseToken?.symbol || "?"}/` +
        `${pair.quoteToken?.symbol || "?"} | ` +
        `Likidite: $${Math.round(Number(pair.liquidity?.usd) || 0)} | ` +
        `24s hacim: $${Math.round(Number(pair.volume?.h24) || 0)}`
      );

      if (pair.url) {
        console.log("URL:", pair.url);
      }
    }
  }

  console.log(
    `\nHavuzu bulunan tokenlar: ${tokensWithPools}/${tokens.length}`
  );
}

main().catch((error) => {
  console.error("Tarama başarısız:", error.message);
  process.exitCode = 1;
});