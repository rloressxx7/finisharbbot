import dotenv from "dotenv";
import bs58 from "bs58";
import fs from "node:fs";
import {
  AddressLookupTableProgram,
  Connection,
  Keypair,
  LAMPORTS_PER_SOL,
  PublicKey,
  TransactionMessage,
  VersionedTransaction,
} from "@solana/web3.js";

dotenv.config();

const MAINNET_GENESIS_HASH = "5eykt4UsFv8P8NJdTREpY1vzqKqZKvdpKuc147dw2N9d";
const EXISTING_ALT_ADDRESS = "CSmqNjMiAMSHtvsURGyo31MkncehVBqeL2QGEsFmgCM5";
const OLD_ALT_ADDRESS = "4RqDUqkQqMkbQEAXvEBr5nFhh3hhfeHxeL9gUaMCFzyh";
const FEE_RESERVE_LAMPORTS = 1_000_000; // keep at least 0.001 SOL for fees after rent top-up

async function sendAndConfirm(
  connection: Connection,
  payer: Keypair,
  lookupTable: PublicKey,
  addresses: PublicKey[],
): Promise<number> {
  const instruction = AddressLookupTableProgram.extendLookupTable({
    payer: payer.publicKey,
    authority: payer.publicKey,
    lookupTable,
    addresses,
  });
  const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash("confirmed");
  const message = new TransactionMessage({
    payerKey: payer.publicKey,
    recentBlockhash: blockhash,
    instructions: [instruction],
  }).compileToV0Message();
  const transaction = new VersionedTransaction(message);
  transaction.sign([payer]);
  const signature = await connection.sendTransaction(transaction, { maxRetries: 3 });
  const confirmation = await connection.confirmTransaction(
    { signature, blockhash, lastValidBlockHeight },
    "confirmed",
  );
  if (confirmation.value.err) {
    throw new Error(`ALT extension failed: ${JSON.stringify(confirmation.value.err)}; signature=${signature}`);
  }
  console.log(`Extended ${addresses.length} addresses. Signature: ${signature}`);
  return confirmation.context.slot;
}

async function main(): Promise<void> {
  const rpcEndpoint = process.env.RPC_ENDPOINT?.trim();
  const privateKey = process.env.PRIVATE_KEY?.trim();
  if (!rpcEndpoint || !privateKey) throw new Error("RPC_ENDPOINT and PRIVATE_KEY must be set in .env");
  if (!fs.existsSync("alts.txt")) throw new Error("alts.txt not found in project root");
  if (!fs.existsSync("main.ts")) throw new Error("main.ts not found in project root");

  const targetAddresses = [...new Set(
    fs.readFileSync("alts.txt", "utf8")
      .split(/\r?\n/)
      .map((line) => line.trim())
      .filter(Boolean),
  )].map((address) => new PublicKey(address));

  const connection = new Connection(rpcEndpoint, "confirmed");
  const genesisHash = await connection.getGenesisHash();
  if (genesisHash !== MAINNET_GENESIS_HASH) throw new Error("RPC is not Solana mainnet-beta; refusing to proceed");

  const secret = bs58.decode(privateKey);
  if (secret.length !== 64) throw new Error("PRIVATE_KEY must decode to a 64-byte Solana keypair");
  const payer = Keypair.fromSecretKey(secret);
  const tableAddress = new PublicKey(EXISTING_ALT_ADDRESS);

  let tableResult = await connection.getAddressLookupTable(tableAddress, { commitment: "confirmed" });
  if (!tableResult.value) throw new Error(`Existing ALT ${EXISTING_ALT_ADDRESS} not found; this script will not create another table`);
  if (!tableResult.value.state.authority?.equals(payer.publicKey)) {
    throw new Error("Existing ALT authority does not match the local payer wallet; refusing to spend funds");
  }
  const accountInfo = await connection.getAccountInfo(tableAddress, "confirmed");
  if (!accountInfo || !accountInfo.owner.equals(AddressLookupTableProgram.programId)) {
    throw new Error("Existing address is not an Address Lookup Table account");
  }

  const have = new Set(tableResult.value.state.addresses.map((address) => address.toBase58()));
  const missing = targetAddresses.filter((address) => !have.has(address.toBase58()));
  const combinedCount = new Set([
    ...tableResult.value.state.addresses.map((address) => address.toBase58()),
    ...targetAddresses.map((address) => address.toBase58()),
  ]).size;

  const payerBalance = await connection.getBalance(payer.publicKey, "confirmed");
  const targetRent = await connection.getMinimumBalanceForRentExemption(56 + 32 * combinedCount, "confirmed");
  const rentTopUp = Math.max(0, targetRent - accountInfo.lamports);

  console.log("Network: Solana mainnet-beta");
  console.log("Existing ALT:", EXISTING_ALT_ADDRESS);
  console.log("ALT addresses currently present:", have.size);
  console.log("Addresses from alts.txt:", targetAddresses.length);
  console.log("Addresses still to add:", missing.length);
  console.log("Wallet balance:", (payerBalance / LAMPORTS_PER_SOL).toFixed(6), "SOL");
  console.log("Estimated additional ALT rent:", (rentTopUp / LAMPORTS_PER_SOL).toFixed(6), "SOL; fees extra");

  if (missing.length > 0 && payerBalance < rentTopUp + FEE_RESERVE_LAMPORTS) {
    throw new Error(
      `Insufficient SOL to safely finish this existing ALT. Need at least ${((rentTopUp + FEE_RESERVE_LAMPORTS) / LAMPORTS_PER_SOL).toFixed(6)} SOL including a 0.001 SOL fee reserve. No extension transaction was sent.`,
    );
  }

  let lastProcessedSlot = 0;
  for (let i = 0; i < missing.length; i += 20) {
    const batch = missing.slice(i, i + 20);
    lastProcessedSlot = await sendAndConfirm(connection, payer, tableAddress, batch);
  }

  if (lastProcessedSlot > 0) {
    const deadline = Date.now() + 20_000;
    while (Date.now() < deadline) {
      const slot = await connection.getSlot("confirmed");
      if (slot > lastProcessedSlot) break;
      await new Promise((resolve) => setTimeout(resolve, 400));
    }
  }

  tableResult = await connection.getAddressLookupTable(tableAddress, { commitment: "confirmed" });
  if (!tableResult.value) throw new Error("ALT could not be loaded after extension");
  const finalSet = new Set(tableResult.value.state.addresses.map((address) => address.toBase58()));
  const stillMissing = targetAddresses.filter((address) => !finalSet.has(address.toBase58()));
  if (stillMissing.length > 0) {
    throw new Error(`ALT verification incomplete: ${stillMissing.length} target addresses still missing. Existing table preserved; rerun this script to resume.`);
  }

  console.log("ALT READY:", tableAddress.toBase58());
  console.log("Verified target addresses:", targetAddresses.length);

  const mainPath = "main.ts";
  const source = fs.readFileSync(mainPath, "utf8");
  const occurrences = source.split(OLD_ALT_ADDRESS).length - 1;
  if (occurrences === 1) {
    const stamp = new Date().toISOString().replace(/[:.]/g, "-");
    const backupPath = `main.ts.before-alt-${stamp}.bak`;
    fs.copyFileSync(mainPath, backupPath);
    fs.writeFileSync(mainPath, source.replace(OLD_ALT_ADDRESS, EXISTING_ALT_ADDRESS), "utf8");
    console.log("Updated main.ts to the verified ALT.");
    console.log("Backup:", backupPath);
  } else if (occurrences === 0 && source.includes(EXISTING_ALT_ADDRESS)) {
    console.log("main.ts already references the new ALT.");
  } else {
    throw new Error(`ALT is verified, but main.ts has ${occurrences} occurrence(s) of the old address. Update the lookupTableAddress constant manually after checking the file.`);
  }

  console.log("Next: pnpm exec tsc --noEmit");
}

main().catch((error: unknown) => {
  const message = error instanceof Error ? error.message : String(error);
  console.error("Resume ALT failed:", message);
  process.exitCode = 1;
});
