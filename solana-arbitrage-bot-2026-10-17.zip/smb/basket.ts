/**
 * A mint's SMB basket: every pool of the mint the executor can trade, laid
 * out as V10 pool blocks, plus what the wallet still lacks (accounts the
 * executor would create and pay rent for). Pool states come from the live
 * account cache (the hot screen keeps them subscribed); one-off accounts —
 * fee-recipient ATAs, the wallet's own accounts — are read on a plain
 * connection with their own cache, so they never take a websocket slot.
 */
import type { AccountInfo, Connection, PublicKey } from "@solana/web3.js";
import { directBasketCu, MAX_TRANSACTION_CU, missingAtaCu, PUMP_MISSING_ACCOUNT_CU } from "./cost";
import {
  arrayCandidates,
  ataBump,
  DLMM,
  isInitializedAta,
  MAX_COMPUTE_UNIT_LIMIT,
  mintAccounts,
  PUMP,
  pumpBuybackOffsets,
  pumpFeeOffsets,
  pumpGlobalConfig,
  pumpKeysFromState,
  pumpPoolBlock,
  pumpRecipientCandidates,
  pumpV2Eligible,
  pumpVolumeAccumulator,
  poolBlockFromState,
  poolPair,
  RAYDIUM,
  RAYDIUM_CONVERSION,
  SMB_POOL_PROGRAMS,
  SOL,
  TOKEN,
  TOKEN_2022,
  USDC,
  type ConversionAccounts,
  type MintAccounts,
  type PoolBlock,
} from "./v10";

export interface SmbBasket {
  mint: string;
  target: MintAccounts;
  settlement: MintAccounts;
  target2022: boolean;
  pools: PoolBlock[];
  /** Pools left out, with why. */
  skipped: string[];
  wsolAtaMissing: boolean;
  targetAtaMissing: boolean;
  /** Pump's per-wallet volume accumulator (created by a Pump swap when missing). */
  volumeMissing: boolean;
  /**
   * SOL/USDC converter when USDC-quoted pools take part (the program routes
   * token/USDC against token/SOL through it), and whether the wallet still
   * lacks its USDC account (created in the same transaction).
   */
  conversion?: ConversionAccounts;
  usdcAtaMissing: boolean;
  /** CU the executor gets (its own model + accounts it must create). */
  executorCu: number;
  builtAt: number;
}

const RECIPIENT_TTL_MS = 300_000;
/** The wallet's accounts change only through our own trades (cache dropped then). */
const WALLET_TTL_MS = 60_000;
const recipientCache = new Map<string, { at: number; initialized: Set<string> }>();
const walletCache = new Map<string, { at: number; exists: boolean }>();

/** Forget the wallet's account cache (after a landed trade created some). */
export function invalidateWalletAccounts(): void {
  walletCache.clear();
}

async function walletAccountsExist(raw: Connection, keys: PublicKey[]): Promise<boolean[]> {
  const now = Date.now();
  const need = keys.filter((k) => {
    const c = walletCache.get(k.toBase58());
    return !c || now - c.at > WALLET_TTL_MS;
  });
  if (need.length) {
    const infos = await raw.getMultipleAccountsInfo(need, "processed");
    need.forEach((k, i) => walletCache.set(k.toBase58(), { at: now, exists: !!infos[i] }));
  }
  return keys.map((k) => walletCache.get(k.toBase58())!.exists);
}

/** Which of these fee-recipient ATAs are initialized (cached 5 min). */
async function initializedRecipients(
  raw: Connection,
  cands: { owner: PublicKey; ata: PublicKey }[],
  quote: PublicKey,
  tokenProgram: PublicKey,
): Promise<Set<string>> {
  const id = cands.map((c) => c.ata.toBase58()).join(",");
  const hit = recipientCache.get(id);
  if (hit && Date.now() - hit.at < RECIPIENT_TTL_MS) return hit.initialized;
  const infos = await raw.getMultipleAccountsInfo(
    cands.map((c) => c.ata),
    "confirmed",
  );
  const initialized = new Set<string>();
  cands.forEach((c, i) => {
    if (isInitializedAta(infos[i], c.owner, quote, tokenProgram)) initialized.add(c.ata.toBase58());
  });
  recipientCache.set(id, { at: Date.now(), initialized });
  return initialized;
}

function pick<T>(xs: T[]): T {
  return xs[Math.floor(Math.random() * xs.length)]!;
}

/**
 * Build the basket. `stream` serves pool states (live cache); `raw` reads the
 * one-off accounts. Pools keep the caller's order (deepest first) and at most
 * `maxPools` are kept.
 */
export interface TokenMeta {
  mint: PublicKey;
  tokenProgram: PublicKey;
}

async function getMultiple(c: Connection, keys: PublicKey[], commitment: "processed" | "confirmed") {
  const out: (AccountInfo<Buffer> | null)[] = [];
  for (let i = 0; i < keys.length; i += 100) {
    out.push(...(await c.getMultipleAccountsInfo(keys.slice(i, i + 100), commitment)));
  }
  return out;
}

export async function loadBasket(a: {
  stream: Connection;
  raw: Connection;
  wallet: PublicKey;
  token: TokenMeta;
  pools: PublicKey[];
  maxPools: number;
}): Promise<SmbBasket> {
  const { stream, raw, wallet, token } = a;
  const target = mintAccounts(wallet, token.mint, token.tokenProgram);
  const settlement = mintAccounts(wallet, SOL, TOKEN);
  const usdc = mintAccounts(wallet, USDC, TOKEN);
  const target2022 = token.tokenProgram.equals(TOKEN_2022);
  const skipped: string[] = [];

  const uniq: PublicKey[] = [];
  for (const p of a.pools) if (!uniq.some((u) => u.equals(p))) uniq.push(p);
  const states = await getMultiple(stream, uniq, "processed");

  type Raw = { pool: PublicKey; info: AccountInfo<Buffer>; base: MintAccounts };
  const usable: Raw[] = [];
  uniq.forEach((pool, i) => {
    const info = states[i];
    const short = pool.toBase58().slice(0, 6);
    if (!info) return skipped.push(`${short}: yok`);
    if (!SMB_POOL_PROGRAMS.some((p) => p.equals(info.owner))) return skipped.push(`${short}: desteklenmeyen program`);
    try {
      const pair = poolPair(info.owner, info.data);
      const hasTarget = pair.mints.some((m) => m.equals(token.mint));
      const hasSol = pair.mints.some((m) => m.equals(SOL));
      const hasUsdc = pair.mints.some((m) => m.equals(USDC));
      if (!hasTarget || (!hasSol && !hasUsdc)) return skipped.push(`${short}: SOL/USDC çifti değil`);
      usable.push({ pool, info, base: hasSol ? settlement : usdc });
    } catch (e) {
      return skipped.push(`${short}: ${String(e).slice(0, 40)}`);
    }
  });
  // USDC pools need the converter; read it in the same round trip.
  const wantsUsdc = usable.some((u) => u.base === usdc);

  // Second round trip (memory when warm): pump global, arrays and bitmaps.
  const extra: PublicKey[] = [];
  const anyPump = usable.some((u) => u.info.owner.equals(PUMP));
  if (anyPump) extra.push(pumpGlobalConfig());
  const cands = new Map<string, { arrays: PublicKey[]; bitmap?: PublicKey }>();
  for (const u of usable) {
    if (u.info.owner.equals(PUMP)) continue;
    const c = arrayCandidates(u.pool, u.info.owner, u.info.data);
    cands.set(u.pool.toBase58(), c);
    extra.push(...c.arrays);
    if (c.bitmap && u.info.owner.equals(DLMM)) extra.push(c.bitmap);
  }
  if (wantsUsdc) extra.push(RAYDIUM_CONVERSION);
  const extraInfos = extra.length ? await getMultiple(stream, extra, "processed") : [];
  const byKey = new Map<string, AccountInfo<Buffer> | null>();
  extra.forEach((k, i) => byKey.set(k.toBase58(), extraInfos[i] ?? null));

  const volume = pumpVolumeAccumulator(wallet);
  const [wsolExists, targetExists, volumeExists, usdcExists] = await walletAccountsExist(raw, [
    settlement.wallet,
    target.wallet,
    volume,
    usdc.wallet,
  ]);

  const blocks: PoolBlock[] = [];
  for (const u of usable) {
    if (blocks.length >= a.maxPools) break;
    const short = u.pool.toBase58().slice(0, 6);
    try {
      if (u.info.owner.equals(PUMP)) {
        const global = byKey.get(pumpGlobalConfig().toBase58());
        if (!global) throw new Error("pump global config yok");
        const keys = pumpKeysFromState(u.pool, u.info.data, global.data, target, u.base);
        const mayhem = u.info.data[243] === 1;
        const fee = pumpRecipientCandidates(global.data, pumpFeeOffsets(mayhem), keys.quote.mint, keys.quote.tokenProgram);
        const feeInit = await initializedRecipients(raw, fee, keys.quote.mint, keys.quote.tokenProgram);
        const feeWarm = fee.filter((c) => feeInit.has(c.ata.toBase58()));
        keys.recipient = pick(feeWarm.length ? feeWarm : fee).owner;
        if (pumpV2Eligible(keys)) {
          const bb = pumpRecipientCandidates(global.data, pumpBuybackOffsets(), keys.quote.mint, keys.quote.tokenProgram);
          const bbInit = await initializedRecipients(raw, bb, keys.quote.mint, keys.quote.tokenProgram);
          const bbWarm = bb.filter((c) => bbInit.has(c.ata.toBase58()));
          // v2 never creates the buyback account: only with a warm one.
          if (bbWarm.length) {
            keys.v2 = true;
            keys.buyback = pick(bbWarm).owner;
          }
        }
        blocks.push(pumpPoolBlock(wallet, target, u.base, keys));
      } else {
        const c = cands.get(u.pool.toBase58())!;
        const owner = u.info.owner;
        const exists = (k: PublicKey) => byKey.get(k.toBase58())?.owner.equals(owner) ?? false;
        let arrays = c.arrays;
        let bitmap = c.bitmap;
        if (arrays.length) {
          // Only arrays that exist on chain; DLMM's bitmap extension is
          // optional and listed only when it exists (CLMM's always is).
          arrays = arrays.filter(exists);
          if (owner.equals(DLMM)) bitmap = bitmap && exists(bitmap) ? bitmap : undefined;
        }
        blocks.push(poolBlockFromState(u.pool, owner, u.info.data, target, u.base, arrays, bitmap));
      }
    } catch (e) {
      skipped.push(`${short}: ${String(e instanceof Error ? e.message : e).slice(0, 60)}`);
    }
  }

  // The program needs a WSOL-quoted pool in the group; USDC pools only ride
  // along through the converter.
  let conversion: ConversionAccounts | undefined;
  const solBlocks = blocks.filter((b) => b.baseMint.equals(SOL));
  if (solBlocks.length && blocks.some((b) => b.baseMint.equals(USDC))) {
    const conv = byKey.get(RAYDIUM_CONVERSION.toBase58());
    try {
      if (!conv || !conv.owner.equals(RAYDIUM)) throw new Error("çevrim havuzu yok");
      conversion = {
        quote: usdc,
        pool: poolBlockFromState(RAYDIUM_CONVERSION, RAYDIUM, conv.data, usdc, settlement, [], undefined),
      };
    } catch (e) {
      skipped.push(`USDC çevrimi: ${String(e instanceof Error ? e.message : e).slice(0, 50)}`);
    }
  }
  if (!conversion) {
    for (const b of blocks) if (b.baseMint.equals(USDC)) skipped.push(`${b.pool.toBase58().slice(0, 6)}: USDC (çevrim yok)`);
  }
  // Copies: `blocks` is emptied right below.
  const used = solBlocks.length ? (conversion ? [...blocks] : [...solBlocks]) : [];
  blocks.length = 0;
  blocks.push(...used);

  let executorCu = directBasketCu(
    blocks.map((b) => ({ venue: b.venue, pumpQuoteIsBase: b.pumpQuoteIsBase })),
    target2022,
    true,
  );
  // Converted routes are 3-leg cycles the direct model does not cover:
  // budget the cap the Rust model uses for its widest baskets.
  if (conversion) executorCu = MAX_TRANSACTION_CU;
  if (!targetExists) executorCu += missingAtaCu(target2022, ataBump(wallet, token.mint, token.tokenProgram));
  if (!volumeExists && blocks.some((b) => b.venue === "Pump" || b.venue === "PumpV2")) {
    executorCu += PUMP_MISSING_ACCOUNT_CU;
  }
  return {
    mint: token.mint.toBase58(),
    target,
    settlement,
    target2022,
    pools: blocks,
    skipped,
    wsolAtaMissing: !wsolExists,
    targetAtaMissing: !targetExists,
    volumeMissing: !volumeExists,
    conversion,
    usdcAtaMissing: !!conversion && !usdcExists,
    executorCu: Math.min(executorCu, MAX_COMPUTE_UNIT_LIMIT - 1_300),
    builtAt: Date.now(),
  };
}
