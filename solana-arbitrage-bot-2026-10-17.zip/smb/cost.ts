/**
 * The executor's CU cost model for DIRECT baskets (one target mint, every
 * pool quoted in WSOL, no SOL/USDC conversion, no triangles) — a port of
 * executor-v10-abi `cost.rs` restricted to what this bot sends. The program
 * budgets its on-chain search with the compute limit we give it, so the limit
 * must match its own model: too small and it sizes the trade smaller.
 * Golden values in smb.test.ts come from the Rust crate itself.
 */

export type V10Venue =
  | "Manifest"
  | "RaydiumAmm"
  | "MeteoraDamm"
  | "Pump"
  | "PumpV2"
  | "RaydiumCpmm"
  | "Clmm"
  | "ClmmFork"
  | "Whirlpool"
  | "Dlmm"
  | "Dammv2";

interface VenueCost {
  select: number;
  prepare: number;
  interval: number;
  swap: number;
  token2022: number;
}

const COST: Record<V10Venue, VenueCost> = {
  Manifest: { select: 2_500, prepare: 800, interval: 1_500, swap: 16_900, token2022: 8_000 },
  RaydiumAmm: { select: 3_300, prepare: 1_000, interval: 1_300, swap: 18_600, token2022: 0 },
  MeteoraDamm: { select: 8_000, prepare: 1_000, interval: 2_000, swap: 81_500, token2022: 3_000 },
  Pump: { select: 3_200, prepare: 300, interval: 1_200, swap: 82_700, token2022: 3_000 },
  PumpV2: { select: 3_200, prepare: 300, interval: 1_200, swap: 60_600, token2022: 3_000 },
  RaydiumCpmm: { select: 3_300, prepare: 1_300, interval: 1_200, swap: 27_300, token2022: 8_500 },
  Clmm: { select: 4_300, prepare: 5_000, interval: 3_000, swap: 46_500, token2022: 8_000 },
  ClmmFork: { select: 5_000, prepare: 4_000, interval: 3_000, swap: 59_500, token2022: 8_000 },
  Whirlpool: { select: 4_300, prepare: 6_500, interval: 4_500, swap: 41_500, token2022: 9_900 },
  Dlmm: { select: 5_000, prepare: 2_300, interval: 1_300, swap: 35_400, token2022: 5_600 },
  Dammv2: { select: 3_000, prepare: 800, interval: 1_300, swap: 26_500, token2022: 6_000 },
};

const SETUP_CU = 3_500;
const GROUP_SETUP_CU = 1_500;
const TOKEN_2022_MINT_CU = 1_500;
const PUMP_PDA_CU = 1_600;
const DISCOVERY_CU = 6_000;
const SCREEN_CU = Math.floor((1_500 + 150) / 2);
const PLANNING_CU = 800;
const FIRST_CANDIDATE_CU = 12_000;
const SHORT_SIZING_CU = 1_200;
const SHORT_INTERVAL_CU = 300;
const EXECUTION_MARGIN_CU = 8_000 + 1_000 + 1_500;
const LEG_EXECUTION_CU = 100;
const TOKEN_2022_CU = 500;
const LOAN_CU = 1_400;
const DLMM_HOST_CLAIM_CU = 3_500;
const PUMP_BUY_CU = 12_000;
const PUMP_V2_BUY_CU = 5_100;
const SHORT_ALLOWANCE = { dlmm: 92_000, concentrated: 40_000, orderBook: 60_000, extraLeg: 20_000 };
const SIZED_CANDIDATES = 3;
export const MAX_TRANSACTION_CU = 700_000;
const HEADROOM_DIVISOR = 20;
/** Pump creates the wallet's volume accumulator when it is missing. */
export const PUMP_MISSING_ACCOUNT_CU = 27_700;

/** CU for the executor to create a missing wallet token account at `bump`. */
export function missingAtaCu(token2022: boolean, bump: number): number {
  return (token2022 ? 21_000 : 17_000) + 2_000 + (3_000 + 1_500) * (255 - bump);
}

export interface BasketPool {
  venue: V10Venue;
  /** Pump's native quote mint is WSOL (the route's base); undefined = unknown. */
  pumpQuoteIsBase?: boolean;
}

interface Leg {
  venue: V10Venue;
  token2022Mints: number;
  pumpBuy?: boolean;
}

const isPump = (v: V10Venue) => v === "Pump" || v === "PumpV2";
const pumpBuyCu = (v: V10Venue) => (v === "Pump" ? PUMP_BUY_CU : v === "PumpV2" ? PUMP_V2_BUY_CU : 0);

function allowanceOf(v: V10Venue): number | undefined {
  if (v === "Dlmm") return SHORT_ALLOWANCE.dlmm;
  if (v === "Clmm" || v === "ClmmFork" || v === "Whirlpool") return SHORT_ALLOWANCE.concentrated;
  if (v === "Manifest") return SHORT_ALLOWANCE.orderBook;
  return undefined;
}

function routeWork(legs: V10Venue[]) {
  let preparation = 0;
  let interval = SHORT_INTERVAL_CU;
  let execution = EXECUTION_MARGIN_CU + LEG_EXECUTION_CU * legs.length;
  for (const v of legs) {
    const c = COST[v];
    preparation += c.prepare;
    interval += c.interval;
    execution += c.swap;
  }
  return { preparation, search: SHORT_SIZING_CU, interval, execution };
}

/** A two-leg direct route (the only kind a direct basket has). */
function routeCu(legs: Leg[]): number {
  const venues = legs.map((l) => l.venue);
  const work = routeWork(venues);
  let transfers = 0;
  for (const l of legs) {
    transfers += l.token2022Mints * (COST[l.venue].token2022 + TOKEN_2022_CU);
    if (l.venue === "Dlmm") transfers += DLMM_HOST_CLAIM_CU;
  }
  let buys = 0;
  let sells = 0;
  let unknown = 0;
  for (const l of legs) {
    if (!isPump(l.venue)) continue;
    const cu = pumpBuyCu(l.venue);
    if (l.pumpBuy === true) buys += cu;
    else if (l.pumpBuy === false) sells += cu;
    else unknown += cu;
  }
  let largest = 0;
  let crossing = 0;
  for (const v of venues) {
    const a = allowanceOf(v);
    if (a === undefined) continue;
    largest = Math.max(largest, a);
    crossing++;
  }
  const allowance = largest + SHORT_ALLOWANCE.extraLeg * Math.max(0, crossing - 1);
  return (
    work.preparation +
    work.search +
    work.execution +
    transfers +
    Math.max(buys, sells) +
    unknown +
    work.interval +
    allowance
  );
}

function candidateCu(legs: Leg[]): number {
  const w = routeWork(legs.map((l) => l.venue));
  return w.preparation + w.search + w.interval + PLANNING_CU + 300;
}

/**
 * CU the transaction should give the executor for one direct group of
 * `pools` (all WSOL-quoted). Same result as the Rust `transaction_cu`.
 */
export function directBasketCu(pools: BasketPool[], target2022: boolean, loan: boolean): number {
  const t = target2022 ? 1 : 0;
  let quotes = 0;
  let cpmm = 0;
  for (const p of pools) {
    quotes += COST[p.venue].select;
    if (p.venue === "RaydiumCpmm") cpmm++;
  }
  const setup =
    SETUP_CU +
    GROUP_SETUP_CU +
    quotes +
    Math.max(0, cpmm - 2) * 2_400 +
    t * TOKEN_2022_MINT_CU +
    pools.filter((p) => isPump(p.venue)).length * PUMP_PDA_CU;

  const routes: Leg[][] = [];
  const leg = (p: BasketPool, baseToX: boolean): Leg => ({
    venue: p.venue,
    token2022Mints: t,
    pumpBuy: p.pumpQuoteIsBase === undefined ? undefined : p.pumpQuoteIsBase === baseToX,
  });
  for (let i = 0; i < pools.length; i++) {
    for (let j = i + 1; j < pools.length; j++) routes.push([leg(pools[i]!, true), leg(pools[j]!, false)]);
  }
  const screens = routes.length * 2;
  let worst = 0;
  let worstIndex = 0;
  let includedSizing = 0;
  routes.forEach((r, i) => {
    const cu = routeCu(r);
    if (cu > worst) {
      worst = cu;
      worstIndex = i;
      includedSizing = candidateCu(r);
    }
  });
  const sizing: number[] = new Array(SIZED_CANDIDATES).fill(0);
  routes.forEach((r, i) => {
    let cu = candidateCu(r);
    if (i === worstIndex) cu -= includedSizing;
    const slot = sizing.findIndex((s) => cu > s);
    if (slot >= 0) {
      sizing.splice(slot, 0, cu);
      sizing.length = SIZED_CANDIDATES;
    }
  });
  const fit =
    setup + Math.max(DISCOVERY_CU, screens * SCREEN_CU) + worst + sizing.reduce((a, b) => a + b, 0);
  let firstCandidate = 0;
  if (screens > 0) {
    const swaps = pools.map((p) => COST[p.venue].swap).sort((a, b) => a - b);
    firstCandidate =
      setup + screens * SCREEN_CU + (swaps[0] ?? 0) + (swaps[1] ?? 0) + FIRST_CANDIDATE_CU + EXECUTION_MARGIN_CU;
  }
  const need = Math.max(fit, firstCandidate) + (loan ? LOAN_CU : 0);
  return Math.min(need + Math.floor(need / HEADROOM_DIVISOR), MAX_TRANSACTION_CU);
}
