/**
 * Transaction v1 (SIMD-0385) builder. web3.js cannot write v1, and the
 * executor needs it: a two-to-four pool basket carries 40-60 accounts, which
 * does not fit the 1,232-byte legacy/v0 packet without our own lookup table,
 * while v1 allows 4,096 bytes and 64 addresses. v1 also carries the compute
 * limit and the priority fee in its header (no ComputeBudget instructions),
 * and the priority fee is a flat lamport amount, not a per-CU price.
 *
 * Layout (solana-message 4.6 v1::Message, wincode):
 *   0x81 | req ro_signed ro_unsigned | config mask u32 | blockhash[32]
 *   | n_ix u8 | n_keys u8 | keys[32]* | config values
 *   | per ix: program u8, n_accounts u8, data_len u16 | per ix: accounts, data
 *   | signatures[64] * req          (signed bytes = everything before them)
 */
import crypto from "node:crypto";
import { PublicKey, TransactionMessage, type Keypair, type TransactionInstruction } from "@solana/web3.js";
import bs58 from "bs58";

export const V1_PREFIX = 0x81;
export const V1_MAX_TRANSACTION_SIZE = 4_096;
export const V1_MAX_ADDRESSES = 64;

const MASK_PRIORITY_FEE = 0b11;
const MASK_COMPUTE_UNIT_LIMIT = 0b100;
const MASK_LOADED_ACCOUNTS_DATA = 0b1000;

export interface V1Config {
  /** Total priority fee in lamports (flat, independent of the CU limit). */
  priorityFee?: bigint;
  computeUnitLimit?: number;
  loadedAccountsDataSizeLimit?: number;
}

export interface V1Message {
  /** Bytes the signers sign: the version prefix and the message. */
  bytes: Uint8Array;
  accountKeys: PublicKey[];
  numRequiredSignatures: number;
}

/**
 * Compile instructions into a v1 message. Account ordering and the header
 * come from web3.js' legacy compiler (payer first, then writable signers,
 * readonly signers, writable and readonly non-signers); any consistent order
 * is valid, only the layout differs from legacy.
 */
export function compileV1(
  payer: PublicKey,
  instructions: TransactionInstruction[],
  blockhash: string,
  cfg: V1Config,
): V1Message {
  const legacy = new TransactionMessage({
    payerKey: payer,
    recentBlockhash: blockhash,
    instructions,
  }).compileToLegacyMessage();
  const keys = legacy.accountKeys;
  if (keys.length > V1_MAX_ADDRESSES) {
    throw new Error(`v1: ${keys.length} accounts > ${V1_MAX_ADDRESSES}`);
  }
  if (instructions.length > 255) throw new Error("v1: too many instructions");

  let mask = 0;
  const values: Buffer[] = [];
  if (cfg.priorityFee !== undefined) {
    mask |= MASK_PRIORITY_FEE;
    const b = Buffer.alloc(8);
    b.writeBigUInt64LE(cfg.priorityFee);
    values.push(b);
  }
  if (cfg.computeUnitLimit !== undefined) {
    mask |= MASK_COMPUTE_UNIT_LIMIT;
    const b = Buffer.alloc(4);
    b.writeUInt32LE(cfg.computeUnitLimit);
    values.push(b);
  }
  if (cfg.loadedAccountsDataSizeLimit !== undefined) {
    mask |= MASK_LOADED_ACCOUNTS_DATA;
    const b = Buffer.alloc(4);
    b.writeUInt32LE(cfg.loadedAccountsDataSizeLimit);
    values.push(b);
  }

  const ixs = legacy.instructions.map((ix) => ({
    program: ix.programIdIndex,
    accounts: Uint8Array.from(ix.accounts),
    data: bs58.decode(ix.data),
  }));
  const head = Buffer.alloc(1 + 3 + 4);
  head[0] = V1_PREFIX;
  head[1] = legacy.header.numRequiredSignatures;
  head[2] = legacy.header.numReadonlySignedAccounts;
  head[3] = legacy.header.numReadonlyUnsignedAccounts;
  head.writeUInt32LE(mask >>> 0, 4);
  const parts: Uint8Array[] = [head, bs58.decode(blockhash), Uint8Array.from([ixs.length, keys.length])];
  for (const k of keys) parts.push(k.toBytes());
  parts.push(...values);
  for (const ix of ixs) {
    if (ix.accounts.length > 255 || ix.data.length > 0xffff) throw new Error("v1: instruction too large");
    const h = Buffer.alloc(4);
    h[0] = ix.program;
    h[1] = ix.accounts.length;
    h.writeUInt16LE(ix.data.length, 2);
    parts.push(h);
  }
  for (const ix of ixs) parts.push(ix.accounts, ix.data);
  const bytes = Buffer.concat(parts);
  return { bytes, accountKeys: keys, numRequiredSignatures: legacy.header.numRequiredSignatures };
}

/** Wire size once signed. */
export function v1WireSize(m: V1Message): number {
  return m.bytes.length + 64 * m.numRequiredSignatures;
}

const PKCS8_ED25519_PREFIX = Buffer.from("302e020100300506032b657004220420", "hex");
const keyObjects = new WeakMap<Keypair, crypto.KeyObject>();

/** Native ed25519 (node:crypto), ~20x faster than the pure-JS signer. */
function keyObject(kp: Keypair): crypto.KeyObject {
  let k = keyObjects.get(kp);
  if (!k) {
    k = crypto.createPrivateKey({
      key: Buffer.concat([PKCS8_ED25519_PREFIX, Buffer.from(kp.secretKey.subarray(0, 32))]),
      format: "der",
      type: "pkcs8",
    });
    keyObjects.set(kp, k);
  }
  return k;
}

export function signBytes(kp: Keypair, bytes: Uint8Array): Uint8Array {
  return crypto.sign(null, bytes, keyObject(kp));
}

/**
 * Sign with the payer (the only signer the bot uses) and return the wire
 * bytes and the signature (the tx id). `signer` null leaves a zero signature,
 * which simulation with sigVerify=false accepts.
 */
export function signV1(m: V1Message, signer: Keypair | null): { wire: Uint8Array; signature: string } {
  if (m.numRequiredSignatures !== 1) throw new Error("v1: only single-signer messages");
  if (signer && !signer.publicKey.equals(m.accountKeys[0]!)) throw new Error("v1: signer is not the payer");
  const sig = signer ? signBytes(signer, m.bytes) : new Uint8Array(64);
  const wire = Buffer.concat([m.bytes, sig]);
  if (wire.length > V1_MAX_TRANSACTION_SIZE) {
    throw new Error(`v1: ${wire.length} bytes > ${V1_MAX_TRANSACTION_SIZE}`);
  }
  return { wire, signature: bs58.encode(sig) };
}
