/**
 * SolanaMevBot on-chain executor (MEViEnsc…), instruction V10 (opcode 61).
 * The program receives a target mint and a list of pools; ON CHAIN it reads
 * every pool, finds the best route and size, borrows the size from its own
 * vault (flashloan), trades, repays, and fails with Custom(1) when the profit
 * is below `minimumProfit`. Port of the Rust client in
 * solana-onchain-arbitrage-bot (src/v10.rs, lib/executor-v10-abi), which
 * matched live mainnet calls byte for byte.
 *
 * Only direct groups (target ↔ WSOL pools) are built here.
 */
import { PublicKey, type AccountMeta, TransactionInstruction } from "@solana/web3.js";
import type { V10Venue } from "./cost";

export const SMB_PROGRAM = new PublicKey("MEViEnscUm6tsQRoGd9h6nLQaQspKj7DB2M5FwM3Xvz");
export const V10_OPCODE = 61;
export const MAX_COMPUTE_UNIT_LIMIT = 1_400_000;
export const MAX_GROUPS = 4;
export const MAX_POOLS = 16;
export const MAX_POOL_ACCOUNTS = 24;

const pk = (s: string) => new PublicKey(s);
export const CPMM = pk("CPMMoo8L3F4NbTegBCKVNunggL7H1ZpdTHKxQB5qKP1C");
export const CLMM = pk("CAMMCzo5YL8w4VFF8KVHrK22GGUsp5VTaW7grrKgrWqK");
export const PANCAKESWAP = pk("HpNfyc2Saw7RKkQd8nEL4khUcuPhQ7WwY1B2qjx8jxFq");
export const BYREAL = pk("REALQqNEomY6cQGZJUGwywTBD2UmDT32rZcNnfxQ5N2");
export const WHIRLPOOL = pk("whirLbMiicVdio4qvUfM5KAg6Ct8VwpYzGff3uctyCc");
export const DLMM = pk("LBUZKhRxPF3XUpBCjp4YzTKgLccjZhTSDM9YuVaPwxo");
export const PUMP = pk("pAMMBay6oceH9fJKBRHGP5D4bD4sWpmSwMn52FMfXEA");
export const PUMP_FEE = pk("pfeeUxB6jkeY1Hxd7CsFCAjcbHA9rWtchMGdZ6VojVZ");
export const RAYDIUM = pk("675kPX9MHTjS2zt1qfr1NYHuzeLXfQM9H24wFSUt1Mp8");
export const DAMMV2 = pk("cpamdpZCGKUy5JxQXB4dcpGPiikHawvSWAd6mEn1sGG");
export const SOL = pk("So11111111111111111111111111111111111111112");
/** Raydium AMM v4 SOL/USDC pool: the converter the Rust client uses. */
export const RAYDIUM_CONVERSION = pk("58oQChx4yWmvKdwLLZzBi4ChoCc2fqCUWBkwMihLYQo2");
export const USDC = pk("EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v");
export const TOKEN = pk("TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA");
export const TOKEN_2022 = pk("TokenzQdBNbLqP5VEhdkAS6EPFLC1PHnBqCXEpPxuEb");
export const MEMO = pk("MemoSq4gqABAXKb96qnH8TysNcWxMyWCqXgDLGmfcHr");
export const ASSOCIATED = pk("ATokenGPvbdGVxr1b2hvZbsiqW5xWH25efTNsLJA8knL");
export const SYSTEM = pk("11111111111111111111111111111111");

/** Programs whose pools this builder lays out. */
export const SMB_POOL_PROGRAMS = [PUMP, DLMM, DAMMV2, RAYDIUM, CPMM, CLMM, PANCAKESWAP, BYREAL, WHIRLPOOL];

const pda = (seeds: (Uint8Array | Buffer)[], program: PublicKey) =>
  PublicKey.findProgramAddressSync(seeds, program)[0];

export function ataOf(owner: PublicKey, mint: PublicKey, tokenProgram: PublicKey): PublicKey {
  return pda([owner.toBuffer(), tokenProgram.toBuffer(), mint.toBuffer()], ASSOCIATED);
}

export function ataBump(owner: PublicKey, mint: PublicKey, tokenProgram: PublicKey): number {
  return PublicKey.findProgramAddressSync([owner.toBuffer(), tokenProgram.toBuffer(), mint.toBuffer()], ASSOCIATED)[1];
}

export const vaultAuthority = () => pda([Buffer.from("vault_authority")], SMB_PROGRAM);
export const vaultTokenAccount = (settlement: PublicKey) =>
  pda([Buffer.from("vault_token_account"), settlement.toBuffer()], SMB_PROGRAM);
export const pumpGlobalConfig = () => pda([Buffer.from("global_config")], PUMP);
export const pumpVolumeAccumulator = (wallet: PublicKey) =>
  pda([Buffer.from("user_volume_accumulator"), wallet.toBuffer()], PUMP);

export interface MintAccounts {
  mint: PublicKey;
  tokenProgram: PublicKey;
  /** The wallet's associated token account of `mint`. */
  wallet: PublicKey;
}

export function mintAccounts(wallet: PublicKey, mint: PublicKey, tokenProgram: PublicKey): MintAccounts {
  if (!tokenProgram.equals(TOKEN) && !tokenProgram.equals(TOKEN_2022)) {
    throw new Error("unsupported token program");
  }
  return { mint, tokenProgram, wallet: ataOf(wallet, mint, tokenProgram) };
}

const ro = (pubkey: PublicKey): AccountMeta => ({ pubkey, isSigner: false, isWritable: false });
const rw = (pubkey: PublicKey): AccountMeta => ({ pubkey, isSigner: false, isWritable: true });

function key(d: Uint8Array, offset: number): PublicKey {
  if (d.length < offset + 32) throw new Error("truncated pool account");
  return new PublicKey(d.subarray(offset, offset + 32));
}
const u16 = (d: Uint8Array, o: number) => Buffer.from(d.buffer, d.byteOffset, d.byteLength).readUInt16LE(o);
const i32 = (d: Uint8Array, o: number) => Buffer.from(d.buffer, d.byteOffset, d.byteLength).readInt32LE(o);

/** Offsets of a pool's two mints and two vaults in its state. */
function pairOffsets(program: PublicKey): [number, number, number, number] {
  if (program.equals(RAYDIUM)) return [400, 432, 336, 368];
  if (program.equals(CPMM)) return [168, 200, 72, 104];
  if (program.equals(CLMM) || program.equals(PANCAKESWAP) || program.equals(BYREAL)) return [73, 105, 137, 169];
  if (program.equals(WHIRLPOOL)) return [101, 181, 133, 213];
  if (program.equals(DLMM)) return [88, 120, 152, 184];
  if (program.equals(DAMMV2)) return [168, 200, 232, 264];
  if (program.equals(PUMP)) return [43, 75, 139, 171];
  throw new Error(`unsupported V10 DEX ${program.toBase58()}`);
}

export function poolPair(program: PublicKey, data: Uint8Array): { mints: [PublicKey, PublicKey]; vaults: [PublicKey, PublicKey] } {
  const [m0, m1, v0, v1] = pairOffsets(program);
  return { mints: [key(data, m0), key(data, m1)], vaults: [key(data, v0), key(data, v1)] };
}

/** Vaults in (x, base) order. */
function vaultsFor(program: PublicKey, data: Uint8Array, x: PublicKey, base: PublicKey): [PublicKey, PublicKey] {
  if (x.equals(base)) throw new Error("pool mints must differ");
  const p = poolPair(program, data);
  if (p.mints[0].equals(x) && p.mints[1].equals(base)) return p.vaults;
  if (p.mints[0].equals(base) && p.mints[1].equals(x)) return [p.vaults[1], p.vaults[0]];
  throw new Error("pool does not match the declared mint pair");
}

/**
 * Tick/bin arrays around a concentrated pool's active one (radius 1), plus
 * the bitmap extension for CLMM / DLMM. The caller keeps only arrays that
 * exist on chain (and the DLMM bitmap only when it exists).
 */
export function arrayCandidates(
  pool: PublicKey,
  owner: PublicKey,
  data: Uint8Array,
  radius = 1,
): { arrays: PublicKey[]; bitmap?: PublicKey } {
  let current: number;
  let width: number;
  let bitmap: PublicKey | undefined;
  let kind: "dlmm" | "clmm" | "whirl";
  if (owner.equals(CLMM) || owner.equals(PANCAKESWAP) || owner.equals(BYREAL)) {
    const spacing = u16(data, 235);
    if (spacing <= 0) throw new Error("invalid CLMM spacing");
    current = i32(data, 269);
    width = spacing * 60;
    bitmap = pda([Buffer.from("pool_tick_array_bitmap_extension"), pool.toBuffer()], owner);
    kind = "clmm";
  } else if (owner.equals(WHIRLPOOL)) {
    const spacing = u16(data, 41);
    if (spacing <= 0) throw new Error("invalid Whirlpool spacing");
    current = i32(data, 81);
    width = spacing * 88;
    kind = "whirl";
  } else if (owner.equals(DLMM)) {
    current = i32(data, 76);
    width = 70;
    bitmap = pda([Buffer.from("bitmap"), pool.toBuffer()], owner);
    kind = "dlmm";
  } else {
    return { arrays: [] };
  }
  const center = Math.floor(current / width);
  const arrays: PublicKey[] = [];
  for (let off = -radius; off <= radius; off++) {
    const index = center + off;
    if (kind === "dlmm") {
      const b = Buffer.alloc(8);
      b.writeBigInt64LE(BigInt(index));
      arrays.push(pda([Buffer.from("bin_array"), pool.toBuffer(), b], owner));
    } else if (kind === "clmm") {
      const b = Buffer.alloc(4);
      b.writeInt32BE(index * width);
      arrays.push(pda([Buffer.from("tick_array"), pool.toBuffer(), b], owner));
    } else {
      arrays.push(pda([Buffer.from("tick_array"), pool.toBuffer(), Buffer.from(String(index * width))], owner));
    }
  }
  return { arrays, bitmap };
}

/** One pool's account block in the instruction (starts with its program). */
export interface PoolBlock {
  venue: V10Venue;
  pool: PublicKey;
  xMint: PublicKey;
  baseMint: PublicKey;
  accounts: AccountMeta[];
  /** Pump only: its native quote mint is the route's base (WSOL). */
  pumpQuoteIsBase?: boolean;
}

/** Non-Pump pools: Raydium v4, CPMM, CLMM (+forks), Whirlpool, DLMM, DAMM v2. */
export function poolBlockFromState(
  pool: PublicKey,
  owner: PublicKey,
  data: Uint8Array,
  x: MintAccounts,
  base: MintAccounts,
  arrays: PublicKey[],
  bitmap: PublicKey | undefined,
): PoolBlock {
  if (owner.equals(PUMP)) throw new Error("Pump needs pumpPoolBlock");
  const [xVault, baseVault] = vaultsFor(owner, data, x.mint, base.mint);
  const accounts: AccountMeta[] = [ro(owner), ro(base.mint)];
  const t22 = x.tokenProgram.equals(TOKEN_2022) || base.tokenProgram.equals(TOKEN_2022);
  let venue: V10Venue;
  if (owner.equals(RAYDIUM)) {
    if (t22) throw new Error("V10 Raydium requires legacy token mints");
    accounts.push(ro(pda([Buffer.from("amm authority")], owner)), rw(pool), rw(xVault), rw(baseVault));
    venue = "RaydiumAmm";
  } else if (owner.equals(DAMMV2)) {
    accounts.push(
      ro(pda([Buffer.from("__event_authority")], owner)),
      ro(pda([Buffer.from("pool_authority")], owner)),
      rw(pool),
      rw(xVault),
      rw(baseVault),
    );
    venue = "Dammv2";
  } else if (owner.equals(CPMM)) {
    accounts.push(
      ro(pda([Buffer.from("vault_and_lp_mint_auth_seed")], CPMM)),
      rw(pool),
      ro(key(data, 8)),
      rw(xVault),
      rw(baseVault),
      rw(key(data, 296)),
    );
    venue = "RaydiumCpmm";
  } else {
    if (arrays.length < 1 || arrays.length > 6) throw new Error("V10 requires 1..=6 arrays per concentrated pool");
    if (owner.equals(DLMM)) accounts.push(ro(pda([Buffer.from("__event_authority")], DLMM)));
    if (t22 || owner.equals(WHIRLPOOL)) accounts.push(ro(MEMO));
    accounts.push(rw(pool));
    if (owner.equals(CLMM) || owner.equals(PANCAKESWAP) || owner.equals(BYREAL)) {
      if (!bitmap) throw new Error("CLMM bitmap address required");
      accounts.push(ro(key(data, 9)), rw(key(data, 201)), rw(bitmap), rw(xVault), rw(baseVault));
      venue = owner.equals(CLMM) ? "Clmm" : "ClmmFork";
    } else if (owner.equals(WHIRLPOOL)) {
      accounts.push(rw(pda([Buffer.from("oracle"), pool.toBuffer()], WHIRLPOOL)), rw(xVault), rw(baseVault));
      venue = "Whirlpool";
    } else if (owner.equals(DLMM)) {
      accounts.push(rw(xVault), rw(baseVault), rw(key(data, 552)));
      if (bitmap) accounts.push(rw(bitmap));
      venue = "Dlmm";
    } else {
      throw new Error("unsupported V10 pool program");
    }
    for (const a of arrays) accounts.push(rw(a));
  }
  return { venue, pool, xMint: x.mint, baseMint: base.mint, accounts };
}

/** Pump fee recipient candidates (owner, its quote-mint ATA). */
export function pumpRecipientCandidates(
  global: Uint8Array,
  offsets: number[],
  quote: PublicKey,
  tokenProgram: PublicKey,
): { owner: PublicKey; ata: PublicKey }[] {
  const out: { owner: PublicKey; ata: PublicKey }[] = [];
  for (const o of offsets) {
    const owner = key(global, o);
    if (owner.equals(PublicKey.default)) continue;
    const a = ataOf(owner, quote, tokenProgram);
    if (!out.some((c) => c.ata.equals(a))) out.push({ owner, ata: a });
  }
  if (!out.length) throw new Error("no Pump fee recipients");
  return out;
}

export const pumpFeeOffsets = (mayhem: boolean) =>
  mayhem ? [385, ...Array.from({ length: 7 }, (_, i) => 418 + i * 32)] : Array.from({ length: 8 }, (_, i) => 57 + i * 32);
export const pumpBuybackOffsets = () => Array.from({ length: 8 }, (_, i) => 643 + i * 32);

/** An initialized token account of `mint` owned by `owner` (Pump's choice rule). */
export function isInitializedAta(
  info: { owner: PublicKey; data: Uint8Array } | null | undefined,
  owner: PublicKey,
  mint: PublicKey,
  tokenProgram: PublicKey,
): boolean {
  if (!info || !info.owner.equals(tokenProgram) || info.data.length < 165) return false;
  const d = info.data;
  return (
    Buffer.from(d.subarray(0, 32)).equals(mint.toBuffer()) &&
    Buffer.from(d.subarray(32, 64)).equals(owner.toBuffer()) &&
    d[108] === 1
  );
}

export interface PumpKeys {
  pool: PublicKey;
  /** Vaults in (x, base) order. */
  vaults: [PublicKey, PublicKey];
  mint0: PublicKey;
  quote: MintAccounts;
  recipient: PublicKey;
  creator: PublicKey;
  cashback: boolean;
  buyback: PublicKey;
  /** Compact PumpSwap v2 layout (only with an existing buyback quote ATA). */
  v2: boolean;
}

/** Pump keys from the pool state; `recipient`/`buyback`/`v2` are refined by the caller. */
export function pumpKeysFromState(
  pool: PublicKey,
  data: Uint8Array,
  global: Uint8Array,
  x: MintAccounts,
  base: MintAccounts,
): PumpKeys {
  const pair = poolPair(PUMP, data);
  const [mint0, mint1] = pair.mints;
  const vaults = vaultsFor(PUMP, data, x.mint, base.mint);
  const quote = mint1.equals(base.mint) ? base : x;
  if (data.length < 245) throw new Error("truncated Pump pool");
  const recipientOffset = data[243] === 0 ? 57 : 385;
  return {
    pool,
    vaults,
    mint0,
    quote,
    recipient: key(global, recipientOffset),
    creator: key(data, 211),
    cashback: data[244] === 1,
    buyback: key(global, 643),
    v2: false,
  };
}

export function pumpV2Eligible(k: PumpKeys): boolean {
  return (
    !k.cashback &&
    (k.quote.mint.equals(SOL) || k.quote.mint.equals(USDC)) &&
    k.quote.tokenProgram.equals(TOKEN)
  );
}

export function pumpPoolBlock(wallet: PublicKey, x: MintAccounts, base: MintAccounts, k: PumpKeys): PoolBlock {
  const sides = [x.mint, base.mint];
  if (
    !sides.some((m) => m.equals(k.quote.mint)) ||
    !sides.some((m) => m.equals(k.mint0)) ||
    k.quote.mint.equals(k.mint0)
  ) {
    throw new Error("invalid Pump orientation");
  }
  if (k.v2 && !pumpV2Eligible(k)) throw new Error("Pump v2 requires a non-cashback SOL or USDC pool");
  const p = (seeds: (Uint8Array | Buffer)[]) => pda(seeds, PUMP);
  const ata = (owner: PublicKey) => ataOf(owner, k.quote.mint, k.quote.tokenProgram);
  const volume = pumpVolumeAccumulator(wallet);
  const feeConfig = pda([Buffer.from("fee_config"), PUMP.toBuffer()], PUMP_FEE);
  const [xVault, baseVault] = k.vaults;
  const accounts: AccountMeta[] = [
    ro(PUMP),
    ro(base.mint),
    ro(p([Buffer.from("global_config")])),
    ro(p([Buffer.from("__event_authority")])),
  ];
  let venue: V10Venue;
  if (k.v2) {
    accounts.push(rw(k.pool), rw(xVault), rw(baseVault), rw(volume), ro(feeConfig), rw(ata(k.buyback)));
    venue = "PumpV2";
  } else {
    const creatorVault = p([Buffer.from("creator_vault"), k.creator.toBuffer()]);
    accounts.push(
      ro(k.recipient),
      rw(k.pool),
      rw(xVault),
      rw(baseVault),
      rw(ata(k.recipient)),
      rw(ata(creatorVault)),
      ro(creatorVault),
      ro(p([Buffer.from("global_volume_accumulator")])),
      rw(volume),
      ro(feeConfig),
      ro(PUMP_FEE),
    );
    if (k.cashback) accounts.push(rw(ata(volume)), rw(volume));
    if (!k.creator.equals(PublicKey.default)) accounts.push(ro(p([Buffer.from("pool-v2"), k.mint0.toBuffer()])));
    accounts.push(ro(k.buyback), rw(ata(k.buyback)));
    venue = "Pump";
  }
  return {
    venue,
    pool: k.pool,
    xMint: x.mint,
    baseMint: base.mint,
    accounts,
    pumpQuoteIsBase: k.quote.mint.equals(base.mint),
  };
}

export interface V10Header {
  minimumProfit: bigint;
  computeUnitLimit: number;
  noFailure: boolean;
  /** Additional fee to a second collector (0 = none; we never set it). */
  additionalFeeBp: number;
  useFlashloan: boolean;
  /** 0 = the program searches the size itself. */
  tradeSize: bigint;
}

/**
 * Instruction data: opcode, 25-byte prefix, flags, group count, [conversion
 * account count u16], per group bridge/direct counts and pool sizes.
 * `conversion` = account count of the SOL/USDC converter pool (0 = none).
 */
export function encodeV10Data(h: V10Header, groups: number[][], conversion = 0): Buffer {
  if (!(h.computeUnitLimit >= 1 && h.computeUnitLimit <= MAX_COMPUTE_UNIT_LIMIT)) {
    throw new Error("invalid V10 compute limit");
  }
  if (h.additionalFeeBp !== 0) throw new Error("additional fee not supported");
  if (groups.length < 1 || groups.length > MAX_GROUPS) throw new Error("invalid V10 group count");
  if (conversion !== 0 && (conversion < 3 || conversion > MAX_POOL_ACCOUNTS)) {
    throw new Error("invalid V10 conversion account count");
  }
  let pools = conversion ? 1 : 0;
  for (const g of groups) {
    pools += g.length;
    if (g.length < 2 || pools > MAX_POOLS) throw new Error("invalid V10 direct group");
    for (const n of g) if (n < 3 || n > MAX_POOL_ACCOUNTS) throw new Error("invalid V10 pool account count");
  }
  const out = Buffer.alloc(1 + 26 + (conversion ? 2 : 0) + groups.reduce((a, g) => a + 2 + 2 * g.length, 0));
  out[0] = V10_OPCODE;
  out.writeBigUInt64LE(h.minimumProfit, 1);
  out.writeUInt32LE(h.computeUnitLimit, 9);
  out[13] = h.noFailure ? 1 : 0;
  out.writeUInt16LE(h.additionalFeeBp, 14);
  out[16] = h.useFlashloan ? 1 : 0;
  out.writeBigUInt64LE(h.tradeSize, 17);
  out[25] = conversion ? 1 : 0; // bit 0: conversion present (constant conversion never)
  out[26] = groups.length;
  let o = 27;
  if (conversion) {
    out.writeUInt16LE(conversion, o);
    o += 2;
  }
  for (const g of groups) {
    out[o++] = 0; // bridges
    out[o++] = g.length; // direct pools
    for (const n of g) {
      out.writeUInt16LE(n, o);
      o += 2;
    }
  }
  return out;
}

export interface DirectGroup {
  target: MintAccounts;
  pools: PoolBlock[];
}

/**
 * The executor instruction for direct groups settled in WSOL with the
 * program's flashloan: the wallet is its own fee collector (the vault takes
 * the program's share of the profit).
 */
export interface ConversionAccounts {
  /** USDC and the wallet's USDC account. */
  quote: MintAccounts;
  /** The SOL/USDC pool laid out with x = USDC, base = WSOL. */
  pool: PoolBlock;
}

export function buildV10Instruction(a: {
  wallet: PublicKey;
  settlement: MintAccounts;
  header: V10Header;
  groups: DirectGroup[];
  /** Lets USDC-quoted pools join a WSOL-settled route (the program converts). */
  conversion?: ConversionAccounts;
}): TransactionInstruction {
  const { wallet, settlement, header, groups, conversion } = a;
  if (!settlement.mint.equals(SOL) || !settlement.tokenProgram.equals(TOKEN)) {
    throw new Error("settlement must be WSOL");
  }
  if (!header.useFlashloan) throw new Error("this builder sends flashloan trades only");
  const keys: AccountMeta[] = [
    { pubkey: wallet, isSigner: true, isWritable: true },
    ro(settlement.mint),
    rw(wallet), // fee collector = payer under a flashloan
    rw(settlement.wallet),
    ro(TOKEN),
    ro(SYSTEM),
    ro(ASSOCIATED),
    ro(vaultAuthority()),
    rw(vaultTokenAccount(settlement.mint)),
  ];
  if (conversion) {
    const c = conversion;
    if (!c.quote.mint.equals(USDC) || !c.quote.tokenProgram.equals(TOKEN)) {
      throw new Error("conversion must be USDC");
    }
    if (!c.pool.xMint.equals(c.quote.mint) || !c.pool.baseMint.equals(settlement.mint)) {
      throw new Error("invalid settlement conversion pool");
    }
    keys.push(ro(c.quote.mint), ro(c.quote.tokenProgram), rw(c.quote.wallet), ...c.pool.accounts);
  }
  const quote = conversion?.quote.mint;
  const counts: number[][] = [];
  for (const g of groups) {
    if (g.target.mint.equals(settlement.mint)) throw new Error("direct target must differ from settlement");
    if (g.pools.length < 2) throw new Error("direct groups require at least two pools");
    keys.push(ro(g.target.mint), ro(g.target.tokenProgram), rw(g.target.wallet));
    const c: number[] = [];
    for (const p of g.pools) {
      const base = p.baseMint;
      if (!p.xMint.equals(g.target.mint) || !(base.equals(settlement.mint) || (quote && base.equals(quote)))) {
        throw new Error(`pool ${p.pool.toBase58()} has the wrong mint pair`);
      }
      c.push(p.accounts.length);
      keys.push(...p.accounts);
    }
    if (!g.pools.some((p) => p.baseMint.equals(settlement.mint))) {
      throw new Error("direct groups require a WSOL-quoted pool");
    }
    counts.push(c);
  }
  return new TransactionInstruction({
    programId: SMB_PROGRAM,
    keys,
    data: encodeV10Data(header, counts, conversion ? conversion.pool.accounts.length : 0),
  });
}

/** Grossed-up on-chain floor: the program's share comes out of the profit first. */
export function profitFloor(minimum: bigint, costs: bigint, feeBps: number): bigint {
  const need = minimum + costs;
  const kept = BigInt(Math.max(1, 10_000 - feeBps));
  return (need * 10_000n + kept - 1n) / kept;
}
