/**
 * Learns where REAL arbitrage happens: reads the SolanaMevBot executor's own
 * recent transactions, keeps the ones that ended with a net gain for their
 * signer (not the "No profitable arbitrage" no-ops, not failures), and pulls
 * the target mint and the pools out of the V10 instruction. Those routes are
 * where the program has actually found profit, so they are the ones worth
 * simulating on every trade.
 *
 * Measured 2026-10-10: profitable calls were a few percent of all calls,
 * always on the same 2-4 pools per token (pump Token-2022 over PumpAMM +
 * DLMM, sometimes Whirlpool/CLMM/DAMM v2).
 */
import { Connection, PublicKey } from "@solana/web3.js";
import { parseTx } from "../shreds/tx-parse";
import { poolPair, SMB_POOL_PROGRAMS, SMB_PROGRAM, SOL, V10_OPCODE } from "./v10";

export interface ProfitableCall {
  signature: string;
  slot: number;
  blockTime: number;
  signer: string;
  /** Net gain of the signer (SOL + WSOL, after fee), lamports. */
  net: bigint;
  mint: string;
  pools: string[];
}

export const harvestStats = { polls: 0, txsRead: 0, profitable: 0, noop: 0, errors: 0 };

const WSOL = SOL.toBase58();

async function rpc<T>(conn: Connection, method: string, params: unknown[]): Promise<T> {
  const res = await (conn as any)._rpcRequest(method, params);
  if (res.error) throw new Error(`${method}: ${res.error.message ?? JSON.stringify(res.error)}`);
  return res.result as T;
}

interface TokenBal {
  accountIndex: number;
  mint: string;
  owner?: string;
  uiTokenAmount: { amount: string };
}
interface TxResult {
  slot: number;
  blockTime: number | null;
  transaction: [string, string];
  meta: {
    err: unknown;
    fee: number;
    preBalances: number[];
    postBalances: number[];
    preTokenBalances?: TokenBal[];
    postTokenBalances?: TokenBal[];
    logMessages?: string[];
    loadedAddresses?: { writable: string[]; readonly: string[] };
  } | null;
}

function wsolOf(bals: TokenBal[] | undefined, owner: string): bigint {
  let t = BigInt(0);
  for (const b of bals ?? []) if (b.mint === WSOL && b.owner === owner) t += BigInt(b.uiTokenAmount.amount);
  return t;
}

/** Groups of a V10 instruction: target mint + per-pool account blocks. */
function decodeV10(data: Uint8Array, accounts: string[]): { mint: string; blocks: string[][] }[] {
  if (data[0] !== V10_OPCODE || data.length < 27) return [];
  const conversion = (data[25]! & 1) === 1;
  const nGroups = data[26]!;
  let o = 27;
  const u16 = (i: number) => data[i]! | (data[i + 1]! << 8);
  let a = 9; // fixed accounts
  if (conversion) {
    const n = u16(o);
    o += 2;
    a += 3 + n;
  }
  const out: { mint: string; blocks: string[][] }[] = [];
  for (let g = 0; g < nGroups; g++) {
    const bridges = data[o++]!;
    const direct = data[o++]!;
    if (bridges !== 0) return out; // bridge layout not decoded
    const sizes: number[] = [];
    for (let i = 0; i < direct; i++, o += 2) sizes.push(u16(o));
    const mint = accounts[a]!;
    a += 3;
    const blocks: string[][] = [];
    for (const n of sizes) {
      blocks.push(accounts.slice(a, a + n));
      a += n;
    }
    out.push({ mint, blocks });
  }
  return out;
}

const poolCache = new Map<string, boolean>();

/** Picks each block's pool account (owned by the block's DEX, holding the mint). */
async function poolsOf(conn: Connection, mint: string, blocks: string[][]): Promise<string[]> {
  const programs = new Set(SMB_POOL_PROGRAMS.map((p) => p.toBase58()));
  const cands = new Set<string>();
  for (const b of blocks) {
    if (!programs.has(b[0]!)) continue;
    for (const k of b.slice(2)) if (!programs.has(k)) cands.add(k);
  }
  const unknown = [...cands].filter((k) => !poolCache.has(`${mint}|${k}`));
  for (let i = 0; i < unknown.length; i += 100) {
    const keys = unknown.slice(i, i + 100);
    const infos = await conn.getMultipleAccountsInfo(keys.map((k) => new PublicKey(k)), "confirmed");
    infos.forEach((info, j) => {
      let ok = false;
      if (info && SMB_POOL_PROGRAMS.some((p) => p.equals(info.owner))) {
        try {
          const pair = poolPair(info.owner, info.data);
          ok = pair.mints.some((m) => m.toBase58() === mint);
        } catch {
          /* tick/bin array or other account */
        }
      }
      poolCache.set(`${mint}|${keys[j]}`, ok);
    });
  }
  return [...cands].filter((k) => poolCache.get(`${mint}|${k}`));
}

/** One transaction -> profitable call, or null. */
async function readCall(conn: Connection, signature: string): Promise<ProfitableCall | null> {
  const tx = await rpc<TxResult | null>(conn, "getTransaction", [
    signature,
    { encoding: "base64", commitment: "confirmed", maxSupportedTransactionVersion: 1 },
  ]);
  harvestStats.txsRead++;
  if (!tx?.meta || tx.meta.err) return null;
  const logs = tx.meta.logMessages ?? [];
  if (logs.some((l) => l.includes("No profitable arbitrage"))) {
    harvestStats.noop++;
    return null;
  }
  const parsed = parseTx(Buffer.from(tx.transaction[0], "base64"));
  const keys = [
    ...parsed.staticKeys.map((k) => new PublicKey(k).toBase58()),
    ...(tx.meta.loadedAddresses?.writable ?? []),
    ...(tx.meta.loadedAddresses?.readonly ?? []),
  ];
  const signer = keys[0]!;
  const net =
    BigInt(tx.meta.postBalances[0]!) -
    BigInt(tx.meta.preBalances[0]!) +
    wsolOf(tx.meta.postTokenBalances, signer) -
    wsolOf(tx.meta.preTokenBalances, signer);
  if (net <= BigInt(0)) return null;
  for (const ix of parsed.instructions) {
    if (keys[ix.programIndex] !== SMB_PROGRAM.toBase58()) continue;
    const groups = decodeV10(ix.data, ix.accounts.map((i) => keys[i]!));
    for (const g of groups) {
      if (g.mint === WSOL) continue;
      const pools = await poolsOf(conn, g.mint, g.blocks);
      if (pools.length >= 2) {
        return { signature, slot: tx.slot, blockTime: tx.blockTime ?? 0, signer, net, mint: g.mint, pools };
      }
    }
  }
  return null;
}

/**
 * Polls the executor's signatures and reports each newly seen profitable call.
 * Cost: one getSignaturesForAddress per poll + one getTransaction per
 * successful call (~5 per minute market-wide).
 */
export function startHarvester(conn: Connection, onWin: (c: ProfitableCall) => void, pollMs = 10000): void {
  const seen = new Set<string>();
  let busy = false;
  let first = true;
  const poll = async () => {
    if (busy) return;
    busy = true;
    try {
      harvestStats.polls++;
      const sigs = await conn.getSignaturesForAddress(SMB_PROGRAM, { limit: first ? Number(process.env.HARVEST_FIRST_LIMIT ?? 300) : 200 }, "confirmed");
      first = false;
      // Oldest first, only successful ones (failures and drops carry no profit).
      for (const s of sigs.reverse()) {
        if (seen.has(s.signature)) continue;
        seen.add(s.signature);
        if (s.err) continue;
        try {
          const c = await readCall(conn, s.signature);
          if (c) {
            harvestStats.profitable++;
            onWin(c);
          }
        } catch {
          harvestStats.errors++;
        }
      }
      if (seen.size > 20000) seen.clear();
    } catch {
      harvestStats.errors++;
    } finally {
      busy = false;
    }
  };
  void poll();
  setInterval(() => void poll(), pollMs);
}

/** Writable keys of a tx that are pools of `mint` on an SMB-supported DEX. */
async function poolsAmong(conn: Connection, mint: string, keys: string[]): Promise<string[]> {
  const programs = new Set(SMB_POOL_PROGRAMS.map((p) => p.toBase58()));
  return poolsOf(conn, mint, [[SMB_POOL_PROGRAMS[0]!.toBase58(), "", ...keys.filter((k) => !programs.has(k))]]);
}

/**
 * Any program's arbitrage: the signer ends with more SOL+WSOL, and some
 * non-WSOL mint went through the tx without changing the signer's balance
 * of it (bought and sold back). Its pools are the tx's writable accounts
 * that are pools of that mint.
 */
async function readGenericArb(conn: Connection, signature: string): Promise<ProfitableCall | null> {
  const tx = await rpc<TxResult | null>(conn, "getTransaction", [
    signature,
    { encoding: "base64", commitment: "confirmed", maxSupportedTransactionVersion: 1 },
  ]);
  harvestStats.txsRead++;
  if (!tx?.meta || tx.meta.err) return null;
  const parsed = parseTx(Buffer.from(tx.transaction[0], "base64"));
  const statics = parsed.staticKeys.map((k) => new PublicKey(k).toBase58());
  const loadedW = tx.meta.loadedAddresses?.writable ?? [];
  const keys = [...statics, ...loadedW, ...(tx.meta.loadedAddresses?.readonly ?? [])];
  const signer = keys[0]!;
  const net =
    BigInt(tx.meta.postBalances[0]!) -
    BigInt(tx.meta.preBalances[0]!) +
    wsolOf(tx.meta.postTokenBalances, signer) -
    wsolOf(tx.meta.preTokenBalances, signer);
  if (net <= BigInt(0)) return null;
  // Writable keys: static ones by the header rule, plus loaded writable.
  const nStatic = statics.length;
  const writable: string[] = [];
  for (let i = 0; i < nStatic; i++) {
    const signed = i < parsed.numRequiredSignatures;
    const ro = signed
      ? i >= parsed.numRequiredSignatures - parsed.numReadonlySigned
      : i >= nStatic - parsed.numReadonlyUnsigned;
    if (!ro) writable.push(statics[i]!);
  }
  writable.push(...loadedW);
  const mints = new Set<string>();
  for (const b of [...(tx.meta.preTokenBalances ?? []), ...(tx.meta.postTokenBalances ?? [])]) {
    if (b.mint !== WSOL) mints.add(b.mint);
  }
  for (const mint of mints) {
    const mine = (bals: TokenBal[] | undefined) =>
      (bals ?? []).filter((b) => b.mint === mint && b.owner === signer).reduce((t, b) => t + BigInt(b.uiTokenAmount.amount), BigInt(0));
    if (mine(tx.meta.postTokenBalances) !== mine(tx.meta.preTokenBalances)) continue;
    const pools = await poolsAmong(conn, mint, writable.slice(1));
    if (pools.length >= 2) {
      return { signature, slot: tx.slot, blockTime: tx.blockTime ?? 0, signer, net, mint, pools };
    }
  }
  return null;
}

export const walletHarvestStats = { polls: 0, txsRead: 0, wins: 0, errors: 0 };

/**
 * Watches known arbitrage wallets (any program): their new successful txs
 * are read and profitable cycles on SMB-tradable pools are reported. Routes
 * repeat, so sampling `maxReadsPerPoll` txs per round is enough to learn them.
 */
export function startWalletHarvester(
  conn: Connection,
  wallets: string[],
  onWin: (c: ProfitableCall) => void,
  pollMs = 15000,
  maxReadsPerPoll = 20,
): void {
  const seen = new Set<string>();
  let busy = false;
  let first = true;
  const poll = async () => {
    if (busy) return;
    busy = true;
    walletHarvestStats.polls++;
    try {
      let reads = 0;
      for (const w of wallets) {
        let sigs;
        try {
          sigs = await conn.getSignaturesForAddress(new PublicKey(w), { limit: first ? 25 : 15 }, "confirmed");
        } catch {
          walletHarvestStats.errors++;
          continue;
        }
        for (const s of sigs) {
          if (seen.has(s.signature)) continue;
          seen.add(s.signature);
          if (s.err || reads >= maxReadsPerPoll) continue;
          reads++;
          try {
            const c = await readGenericArb(conn, s.signature);
            walletHarvestStats.txsRead++;
            if (c) {
              walletHarvestStats.wins++;
              onWin(c);
            }
          } catch {
            walletHarvestStats.errors++;
          }
        }
      }
      first = false;
      if (seen.size > 50000) seen.clear();
    } finally {
      busy = false;
    }
  };
  void poll();
  setInterval(() => void poll(), pollMs);
}
