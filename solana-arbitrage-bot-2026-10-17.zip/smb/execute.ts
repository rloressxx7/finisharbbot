/**
 * Send path for the SolanaMevBot executor (MEViEnsc…, V10): one v1
 * transaction carrying the mint's pools; ON CHAIN the program picks the
 * route and size, borrows from its own vault (flashloan, no Kamino needed),
 * and fails with Custom(1) when the profit is below the floor we set.
 *
 * Safety: the floor covers the program's share, the tx fee, any tip and the
 * rent of accounts the trade would create, plus MINIMUM_PROFIT, so a landed
 * success is never a loss. With simFirst (default) the exact transaction is
 * simulated and only a successful simulation is sent.
 *
 * Ported from solana-atomic-arb src/smb (layout verified by simulation
 * 2026-10-13: PumpV2 / DLMM / CLMM / DAMM v2 baskets accepted).
 */
import { Connection, Keypair, PublicKey, SystemProgram, TransactionInstruction } from "@solana/web3.js";
import { loadBasket, type SmbBasket } from "./basket";
import { compileV1, signV1, v1WireSize, V1_MAX_ADDRESSES, V1_MAX_TRANSACTION_SIZE } from "./tx-v1";
import { ASSOCIATED, buildV10Instruction, profitFloor, SMB_PROGRAM, SOL, SYSTEM, TOKEN } from "./v10";

export { SMB_PROGRAM };

const SIG_FEE = BigInt(5000);
const EXECUTOR_CU_MARGIN = 300;
const WSOL_CREATE_CU = 30_000;
const LOADED_ACCOUNTS_DATA_SIZE_LIMIT = 64 * 1024 * 1024;
/** PumpSwap user volume accumulator rent (created by the program on a Pump leg). */
const PUMPSWAP_UVA_RENT = BigInt(1_346_200);

export interface SmbSettings {
  /** Share of the profit the program keeps (measured 7.9-10.5%). */
  programFeeBps: number;
  minProfitLamports: bigint;
  /** Flat priority fee in lamports (v1 header). */
  priorityLamports: bigint;
  maxPools: number;
  /** Simulate the exact tx before sending (strongly recommended). */
  simFirst: boolean;
  /** Count the rent of accounts the trade creates as a cost in the floor. */
  rentInFloor?: boolean;
  /** DRY only: build/simulate as this wallet (e.g. a funded one with a WSOL account). */
  simWallet?: PublicKey;
}

export interface SmbResult {
  stage: "basket" | "wallet" | "build" | "dry" | "sim" | "send" | "sent";
  reason: string;
  signature?: string;
  bundleSignature?: string;
  /** Simulated WSOL gain (lamports) when the program found profit. */
  profit?: bigint;
}

function createAtaIdempotentIx(wallet: PublicKey, ata: PublicKey, mint: PublicKey = SOL): TransactionInstruction {
  return new TransactionInstruction({
    programId: ASSOCIATED,
    keys: [
      { pubkey: wallet, isSigner: true, isWritable: true },
      { pubkey: ata, isSigner: false, isWritable: true },
      { pubkey: wallet, isSigner: false, isWritable: false },
      { pubkey: mint, isSigner: false, isWritable: false },
      { pubkey: SYSTEM, isSigner: false, isWritable: false },
      { pubkey: TOKEN, isSigner: false, isWritable: false },
    ],
    data: Buffer.from([1]),
  });
}

const rentCache = new Map<number, bigint>();
async function rentFor(conn: Connection, bytes: number): Promise<bigint> {
  let r = rentCache.get(bytes);
  if (r === undefined) {
    r = BigInt(await conn.getMinimumBalanceForRentExemption(bytes));
    rentCache.set(bytes, r);
  }
  return r;
}

async function rpc<T>(conn: Connection, method: string, params: unknown[]): Promise<T> {
  const res = await (conn as any)._rpcRequest(method, params);
  if (res.error) throw new Error(`${method}: ${res.error.message ?? JSON.stringify(res.error)}`);
  return res.result as T;
}

async function simulate(
  conn: Connection,
  b64: string,
  wsolAta: PublicKey,
  wsolPre: bigint | null,
): Promise<{ ok: boolean; summary: string; profit?: bigint }> {
  try {
    const r = await rpc<{
      value: { err: unknown; logs?: string[]; unitsConsumed?: number; accounts?: ({ data: [string, string] } | null)[] };
    }>(conn, "simulateTransaction", [
      b64,
      {
        encoding: "base64",
        sigVerify: false,
        replaceRecentBlockhash: true,
        commitment: "processed",
        accounts: { encoding: "base64", addresses: [wsolAta.toBase58()] },
      },
    ]);
    const v = r.value;
    const logs = v.logs ?? [];
    if (v.err) {
      const custom1 = JSON.stringify(v.err).includes('"Custom":1');
      const tail = logs.slice(-3).map((l) => l.replace(/^Program log: /, "").slice(0, 80)).join(" || ");
      return { ok: false, summary: `${custom1 ? "no profit (Custom 1)" : JSON.stringify(v.err).slice(0, 80)} · ${v.unitsConsumed ?? "?"} CU · ${tail}` };
    }
    const noop = logs.some((l) => l.includes("No profitable arbitrage"));
    // The WSOL the executor left in our account = the real profit at this state.
    let profit: bigint | undefined;
    const post = v.accounts?.[0];
    if (post && wsolPre !== null) {
      const d = Buffer.from(post.data[0], "base64");
      if (d.length >= 72) profit = d.readBigUInt64LE(64) - wsolPre;
    }
    return {
      ok: !noop,
      summary: `${noop ? "no-op" : "PROFIT"}${profit !== undefined ? ` +${profit} lamports WSOL` : ""} · ${v.unitsConsumed ?? "?"} CU`,
      profit,
    };
  } catch (e) {
    return { ok: false, summary: `simulate failed: ${String(e).slice(0, 100)}` };
  }
}

/**
 * Pool account LISTS change rarely (a DLMM/CLMM array set moves only with the
 * active bin) and the program reads live pool state itself, so a basket is
 * reused for BASKET_TTL_MS: a hot trigger then costs one simulate call.
 */
const BASKET_TTL_MS = Number(process.env.SMB_BASKET_TTL_MS ?? 5000);
const basketCache = new Map<string, { key: string; at: number; basket: SmbBasket }>();
async function cachedBasket(conn: Connection, payer: PublicKey, mint: PublicKey, tokenProgram: PublicKey, pools: PublicKey[], maxPools: number) {
  const id = mint.toBase58();
  const key = `${payer.toBase58()}|${maxPools}|${pools.map((p) => p.toBase58()).join(",")}`;
  const hit = basketCache.get(id);
  if (hit && hit.key === key && Date.now() - hit.at < BASKET_TTL_MS) return hit.basket;
  const basket = await loadBasket({ stream: conn, raw: conn, wallet: payer, token: { mint, tokenProgram }, pools, maxPools });
  basketCache.set(id, { key, at: Date.now(), basket });
  if (basketCache.size > 500) basketCache.delete(basketCache.keys().next().value!);
  return basket;
}

let balanceCache: { at: number; lamports: bigint } | null = null;

export async function smbTry(a: {
  conn: Connection;
  /** RPC connections the plain (no-tip) tx is sent to. */
  sendConns: Connection[];
  /** Send the plain tx through `sendConns` (a landed failure costs its fee). */
  plain: boolean;
  /**
   * Jito bundle: `prefix` (e.g. the pending victim tx) + our tx carrying the
   * tip. A bundle whose tx fails never lands, so it costs nothing.
   */
  bundle?: { send: (txsB64: string[]) => Promise<unknown>; tip: { to: PublicKey; lamports: bigint }; prefix: string[] };
  signer: Keypair;
  mint: PublicKey;
  tokenProgram: PublicKey;
  /** The mint's pools, most relevant first (the opportunity's two pools). */
  pools: PublicKey[];
  blockhash: string;
  /** false = DRY: build + simulate only. */
  live: boolean;
  /** Skip the pre-send simulation (shred backrun: the victim has not landed yet). */
  skipSim?: boolean;
  s: SmbSettings;
}): Promise<SmbResult> {
  const { conn, s } = a;
  if (!a.blockhash) return { stage: "build", reason: "no blockhash yet" };
  const payer = !a.live && s.simWallet ? s.simWallet : a.signer.publicKey;

  let basket: SmbBasket;
  try {
    basket = await cachedBasket(conn, payer, a.mint, a.tokenProgram, a.pools, s.maxPools);
  } catch (e) {
    return { stage: "basket", reason: String(e).slice(0, 120) };
  }
  if (basket.pools.length < 2) return { stage: "basket", reason: `<2 usable pools (${basket.skipped.join("; ")})` };

  const ataRent = await rentFor(conn, 165);
  const pumpPools = basket.pools.some((p) => p.venue === "Pump" || p.venue === "PumpV2");
  const rent =
    (basket.targetAtaMissing ? ataRent : BigInt(0)) +
    (basket.volumeMissing && pumpPools ? PUMPSWAP_UVA_RENT : BigInt(0)) +
    (basket.wsolAtaMissing ? ataRent : BigInt(0)) +
    (basket.usdcAtaMissing ? ataRent : BigInt(0));
  const tip = a.bundle?.tip.lamports ?? BigInt(0);
  const plainFee = SIG_FEE + s.priorityLamports;
  const bundleFee = plainFee + tip;
  // Rent counts as a cost too: it is recoverable, but never paid for a trade
  // that would not also cover it. Each variant carries its own floor.
  // Rent of the accounts a trade creates is parked in our own accounts and
  // comes back when they are closed, so by default it is not a cost in the
  // floor (SMB_RENT_IN_FLOOR=true restores the stricter rule). The wallet
  // check below still requires the rent to be on hand.
  const rentCost = s.rentInFloor ? rent : BigInt(0);
  const plainFloor = profitFloor(s.minProfitLamports, plainFee + rentCost, s.programFeeBps);
  const bundleFloor = profitFloor(s.minProfitLamports, bundleFee + rentCost, s.programFeeBps);
  // DRY detection floor leaves the one-off rent out: it reports what the
  // market offers once the accounts exist (live sends always use the above).
  const detectFloor = profitFloor(s.minProfitLamports, plainFee, s.programFeeBps);

  if (a.live) {
    const reserve = await rentFor(conn, 0);
    if (!balanceCache || Date.now() - balanceCache.at > 3000) {
      balanceCache = { at: Date.now(), lamports: BigInt(await conn.getBalance(a.signer.publicKey, "processed")) };
    }
    const need = bundleFee + rent + reserve;
    if (balanceCache.lamports < need) {
      return { stage: "wallet", reason: `wallet ${balanceCache.lamports} < ${need} lamports (fee+rent+reserve)` };
    }
  }

  const compile = (pools: typeof basket.pools, minimumProfit: bigint, withTip: boolean) => {
    const executorLimit = basket.executorCu + Math.floor(Math.random() * 1000);
    const ixs: TransactionInstruction[] = [];
    if (basket.wsolAtaMissing) ixs.push(createAtaIdempotentIx(payer, basket.settlement.wallet));
    if (basket.usdcAtaMissing && basket.conversion) {
      ixs.push(createAtaIdempotentIx(payer, basket.conversion.quote.wallet, basket.conversion.quote.mint));
    }
    ixs.push(
      buildV10Instruction({
        wallet: payer,
        settlement: basket.settlement,
        header: { minimumProfit, computeUnitLimit: executorLimit, noFailure: false, additionalFeeBp: 0, useFlashloan: true, tradeSize: BigInt(0) },
        groups: [{ target: basket.target, pools }],
        conversion: basket.conversion,
      }),
    );
    if (withTip && a.bundle && tip > BigInt(0)) {
      ixs.push(SystemProgram.transfer({ fromPubkey: payer, toPubkey: a.bundle.tip.to, lamports: tip }));
    }
    return compileV1(payer, ixs, a.blockhash, {
      priorityFee: s.priorityLamports,
      computeUnitLimit:
        executorLimit + EXECUTOR_CU_MARGIN + (basket.wsolAtaMissing ? WSOL_CREATE_CU : 0) + (basket.usdcAtaMissing ? WSOL_CREATE_CU : 0),
      loadedAccountsDataSizeLimit: LOADED_ACCOUNTS_DATA_SIZE_LIMIT,
    });
  };
  const fits = (m: ReturnType<typeof compileV1>) => m.accountKeys.length <= V1_MAX_ADDRESSES && v1WireSize(m) <= V1_MAX_TRANSACTION_SIZE;
  let pools = basket.pools;
  let plainTx: ReturnType<typeof compileV1> | null = null;
  let bundleTx: ReturnType<typeof compileV1> | null = null;
  while (pools.length >= 2) {
    const p = compile(pools, a.live ? plainFloor : detectFloor, false);
    const b = a.bundle ? compile(pools, bundleFloor, true) : null;
    if (fits(p) && (!b || fits(b))) {
      plainTx = p;
      bundleTx = b;
      break;
    }
    pools = pools.slice(0, -1);
  }
  if (!plainTx) return { stage: "build", reason: "pools do not fit one tx" };
  const venues = pools.map((p) => p.venue).join("+");

  if (!a.live || (s.simFirst && !a.skipSim)) {
    const { wire } = signV1(plainTx, a.live ? a.signer : null);
    let wsolPre: bigint | null = BigInt(0);
    if (!basket.wsolAtaMissing) {
      const b = await conn.getTokenAccountBalance(basket.settlement.wallet, "processed").catch(() => null);
      wsolPre = b ? BigInt(b.value.amount) : null;
    }
    const sim = await simulate(conn, Buffer.from(wire).toString("base64"), basket.settlement.wallet, wsolPre);
    if (process.env.SMB_DEBUG_DUMP) {
      require("fs").writeFileSync(process.env.SMB_DEBUG_DUMP, JSON.stringify({ b64: Buffer.from(wire).toString("base64"), bytes: wire.length, keys: plainTx.accountKeys.length, venues, sim: sim.summary }));
    }
    if (!a.live) {
      return { stage: "dry", reason: `${venues} floor=${detectFloor} · ${sim.summary}`, profit: sim.ok ? sim.profit : undefined };
    }
    if (!sim.ok) return { stage: "sim", reason: `${venues} · ${sim.summary}` };
  }

  // Both paths at once: whichever lands first takes the profit; the other
  // then fails its floor (plain: costs the fee; bundle: never lands).
  const sends: Promise<string>[] = [];
  let signature: string | undefined;
  let bundleSignature: string | undefined;
  if (a.plain) {
    const { wire, signature: sig } = signV1(plainTx, a.signer);
    signature = sig;
    const b64 = Buffer.from(wire).toString("base64");
    for (const c of a.sendConns) {
      sends.push(rpc(c, "sendTransaction", [b64, { encoding: "base64", skipPreflight: true, maxRetries: 0 }]).then(() => "rpc"));
    }
  }
  if (a.bundle && bundleTx) {
    const { wire, signature: sig } = signV1(bundleTx, a.signer);
    bundleSignature = sig;
    sends.push(a.bundle.send([...a.bundle.prefix, Buffer.from(wire).toString("base64")]).then(() => "jito"));
  }
  const results = await Promise.allSettled(sends);
  const ok = results.flatMap((r) => (r.status === "fulfilled" ? [r.value] : []));
  const errs = results.flatMap((r) => (r.status === "rejected" ? [String(r.reason).slice(0, 80)] : []));
  if (!ok.length) return { stage: "send", reason: `no endpoint accepted: ${errs.join(" | ")}` };
  return {
    stage: "sent",
    reason: `${venues} accepted=${ok.join("+")}${errs.length ? ` rejected=${errs.join(" | ")}` : ""} plainFloor=${plainFloor} bundleFloor=${bundleFloor} rent=${rent}`,
    signature,
    bundleSignature,
  };
}

/** Programdata deploy slot of an upgradeable program (null = closed / not upgradeable). */
export async function programDeploySlot(conn: Connection, program: PublicKey): Promise<bigint | null> {
  const prog = await conn.getAccountInfo(program);
  if (!prog?.executable || prog.data.length < 36) return null;
  const pd = await conn.getAccountInfo(new PublicKey(prog.data.subarray(4, 36)));
  if (!pd || pd.data.length < 12) return null;
  return pd.data.readBigUInt64LE(4);
}
